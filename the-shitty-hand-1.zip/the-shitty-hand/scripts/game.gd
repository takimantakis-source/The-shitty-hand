extends Node3D
## Main game: builds the world, runs the intro, the hunt and the win condition.

const Cfg = preload("res://scripts/config.gd")
const Assets = preload("res://scripts/assets.gd")
const WorldBuilder = preload("res://scripts/world_builder.gd")
const PlayerScript = preload("res://scripts/player.gd")
const NpcScript = preload("res://scripts/npc.gd")
const HudScript = preload("res://scripts/hud.gd")
const SfxScript = preload("res://scripts/sfx.gd")

enum Phase { INTRO, PLAYING, WON }

var phase: int = Phase.INTRO
var assets
var world
var player
var hud
var sfx
var cam_yaw: Node3D
var cam_arm: SpringArm3D
var cam: Camera3D
var npcs: Array = []
var rng := RandomNumberGenerator.new()

var yaw := PI * 0.5
var pitch := -0.15
var catches := 0
var grab_cd := 0.0
var exit_open := false
var stats_t := 0.0
var play_time := 0.0
var bonk_toasts := 0
var hint_pos := Vector3.ZERO
var hint_label := ""
var hint_active := false

var lick_lines := ["Slurp!", "Lick it!", "Right in the face.", "Tastes like freedom.", "Open wide!", "Say aaah."]
var infect_lines := ["INFECTED! Now they hunt for you.", "Third time's the charm - INFECTED!", "That one's turning. Let it work."]


func _ready() -> void:
    rng.randomize()
    assets = Assets.new()
    world = WorldBuilder.new()
    world.build(self, assets)

    sfx = SfxScript.new()
    add_child(sfx)
    sfx.start_ambient()

    player = PlayerScript.new()
    player.setup(assets)
    add_child(player)
    player.position = world.toilet_pos
    player.face_angle(-PI * 0.5)

    _spawn_camera()
    _spawn_npcs()

    var layer := CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    layer.add_child(hud)
    _intro_1()


func is_playing() -> bool:
    return phase == Phase.PLAYING


# ---------------------------------------------------------------- setup

func _spawn_camera() -> void:
    cam_yaw = Node3D.new()
    add_child(cam_yaw)
    cam_arm = SpringArm3D.new()
    cam_arm.spring_length = 2.8
    cam_arm.collision_mask = 1
    cam_arm.margin = 0.3
    cam_arm.add_excluded_object(player.get_rid())
    cam_yaw.add_child(cam_arm)
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.near = 0.1
    cam.far = 140.0
    cam_arm.add_child(cam)
    cam.make_current()


func _spawn_npcs() -> void:
    var count: int = rng.randi_range(Cfg.NPC_MIN, Cfg.NPC_MAX)
    var tries := 0
    while npcs.size() < count and tries < count * 60:
        tries += 1
        var p := Vector3(rng.randf_range(-Cfg.HALL_X + 2.0, Cfg.HALL_X - 2.0), 0.0, rng.randf_range(-Cfg.HALL_Z + 2.0, Cfg.HALL_Z - 2.0))
        if not world.is_free(p, 1.0):
            continue
        if p.distance_to(world.toilet_pos) < 16.0:
            continue
        var n = NpcScript.new()
        n.setup(self, assets, rng)
        add_child(n)
        n.position = p
        npcs.append(n)


# ---------------------------------------------------------------- intro

func _intro_1() -> void:
    phase = Phase.INTRO
    yaw = PI * 0.5
    pitch = -0.12
    hud.show_dialog("MALL OF DESPAIR  -  14:32\n\nYou're parked on a public toilet in the biggest mall in the country. Nature called. You answered.", "Continue", _intro_2)


func _intro_2() -> void:
    sfx.play2d("plop")
    hud.show_dialog("You reach for the toilet paper...\n\nThere is NO toilet paper.\nNot a single sheet.", "Oh no...", _intro_3)


func _intro_3() -> void:
    hud.show_dialog("You look at your hand.\nYour hand looks back.\n\nThere is only one option left.", "WIPE WITH HAND", _wipe)


func _wipe() -> void:
    sfx.play2d("squelch")
    player.give_poop_hand()
    hud.show_dialog("Gross. Absolutely gross.\n\nCatch people and make them LICK your hand. They die. Every 3rd victim is infected instead and will hunt for you.\n\nThe exit only opens when nobody healthy is left.", "GO!", _begin_hunt)


func _begin_hunt() -> void:
    phase = Phase.PLAYING
    player.set_sitting(false)
    world.open_door()
    sfx.play3d("door", Vector3(-30.0, 0.0, -25.0), 3.0)
    yaw = -PI * 0.5
    pitch = -0.22
    cam_arm.spring_length = 4.8
    hud.show_stats = true
    hud.toast("Left thumb: move   |   Drag right side: look   |   GRAB when close", 5.0)


# ---------------------------------------------------------------- per frame

func _process(delta: float) -> void:
    if phase == Phase.INTRO:
        cam_yaw.position = player.position + Vector3(0.0, 1.0, 0.0)
    else:
        var look: Vector2 = hud.consume_look()
        yaw -= look.x * 0.0055
        pitch = clampf(pitch - look.y * 0.004, -1.25, 0.15)
        if Input.is_key_pressed(KEY_LEFT):
            yaw += 2.0 * delta
        if Input.is_key_pressed(KEY_RIGHT):
            yaw -= 2.0 * delta
        if Input.is_key_pressed(KEY_UP):
            pitch = clampf(pitch + 1.2 * delta, -1.25, 0.15)
        if Input.is_key_pressed(KEY_DOWN):
            pitch = clampf(pitch - 1.2 * delta, -1.25, 0.15)
        cam_yaw.position = player.position + Vector3(0.0, 1.45, 0.0)
    cam_yaw.rotation.y = yaw
    cam_arm.rotation.x = pitch

    if phase != Phase.PLAYING:
        return

    play_time += delta
    var kx := 0.0
    var ky := 0.0
    if Input.is_physical_key_pressed(KEY_D):
        kx += 1.0
    if Input.is_physical_key_pressed(KEY_A):
        kx -= 1.0
    if Input.is_physical_key_pressed(KEY_S):
        ky += 1.0
    if Input.is_physical_key_pressed(KEY_W):
        ky -= 1.0
    var v: Vector2 = hud.joy + Vector2(kx, ky)
    if v.length() > 1.0:
        v = v.normalized()
    var dirv := Vector3(v.x, 0.0, v.y).rotated(Vector3.UP, yaw)
    player.move_input = Vector2(dirv.x, dirv.z)
    player.sprint_held = hud.sprint_held or Input.is_physical_key_pressed(KEY_SHIFT)
    hud.stamina = player.stamina

    grab_cd -= delta
    if (hud.grab_held or Input.is_physical_key_pressed(KEY_SPACE)) and grab_cd <= 0.0:
        _try_grab()

    stats_t -= delta
    if stats_t <= 0.0:
        stats_t = 0.25
        _update_stats()

    if hint_active:
        var to: Vector3 = hint_pos - player.position
        to.y = 0.0
        var local: Vector3 = to.rotated(Vector3.UP, -yaw)
        hud.hint_angle = atan2(local.x, -local.z)
        hud.hint_dist = to.length()
        hud.hint_text = hint_label
        hud.hint_on = true
    else:
        hud.hint_on = false

    if exit_open and player.position.x > Cfg.HALL_X - 1.2 and absf(player.position.z) < 3.2:
        _win()


func _update_stats() -> void:
    var h := 0
    var inf := 0
    var dead := 0
    var near = null
    var nd := INF
    for n in npcs:
        if n.is_healthy():
            h += 1
            var d: float = n.position.distance_squared_to(player.position)
            if d < nd:
                nd = d
                near = n
        elif n.is_infected():
            inf += 1
        elif n.is_dead():
            dead += 1
    hud.healthy = h
    hud.infected = inf
    hud.dead = dead
    hud.catches = catches
    hud.next_is_infection = ((catches + 1) % Cfg.EVERY_NTH_IS_INFECTED) == 0

    hint_active = false
    if h > 0 and h <= 8 and near != null:
        hint_active = true
        hint_pos = near.position
        hint_label = "VICTIM"
    elif h == 0:
        if not exit_open:
            exit_open = true
            world.open_exit()
            sfx.play2d("exit_open")
            hud.toast("Everyone is dead or infected. THE EXIT IS OPEN - RUN!", 5.0)
        hint_active = true
        hint_pos = world.exit_pos()
        hint_label = "EXIT"


# ---------------------------------------------------------------- gameplay events

func _try_grab() -> void:
    var best = null
    var best_d: float = Cfg.GRAB_RANGE
    for n in npcs:
        if not n.is_healthy():
            continue
        var d: float = n.position.distance_to(player.position)
        if d < best_d:
            best_d = d
            best = n
    player.do_grab_anim()
    if best == null:
        grab_cd = 0.3
        sfx.play2d("whoosh", -6.0, 0.1)
        return
    grab_cd = Cfg.GRAB_COOLDOWN
    catches += 1
    var infect: bool = (catches % Cfg.EVERY_NTH_IS_INFECTED) == 0
    player.face_point(best.position)
    best.start_lick(player, infect)
    alert_around(best.position, 16.0)
    if infect:
        hud.toast(infect_lines[rng.randi() % infect_lines.size()])
    else:
        hud.toast(lick_lines[rng.randi() % lick_lines.size()])
    _update_stats()


func alert_around(pos: Vector3, radius: float) -> void:
    var r2: float = radius * radius
    for n in npcs:
        if n.is_healthy() and n.position.distance_squared_to(pos) < r2:
            n.panic()


func nearest_healthy(from: Vector3):
    var best = null
    var bd := INF
    for n in npcs:
        if n.is_healthy():
            var d: float = from.distance_squared_to(n.position)
            if d < bd:
                bd = d
                best = n
    return best


func on_npc_died(n, bonk: bool) -> void:
    if bonk:
        sfx.play3d("bonk", n.position, 3.0, 0.1)
    else:
        sfx.play3d("thud", n.position, 0.0, 0.15)
    if bonk and bonk_toasts < 6 and n.position.distance_to(player.position) < 30.0:
        bonk_toasts += 1
        hud.toast("A dumb infected face-planted into a wall. BONK.")


func on_infected(n) -> void:
    sfx.play3d("groan", n.position, 2.0, 0.2)


# ---------------------------------------------------------------- win

func _win() -> void:
    phase = Phase.WON
    player.move_input = Vector2.ZERO
    hud.hint_on = false
    var dead_count := 0
    var inf_count := 0
    for n in npcs:
        if n.is_dead():
            dead_count += 1
        elif n.is_infected():
            inf_count += 1
    var secs: int = int(play_time)
    hud.show_stats = false
    sfx.play2d("win")
    hud.show_dialog("YOU ESCAPED THE MALL!\n\nDead: %d     Infected: %d\nPlayer catches: %d\nTime: %d:%02d\n\nWash your hands." % [dead_count, inf_count, catches, secs / 60, secs % 60], "PLAY AGAIN", _restart)


func _restart() -> void:
    get_tree().reload_current_scene()
