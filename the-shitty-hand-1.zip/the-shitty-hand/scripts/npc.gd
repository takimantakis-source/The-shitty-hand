extends CharacterBody3D
## One person in the mall. States: wander -> flee (when the player is near) -> lick -> dead/infected.
## Infected hunt healthy people. "Dumb" infected die when they touch a wall.

const Cfg = preload("res://scripts/config.gd")
const Humanoid = preload("res://scripts/humanoid.gd")

enum S { WANDER, FLEE, LICK, INFECTED, DEAD }

var game
var assets
var rng: RandomNumberGenerator

var state: int = S.WANDER
var dumb := false
var walk_speed := 1.5
var run_speed := 4.6
var chase_speed := 4.5

var body: Node3D
var torso: MeshInstance3D
var head: MeshInstance3D
var arm_l: Node3D
var arm_r: Node3D
var arm_l_mesh: MeshInstance3D
var arm_r_mesh: MeshInstance3D
var leg_l: Node3D
var leg_r: Node3D

var dir := Vector3.FORWARD
var cur_speed := 0.0
var timer := 0.0
var anim_t := 0.0
var side := 1.0
var stuck_t := 0.0
var sidestep_t := 0.0
var lick_t := 0.0
var lick_infect := false
var grace := 0.0
var target = null
var retarget_t := 0.0
var catch_pause := 0.0


func setup(g, a, r: RandomNumberGenerator) -> void:
    game = g
    assets = a
    rng = r
    collision_layer = 2
    collision_mask = 1 | 8
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.3
    cap.height = 1.7
    cs.shape = cap
    cs.position = Vector3(0, 0.85, 0)
    add_child(cs)

    var shirt = a.shirts[r.randi() % a.shirts.size()]
    var skin = a.skins[r.randi() % a.skins.size()]
    var pants = a.pants[r.randi() % a.pants.size()]
    var parts: Dictionary = Humanoid.build(a, self, shirt, skin, pants, Cfg.NPC_CAST_SHADOWS, false)
    body = parts["body"]
    torso = parts["torso"]
    head = parts["head"]
    arm_l = parts["arm_l"]
    arm_r = parts["arm_r"]
    arm_l_mesh = parts["arm_l_mesh"]
    arm_r_mesh = parts["arm_r_mesh"]
    leg_l = parts["leg_l"]
    leg_r = parts["leg_r"]

    var s: float = r.randf_range(0.9, 1.08)
    body.scale = Vector3(s, s, s)
    walk_speed = r.randf_range(1.1, 1.8)
    run_speed = r.randf_range(4.0, 5.0)
    chase_speed = r.randf_range(4.1, 4.9)
    var ang: float = r.randf() * TAU
    dir = Vector3(cos(ang), 0.0, sin(ang))
    timer = r.randf_range(0.0, 3.0)
    rotation.y = r.randf() * TAU


func is_healthy() -> bool:
    return state == S.WANDER or state == S.FLEE


func is_infected() -> bool:
    return state == S.INFECTED


func is_dead() -> bool:
    return state == S.DEAD


func panic() -> void:
    if state != S.WANDER and state != S.FLEE:
        return
    if state == S.WANDER:
        side = 1.0 if rng.randf() < 0.5 else -1.0
        sidestep_t = 0.0
        if rng.randf() < 0.6 and position.distance_squared_to(game.player.position) < 1225.0:
            game.sfx.play3d("scream", position, 0.0, 0.3)
    state = S.FLEE


func _physics_process(delta: float) -> void:
    match state:
        S.WANDER:
            _do_wander(delta)
        S.FLEE:
            _do_flee(delta)
        S.LICK:
            _do_lick(delta)
        S.INFECTED:
            _do_infected(delta)


# ---------------------------------------------------------------- healthy

func _do_wander(delta: float) -> void:
    if game.is_playing() and game.player.holding_poop:
        var d2: float = position.distance_squared_to(game.player.position)
        if d2 < Cfg.NPC_NOTICE_RADIUS * Cfg.NPC_NOTICE_RADIUS:
            panic()
            return
    timer -= delta
    if timer <= 0.0:
        timer = rng.randf_range(2.0, 6.0)
        if rng.randf() < 0.25:
            cur_speed = 0.0
        else:
            cur_speed = walk_speed
            var ang: float = rng.randf() * TAU
            dir = Vector3(cos(ang), 0.0, sin(ang))
    velocity = dir * cur_speed
    move_and_slide()
    if cur_speed > 0.0 and get_slide_collision_count() > 0:
        timer = 0.0
    _face_and_animate(delta)


func _do_flee(delta: float) -> void:
    var away: Vector3 = position - game.player.position
    away.y = 0.0
    var dist: float = away.length()
    if dist > Cfg.NPC_CALM_RADIUS:
        state = S.WANDER
        timer = 0.0
        return
    if dist > 0.01:
        away = away / dist
    else:
        away = Vector3.RIGHT
    var move_dir: Vector3
    if sidestep_t > 0.0:
        sidestep_t -= delta
        move_dir = away.rotated(Vector3.UP, side * 1.2)
    else:
        move_dir = away.rotated(Vector3.UP, side * 0.35)
    velocity = move_dir * run_speed
    move_and_slide()
    var real: float = get_real_velocity().length()
    if real < run_speed * 0.45:
        stuck_t += delta
        if stuck_t > 0.2:
            stuck_t = 0.0
            if rng.randf() < 0.5:
                side = -side
            sidestep_t = 0.9
    else:
        stuck_t = maxf(0.0, stuck_t - delta)
    _face_and_animate(delta)


# ---------------------------------------------------------------- licking

func start_lick(source, infect: bool) -> void:
    state = S.LICK
    game.sfx.play3d("lick", position, 3.0, 0.1)
    lick_t = 1.15
    lick_infect = infect
    velocity = Vector3.ZERO
    var d: Vector3 = source.position - position
    rotation.y = atan2(-d.x, -d.z)
    arm_l.rotation.x = 0.0
    arm_r.rotation.x = 0.0
    leg_l.rotation.x = 0.0
    leg_r.rotation.x = 0.0
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(body, "position:y", -0.22, 0.3)
    tw.tween_property(body, "rotation:x", -0.5, 0.3)


func _do_lick(delta: float) -> void:
    lick_t -= delta
    head.rotation.x = -0.3 + sin(lick_t * 28.0) * 0.15
    if lick_t <= 0.0:
        if lick_infect:
            _become_infected()
        else:
            die(false)


func die(bonk: bool = false) -> void:
    state = S.DEAD
    set_deferred("collision_layer", 0)
    set_deferred("collision_mask", 0)
    set_physics_process(false)
    velocity = Vector3.ZERO
    var fall: float = PI * 0.5 if rng.randf() < 0.5 else -PI * 0.5
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(body, "rotation:x", fall, 0.45)
    tw.tween_property(body, "position:y", 0.2, 0.45)
    head.rotation.x = 0.0
    arm_l.rotation.x = rng.randf_range(-1.0, 1.0)
    arm_r.rotation.x = rng.randf_range(-1.0, 1.0)
    leg_l.rotation.x = rng.randf_range(-0.5, 0.5)
    leg_r.rotation.x = rng.randf_range(-0.5, 0.5)
    game.on_npc_died(self, bonk)


# ---------------------------------------------------------------- infected

func _become_infected() -> void:
    state = S.INFECTED
    grace = 1.0
    dumb = rng.randf() < Cfg.DUMB_CHANCE
    target = null
    retarget_t = 0.0
    catch_pause = 0.0
    torso.material_override = assets.infected_shirt
    head.material_override = assets.infected_skin
    arm_l_mesh.material_override = assets.infected_skin
    arm_r_mesh.material_override = assets.infected_skin
    head.rotation.x = 0.0
    if dumb:
        head.rotation.z = 0.4    # tilted head = tell-tale sign of a dumb one
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(body, "position:y", 0.0, 0.35)
    tw.tween_property(body, "rotation:x", 0.0, 0.35)
    game.on_infected(self)


func _do_infected(delta: float) -> void:
    grace -= delta
    if catch_pause > 0.0:
        catch_pause -= delta
        velocity = Vector3.ZERO
        _face_and_animate(delta)
        return
    retarget_t -= delta
    if retarget_t <= 0.0 or target == null or not target.is_healthy():
        retarget_t = rng.randf_range(0.35, 0.8)
        target = game.nearest_healthy(position)
    if target == null:
        _shamble(delta)
        return
    var to: Vector3 = target.position - position
    to.y = 0.0
    var dist: float = to.length()
    if dist < 1.2:
        target.start_lick(self, false)
        game.alert_around(target.position, 14.0)
        catch_pause = 0.9
        target = null
        return
    var d: Vector3 = to / maxf(dist, 0.001)
    if (not dumb) and sidestep_t > 0.0:
        sidestep_t -= delta
        d = d.rotated(Vector3.UP, side * 1.1)
    velocity = d * chase_speed
    move_and_slide()
    if dumb:
        if grace <= 0.0:
            for i in get_slide_collision_count():
                var col = get_slide_collision(i).get_collider()
                if col != null and col.is_in_group("solid"):
                    die(true)
                    return
    else:
        var real: float = get_real_velocity().length()
        if real < chase_speed * 0.4:
            stuck_t += delta
            if stuck_t > 0.25:
                stuck_t = 0.0
                side = 1.0 if rng.randf() < 0.5 else -1.0
                sidestep_t = 0.8
        else:
            stuck_t = maxf(0.0, stuck_t - delta)
    _face_and_animate(delta)


func _shamble(delta: float) -> void:
    timer -= delta
    if timer <= 0.0 or get_slide_collision_count() > 0:
        timer = rng.randf_range(1.5, 4.0)
        var ang: float = rng.randf() * TAU
        dir = Vector3(cos(ang), 0.0, sin(ang))
    velocity = dir * 0.9
    move_and_slide()
    _face_and_animate(delta)


# ---------------------------------------------------------------- animation

func _face_and_animate(delta: float) -> void:
    var v := Vector3(velocity.x, 0.0, velocity.z)
    var sp: float = v.length()
    if sp > 0.15:
        rotation.y = lerp_angle(rotation.y, atan2(-v.x, -v.z), minf(1.0, 9.0 * delta))
    if position.distance_squared_to(game.player.position) > 3600.0:
        return    # too far away to see: skip animation work
    var k: float = minf(1.0, 8.0 * delta)
    var rest_arm: float = 1.45 if state == S.INFECTED else 0.0
    if sp > 0.15:
        anim_t += delta * (2.0 + sp * 1.8)
        var s: float = sin(anim_t) * clampf(sp * 0.2, 0.2, 0.9)
        leg_l.rotation.x = s
        leg_r.rotation.x = -s
        if state == S.INFECTED:
            arm_l.rotation.x = rest_arm + s * 0.1
            arm_r.rotation.x = rest_arm - s * 0.1
        elif state == S.FLEE:
            arm_l.rotation.x = -s * 1.1 - 0.4
            arm_r.rotation.x = s * 1.1 - 0.4
        else:
            arm_l.rotation.x = -s
            arm_r.rotation.x = s
    else:
        leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, k)
        leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, k)
        arm_l.rotation.x = lerpf(arm_l.rotation.x, rest_arm, k)
        arm_r.rotation.x = lerpf(arm_r.rotation.x, rest_arm, k)
