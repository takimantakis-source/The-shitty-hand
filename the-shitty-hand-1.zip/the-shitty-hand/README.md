# The Shitty Hand

A silly 3D gross-out chase game for Android, made with **Godot 4.3+** (GDScript, Mobile renderer).

You're mid-poop in a public toilet in a giant mall. No toilet paper. You wipe with your hand,
walk out, and chase the 100-150 shoppers around the mall.

## Rules

- Catch someone (**GRAB** when close) and they have to lick your hand. They die.
- Every **3rd** person you catch is **infected** instead and starts hunting other people.
- Some infected are **dumb**: they run in a straight line and die when they hit a wall (tilted head = dumb).
- The exit only opens when **nobody healthy is left** (everyone dead or infected). Then run for it.

## Controls

| | Touch | Keyboard (desktop testing) |
|---|---|---|
| Move | left thumb joystick | WASD |
| Look | drag on the right side | arrow keys |
| Grab | GRAB button | Space |
| Sprint | RUN button (stamina) | Shift |

## Run it

1. Install [Godot 4.3 or newer](https://godotengine.org/download) (the normal build, not .NET).
2. Project Manager -> Import -> select `project.godot` -> Run (F5).

The whole mall is built from code at startup, so the first load takes a moment.

## Build the Android APK

1. In Godot: Editor -> Manage Export Templates -> download for your version.
2. Install a JDK (17) and the Android SDK (Android Studio is the easiest way).
3. Editor -> Editor Settings -> Export -> Android: set the Android SDK path, the JDK path and a debug keystore.
   Create a debug keystore once with:
   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ```
4. Project -> Export -> Android. Change `Package > Unique Name` (currently `com.example.theshittyhand`) to your own.
5. Export Project (APK) or plug in a phone with USB debugging and use the one-click deploy button.

See the official guide: <https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html>

## Automatic APK builds (GitHub Actions)

`.github/workflows/build-android.yml` builds a **debug-signed APK** on every push/PR and uploads it as a
workflow artifact (Actions tab -> run -> Artifacts). Push a tag like `v1.0.0` and the APK is also attached
to a GitHub Release:

```
git tag v1.0.0
git push origin v1.0.0
```

The workflow uses the `barichello/godot-ci:4.3` Docker image. Debug-signed APKs install fine on any phone
(allow "install unknown apps"), but they can't be uploaded to Google Play - that needs your own release keystore.

## Publish on GitHub

```
git init
git add .
git commit -m "The Shitty Hand"
git branch -M main
git remote add origin https://github.com/<you>/the-shitty-hand.git
git push -u origin main
```

Upload the exported APK under **Releases** instead of committing it (`*.apk` is git-ignored).

## Sound

All sound effects are synthesized (no downloaded assets, no licensing worries): `tools/make_sounds.py`
writes `audio/*.wav`. Sounds: ambient mall hum (loop), toilet plop, wipe squelch, door creak, whoosh (missed grab),
lick, scream, thud, bonk, zombie groan, exit chime, win jingle. People's sounds are 3D-positional.
To use your own recordings, replace the files in `audio/` (keep the names) or edit the list in `scripts/sfx.gd`.

## Tuning

Everything balance-related lives in `scripts/config.gd` (number of people, speeds, grab range,
infection interval, dumb-infected chance, NPC shadows...). If it runs slowly on an older phone,
lower `NPC_MAX`.

## Project layout

```
scripts/game.gd            intro, camera, win condition, game events
scripts/world_builder.gd   procedural mall: shops, toilet room, fountain, exit, lights
scripts/player.gd          player movement and animation
scripts/npc.gd             people: wander, flee, lick, die, infected AI
scripts/humanoid.gd        builds a person from primitives
scripts/assets.gd          shared materials/meshes, procedural tile texture
scripts/hud.gd             touch controls + HUD (drawn in code)
scripts/sfx.gd             sound effect manager (3D + 2D pools, ambient loop)
audio/                     generated .wav sound effects
tools/make_icons.py        regenerates the app icons (Pillow)
tools/make_sounds.py       regenerates the sound effects (numpy)
.github/workflows/         Android APK build + release
```

## Notes

- Graphics are PBR materials, polished reflective floor, bloom, filmic tonemapping and soft lighting,
  but the characters are low-poly primitives. For a more realistic look, swap `humanoid.gd` for
  CC0 character models (e.g. Quaternius, Kenney, Mixamo) with walk animations.
- Fictional shop names only. Game content is crude cartoon humor - check store policies before publishing to Google Play;
  GitHub Releases / sideloading is the easy route.

MIT licensed (see `LICENSE`).
