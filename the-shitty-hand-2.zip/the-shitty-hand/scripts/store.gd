extends Node
## Save data + settings. Registered as the autoload "Store" in project.godot.

const PATH := "user://save.cfg"

var coins := 0
var owned := {"skins:classic": true, "faces:evil": true}
var equipped := {"skin": "classic", "face": "evil", "head": "", "eyes": "", "back": ""}
var levels := {}
var npc_count := 120
var volume := 1.0
var sens := 1.0
var first_person := false
var selected_map := 0

var mode := "round"     # runtime only: "round" or "open"


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    load_data()
    apply_volume()


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_data()


func apply_volume() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))


func save_data() -> void:
    var c := ConfigFile.new()
    c.set_value("s", "coins", coins)
    c.set_value("s", "owned", owned)
    c.set_value("s", "equipped", equipped)
    c.set_value("s", "levels", levels)
    c.set_value("s", "npc_count", npc_count)
    c.set_value("s", "volume", volume)
    c.set_value("s", "sens", sens)
    c.set_value("s", "first_person", first_person)
    c.set_value("s", "selected_map", selected_map)
    c.save(PATH)


func load_data() -> void:
    var c := ConfigFile.new()
    if c.load(PATH) != OK:
        return
    coins = int(c.get_value("s", "coins", coins))
    var o = c.get_value("s", "owned", owned)
    if o is Dictionary:
        owned = o
    var e = c.get_value("s", "equipped", equipped)
    if e is Dictionary:
        for k in e:
            equipped[k] = e[k]
    var l = c.get_value("s", "levels", levels)
    if l is Dictionary:
        levels = l
    npc_count = int(c.get_value("s", "npc_count", npc_count))
    volume = float(c.get_value("s", "volume", volume))
    sens = float(c.get_value("s", "sens", sens))
    first_person = bool(c.get_value("s", "first_person", first_person))
    selected_map = int(c.get_value("s", "selected_map", selected_map))
    owned["skins:classic"] = true
    owned["faces:evil"] = true


func reset_progress() -> void:
    coins = 0
    owned = {"skins:classic": true, "faces:evil": true}
    equipped = {"skin": "classic", "face": "evil", "head": "", "eyes": "", "back": ""}
    levels = {}
    save_data()


func reset_all() -> void:
    reset_progress()


func add_coins(n: int) -> void:
    coins += n


# ---- shop ----

func has_item(cat: String, id: String) -> bool:
    return owned.has(cat + ":" + id)


func is_equipped(cat: String, item: Dictionary) -> bool:
    match cat:
        "skins":
            return equipped["skin"] == item["id"]
        "faces":
            return equipped["face"] == item["id"]
        "acc":
            return equipped.get(item["slot"], "") == item["id"]
    return false


func buy(cat: String, item: Dictionary) -> bool:
    var key: String = cat + ":" + String(item["id"])
    var price: int = int(item["price"])
    if owned.has(key) or coins < price:
        return false
    coins -= price
    owned[key] = true
    save_data()
    return true


func equip(cat: String, item: Dictionary) -> void:
    match cat:
        "skins":
            equipped["skin"] = item["id"]
        "faces":
            equipped["face"] = item["id"]
        "acc":
            var slot: String = item["slot"]
            if equipped.get(slot, "") == item["id"]:
                equipped[slot] = ""
            else:
                equipped[slot] = item["id"]
    save_data()


func level(id: String) -> int:
    return int(levels.get(id, 0))


func upgrade(item: Dictionary) -> bool:
    var lv: int = level(item["id"])
    if lv >= int(item["max"]):
        return false
    var cost: int = int(item["base"]) * (lv + 1)
    if coins < cost:
        return false
    coins -= cost
    levels[item["id"]] = lv + 1
    save_data()
    return true


# ---- power-up effects ----

func speed_mult() -> float:
    return 1.0 + 0.07 * level("speed")


func reach_bonus() -> float:
    return 0.3 * level("reach")


func stamina_mult() -> float:
    return 1.0 / (1.0 + 0.25 * level("stamina"))


func stink_radius() -> float:
    if level("stink") == 0:
        return 0.0
    return 2.5 + 0.8 * level("stink")


func coin_mult() -> float:
    return 1.0 + 0.25 * level("lucky")
