extends Node3D
## Game scene: a round on one of the 10 maps (cutscene -> hunt -> escape) or the open world.
## Store.mode ("round" / "open") and Store.selected_map are set by the home page.

const Cfg = preload("res://scripts/config.gd")
const Assets = preload("res://scripts/assets.gd")
const WorldBuilder = preload("res://scripts/world_builder.gd")
const PlayerScript = preload("res://scripts/player.gd")
const NpcScript = preload("res://scripts/npc.gd")
const HudScript = preload("res://scripts/hud.gd")
const SfxScript = preload("res://scripts/sfx.gd")
const ShopUIScript = preload("res://scripts/shop_ui.gd")
const Maps = preload("res://scripts/maps.gd")

enum Phase { CUTSCENE, PLAYING, WON }

var phase: int = Phase.PLAYING
var open_world := false
var map_def: Dictionary = {}
var assets
var world
var player
var hud
var sfx
var cam_yaw: Node3D
var cam_arm: SpringArm3D
var cam: Camera3D
var npcs: Array = []
var projectiles: Array = []
var rng := RandomNumberGenerator.new()

var yaw := 0.0
var pitch := -0.2
var catches := 0
var grab_cd := 0.0
var throw_cd := 0.0
var ultra_charge := 0
var freeze_left := 0.0
var shake_t := 0.0
var exit_open := false
var stats_t := 0.0
var spawn_t := 0.0
var play_time := 0.0
var bonk_toasts := 0
var hint_pos := Vector3.ZERO
var hint_label := ""
var hint_active := false
var key_interact := false
var key_ultra := false
var key_view := false

var cut_t := 0.0
var cut_beat := -1
var cut_wiped := false
var cut_plop := false
var cut_evil := false

var lick_lines := ["Slurp!", "Lick it!", "Right in the face.", "Tastes like freedom.", "Open wide!", "Say aaah."]
var infect_lines := ["INFECTED! Now they hunt for you.", "Third time's the charm - INFECTED!", "That one's turning. Let it work."]


func _ready() -> void:
    rng.randomize()
    open_world = (Store.mode == "open")
    if open_world:
        map_def = Maps.open_world()
    else:
        var all: Array = Maps.list()
        map_def = all[clampi(Store.selected_map, 0, all.size() - 1)]

    assets = Assets.new()
    world = WorldBuilder.new()
    world.build(self, assets, map_def, open_world)

    sfx = SfxScript.new()
    sfx.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(sfx)
    sfx.start_ambient()

    player = PlayerScript.new()
    player.setup(assets)
    add_child(player)
    player.ultra_landed.connect(_on_ultra_landed)

    _spawn_camera()
    _spawn_npcs()

    var layer := CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    layer.add_child(hud)
    hud.open_mode = open_world

    if open_world:
        _start_open_world()
    else:
        _start_cutscene()


func is_playing() -> bool:
    return phase == Phase.PLAYING


# ---------------------------------------------------------------- setup

func _spawn_camera() -> void:
    cam_yaw = Node3D.new()
    add_child(cam_yaw)
    cam_arm = SpringArm3D.new()
    cam_arm.spring_length = 2.8
    cam_arm.collision_mask = 1
    cam_arm.margin = 0.3
    cam_arm.add_excluded_object(player.get_rid())
    cam_yaw.add_child(cam_arm)
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.near = 0.1
    cam.far = 400.0 if open_world else 150.0
    cam_arm.add_child(cam)
    cam.make_current()


func _spawn_one(avoid: Vector3, min_dist: float) -> bool:
    for i in 30:
        var p := Vector3(rng.randf_range(-world.hx + 2.0, world.hx - 2.0), 0.0, rng.randf_range(-world.hz + 2.0, world.hz - 2.0))
        if not world.is_free(p, 1.0):
            continue
        if p.distance_to(avoid) < min_dist:
            continue
        var n = NpcScript.new()
        n.setup(self, assets, rng)
        add_child(n)
        n.position = p
        npcs.append(n)
        return true
    return false


func _spawn_npcs() -> void:
    var avoid: Vector3 = world.spawn_pos if open_world else world.toilet_pos
    var fails := 0
    while npcs.size() < Store.npc_count and fails < 20:
        if not _spawn_one(avoid, 16.0):
            fails += 1


# ---------------------------------------------------------------- starts

func _start_open_world() -> void:
    phase = Phase.PLAYING
    player.position = world.spawn_pos
    player.face_angle(0.0)
    player.give_poop_hand()
    yaw = 0.0
    pitch = -0.2
    hud.show_stats = true
    _apply_view()
    hud.toast("Welcome to Poopville! Visit the shops, chase people, earn coins.", 5.0)


func _start_cutscene() -> void:
    phase = Phase.CUTSCENE
    player.position = world.toilet_pos
    player.face_angle(-PI * 0.5)
    player.set_sitting(true)
    player.set_face_override("neutral")
    cut_t = 0.0
    hud.skip_on = true
    hud.show_stats = false
    yaw = PI * 0.5
    pitch = -0.1
    cam_arm.spring_length = 2.6
    _apply_view()


## ~13 second animated cutscene: sit, no toilet paper, look at hand, wipe, evil grin.
func _update_cutscene(delta: float) -> void:
    cut_t += delta
    var t: float = cut_t
    var lean := 0.0
    var head_yaw := 0.0
    var al_x := 0.5
    var al_z := 0.0
    var ar_x := 0.5
    var ar_z := 0.0
    var curl := 0.2
    var cap := ""
    if t < 2.6:
        yaw = lerpf(PI * 0.5 + 0.35, PI * 0.5, t / 2.6)
        pitch = -0.1
        cam_arm.spring_length = 2.6
        cap = "MALL OF DESPAIR  -  14:32\n\nNature called. You answered."
        if t > 0.8 and not cut_plop:
            cut_plop = true
            sfx.play2d("plop")
    elif t < 5.2:
        var k: float = t - 2.6
        yaw = PI * 0.5 - 0.5
        pitch = -0.1
        cam_arm.spring_length = 2.3
        al_x = 0.9 + sin(k * 8.0) * 0.35
        al_z = -0.9
        head_yaw = sin(k * 7.0) * 0.45
        cap = "You reach for the toilet paper...\n\nThere is NO toilet paper."
    elif t < 7.2:
        var k2: float = t - 5.2
        yaw = lerpf(PI * 0.5 - 0.5, 0.35, clampf(k2 / 1.0, 0.0, 1.0))
        pitch = -0.1
        cam_arm.spring_length = 1.7
        ar_x = 1.5
        curl = 0.5 + 0.5 * sin(k2 * 10.0)
        cap = "You look at your hand.\nYour hand looks back."
    elif t < 11.2:
        var k3: float = t - 7.2
        yaw = 0.0
        pitch = -0.12
        cam_arm.spring_length = 1.9
        lean = -0.32
        ar_x = -1.05 + sin(k3 * 13.0) * 0.22
        ar_z = -0.3
        curl = 0.3
        cap = "Only one option left."
        if k3 > 0.5 and not cut_wiped:
            cut_wiped = true
            player.give_poop_hand()
        var beat: int = int(k3 * 2.0)
        if beat != cut_beat:
            cut_beat = beat
            sfx.play2d("squelch", -4.0, 0.15)
    elif t < 13.6:
        var k4: float = t - 11.2
        yaw = lerpf(0.0, PI * 0.5, clampf(k4 / 0.8, 0.0, 1.0))
        pitch = -0.05
        cam_arm.spring_length = 1.7
        ar_x = 1.55
        curl = 0.9
        cap = "Time to share the love."
        if not cut_evil:
            cut_evil = true
            player.set_face_override("")
            sfx.play2d("whoosh")
    else:
        _begin_hunt()
        return
    player.set_pose(lean, head_yaw, al_x, al_z, ar_x, ar_z, curl)
    hud.caption = cap


func _begin_hunt() -> void:
    if not player.holding_poop:
        player.give_poop_hand()
    player.set_face_override("")
    player.set_sitting(false)
    hud.skip_on = false
    hud.caption = ""
    phase = Phase.PLAYING
    world.open_door()
    sfx.play3d("door", world.door_pos(), 3.0)
    yaw = -PI * 0.5
    pitch = -0.22
    hud.show_stats = true
    _apply_view()
    hud.toast("GRAB or THROW poop at people. 5 catches = ULTRA slam!", 5.0)


# ---------------------------------------------------------------- views / input

func _apply_view() -> void:
    var fp: bool = Store.first_person and phase != Phase.CUTSCENE
    player.set_first_person(fp)
    cam.fov = 78.0 if fp else 70.0
    cam.near = 0.05 if fp else 0.1
    if phase != Phase.CUTSCENE:
        cam_arm.spring_length = 0.0 if fp else 4.8
    hud.fp_on = fp


func _input(event: InputEvent) -> void:
    if event is InputEventKey:
        var k := event as InputEventKey
        if k.pressed and not k.echo:
            match k.keycode:
                KEY_V:
                    key_view = true
                KEY_U:
                    key_ultra = true
                KEY_E:
                    key_interact = true


func _go_home() -> void:
    Store.save_data()
    get_tree().paused = false
    get_tree().change_scene_to_file("res://scenes/menu.tscn")


func stink_factor(pos: Vector3) -> float:
    var r: float = Store.stink_radius()
    if r > 0.0 and pos.distance_to(player.position) < r:
        return 0.5
    return 1.0


# ---------------------------------------------------------------- per frame

func _process(delta: float) -> void:
    if hud.consume_home():
        _go_home()
        return

    if phase == Phase.CUTSCENE:
        if hud.consume_skip():
            _begin_hunt()
        else:
            _update_cutscene(delta)
            cam_yaw.position = player.position + Vector3(0.0, 1.0, 0.0)
            cam_yaw.rotation.y = yaw
            cam_arm.rotation.x = pitch
        return

    if hud.consume_view() or key_view:
        key_view = false
        Store.first_person = not Store.first_person
        Store.save_data()
        _apply_view()

    _update_camera(delta)
    hud.ultra_charge = ultra_charge
    hud.ultra_ready = ultra_charge >= 5
    hud.coins = Store.coins
    hud.freeze_left = freeze_left
    if freeze_left > 0.0:
        freeze_left = maxf(0.0, freeze_left - delta)
    _update_projectiles(delta)

    if phase != Phase.PLAYING:
        return

    play_time += delta
    var busy: bool = player.is_busy()
    var kx := 0.0
    var ky := 0.0
    if Input.is_physical_key_pressed(KEY_D):
        kx += 1.0
    if Input.is_physical_key_pressed(KEY_A):
        kx -= 1.0
    if Input.is_physical_key_pressed(KEY_S):
        ky += 1.0
    if Input.is_physical_key_pressed(KEY_W):
        ky -= 1.0
    var v: Vector2 = hud.joy + Vector2(kx, ky)
    if v.length() > 1.0:
        v = v.normalized()
    var dirv := Vector3(v.x, 0.0, v.y).rotated(Vector3.UP, yaw)
    player.move_input = Vector2(0.0, 0.0) if busy else Vector2(dirv.x, dirv.z)
    player.sprint_held = hud.sprint_held or Input.is_physical_key_pressed(KEY_SHIFT)
    hud.stamina = player.stamina

    grab_cd -= delta
    throw_cd -= delta
    if not busy:
        if (hud.grab_held or Input.is_physical_key_pressed(KEY_SPACE)) and grab_cd <= 0.0:
            _try_grab()
        if (hud.throw_held or Input.is_physical_key_pressed(KEY_F)) and throw_cd <= 0.0:
            _throw_poop()
        if (hud.consume_ultra() or key_ultra) and ultra_charge >= 5:
            _start_ultra()
    hud.consume_ultra()
    key_ultra = false

    stats_t -= delta
    if stats_t <= 0.0:
        stats_t = 0.25
        _update_stats()

    if hint_active:
        var to: Vector3 = hint_pos - player.position
        to.y = 0.0
        var local: Vector3 = to.rotated(Vector3.UP, -yaw)
        hud.hint_angle = atan2(local.x, -local.z)
        hud.hint_dist = to.length()
        hud.hint_text = hint_label
        hud.hint_on = true
    else:
        hud.hint_on = false

    if open_world:
        _update_open_world(delta)
        _update_shops()
    elif exit_open and player.position.x > world.hx - 1.2 and absf(player.position.z) < 3.2:
        _win()


func _update_camera(delta: float) -> void:
    var fp: bool = Store.first_person
    var look: Vector2 = hud.consume_look()
    var sens: float = Store.sens
    var pmin: float = -1.3 if fp else -1.25
    var pmax: float = 1.3 if fp else 0.15
    yaw -= look.x * 0.0055 * sens
    pitch = clampf(pitch - look.y * 0.004 * sens, pmin, pmax)
    if Input.is_key_pressed(KEY_LEFT):
        yaw += 2.0 * delta
    if Input.is_key_pressed(KEY_RIGHT):
        yaw -= 2.0 * delta
    if Input.is_key_pressed(KEY_UP):
        pitch = clampf(pitch + 1.2 * delta, pmin, pmax)
    if Input.is_key_pressed(KEY_DOWN):
        pitch = clampf(pitch - 1.2 * delta, pmin, pmax)
    cam_yaw.position = player.position + Vector3(0.0, 1.62 if fp else 1.45, 0.0)
    cam_yaw.rotation.y = yaw
    cam_arm.rotation.x = pitch
    if fp:
        player.face_angle(yaw)
    if shake_t > 0.0:
        shake_t -= delta
        cam.h_offset = rng.randf_range(-1.0, 1.0) * shake_t * 0.4
        cam.v_offset = rng.randf_range(-1.0, 1.0) * shake_t * 0.4
    else:
        cam.h_offset = 0.0
        cam.v_offset = 0.0


func _update_stats() -> void:
    var h := 0
    var inf := 0
    var dead := 0
    var near = null
    var nd := INF
    for n in npcs:
        if n.is_healthy():
            h += 1
            var d: float = n.position.distance_squared_to(player.position)
            if d < nd:
                nd = d
                near = n
        elif n.is_infected():
            inf += 1
        elif n.is_dead():
            dead += 1
    hud.healthy = h
    hud.infected = inf
    hud.dead = dead
    hud.people = h + inf
    hud.catches = catches
    hud.next_is_infection = ((catches + 1) % Cfg.EVERY_NTH_IS_INFECTED) == 0

    hint_active = false
    if open_world:
        return
    if h > 0 and h <= 8 and near != null:
        hint_active = true
        hint_pos = near.position
        hint_label = "VICTIM"
    elif h == 0:
        if not exit_open:
            exit_open = true
            world.open_exit()
            sfx.play2d("exit_open")
            hud.toast("Everyone is dead or infected. THE EXIT IS OPEN - RUN!", 5.0)
        hint_active = true
        hint_pos = world.exit_pos()
        hint_label = "EXIT"


# ---------------------------------------------------------------- catching, throwing, ultra

func _register_catch(n, quick: bool) -> void:
    catches += 1
    var infect: bool = (catches % Cfg.EVERY_NTH_IS_INFECTED) == 0
    player.face_point(n.position)
    if n.is_infected():
        n.die(false)               # a poop ball to the face stops an infected for good
    else:
        n.start_lick(player, infect, quick)
    alert_around(n.position, 16.0)
    var gain: int = int(round((5.0 if open_world else 3.0) * Store.coin_mult()))
    Store.add_coins(gain)
    var msg: String
    if infect and not n.is_infected():
        msg = infect_lines[rng.randi() % infect_lines.size()]
    else:
        msg = lick_lines[rng.randi() % lick_lines.size()]
    hud.toast("%s  +%d" % [msg, gain])
    if ultra_charge < 5:
        ultra_charge += 1
        if ultra_charge == 5:
            hud.toast("ULTRA READY!  Tap the ULTRA button!", 3.0)
            sfx.play2d("coin")
    _update_stats()


func _try_grab() -> void:
    var best = null
    var best_d: float = Cfg.GRAB_RANGE + Store.reach_bonus()
    for n in npcs:
        if not n.is_healthy():
            continue
        var d: float = n.position.distance_to(player.position)
        if d < best_d:
            best_d = d
            best = n
    player.do_grab_anim()
    if best == null:
        grab_cd = 0.3
        sfx.play2d("whoosh", -6.0, 0.1)
        return
    grab_cd = Cfg.GRAB_COOLDOWN
    _register_catch(best, false)


func _throw_poop() -> void:
    throw_cd = 0.6
    player.do_grab_anim()
    var start: Vector3 = player.hand_world_pos()
    var fwd: Vector3 = -cam.global_transform.basis.z
    var dir: Vector3 = fwd
    var best = null
    var best_dot := 0.95
    for n in npcs:
        if not n.is_healthy():
            continue
        var to: Vector3 = n.chest_pos() - start
        var dist: float = to.length()
        if dist < 1.0 or dist > 32.0:
            continue
        var dt: float = to.normalized().dot(fwd)
        if dt > best_dot:
            best_dot = dt
            best = n
    if best != null:
        var to2: Vector3 = best.chest_pos() - start
        dir = (to2 + Vector3(0.0, to2.length() * 0.03, 0.0)).normalized()
    var ball := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.12
    sm.height = 0.24
    sm.radial_segments = 10
    sm.rings = 5
    ball.mesh = sm
    ball.material_override = assets.poop
    add_child(ball)
    ball.position = start
    projectiles.append({"node": ball, "vel": dir * 30.0, "life": 2.5})
    sfx.play2d("whoosh", -4.0, 0.15)


func _hit_npc_at(p: Vector3):
    if p.y < 0.1 or p.y > 2.0:
        return null
    for n in npcs:
        if not (n.is_healthy() or n.is_infected()):
            continue
        var dx: float = p.x - n.position.x
        var dz: float = p.z - n.position.z
        if dx * dx + dz * dz < 0.49:
            return n
    return null


func _update_projectiles(delta: float) -> void:
    for i in range(projectiles.size() - 1, -1, -1):
        var pr: Dictionary = projectiles[i]
        var node: MeshInstance3D = pr["node"]
        var vel: Vector3 = pr["vel"]
        var life: float = float(pr["life"]) - delta
        var steps: int = maxi(1, int(ceil(vel.length() * delta / 0.35)))
        var dt: float = delta / float(steps)
        var done := false
        for s in steps:
            vel.y -= 5.0 * dt
            node.position += vel * dt
            var p: Vector3 = node.position
            var hit = _hit_npc_at(p)
            if hit != null:
                sfx.play3d("splat", p, 4.0, 0.1)
                _register_catch(hit, true)
                done = true
                break
            if world.blocked(p):
                sfx.play3d("splat", p, 0.0, 0.1)
                if p.y < 0.2:
                    _make_splat(Vector3(p.x, 0.03, p.z))
                done = true
                break
        pr["vel"] = vel
        pr["life"] = life
        if life <= 0.0:
            done = true
        if done:
            node.queue_free()
            projectiles.remove_at(i)


func _make_splat(pos: Vector3) -> void:
    var d := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.4
    cm.bottom_radius = 0.4
    cm.height = 0.02
    cm.radial_segments = 10
    cm.rings = 1
    d.mesh = cm
    d.material_override = assets.poop
    d.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(d)
    d.position = pos
    get_tree().create_timer(10.0).timeout.connect(d.queue_free)


func _start_ultra() -> void:
    ultra_charge = 0
    var h: float = 11.0 if not world.indoor else 4.6
    player.start_ultra(h)
    sfx.play2d("whoosh")
    hud.toast("ULTRA BUTT SLAM!", 1.5)


func _on_ultra_landed(pos: Vector3) -> void:
    sfx.play2d("boom", 4.0)
    sfx.play2d("freeze")
    shake_t = 0.9
    freeze_left = 5.0
    for n in npcs:
        n.freeze(5.0)
    _spawn_shockwave(pos)
    hud.toast("EVERYONE IS FROZEN FOR 5 SECONDS!", 3.0)


func _spawn_shockwave(pos: Vector3) -> void:
    var ring := MeshInstance3D.new()
    var tm := TorusMesh.new()
    tm.inner_radius = 0.85
    tm.outer_radius = 1.0
    tm.rings = 40
    tm.ring_segments = 6
    ring.mesh = tm
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(0.7, 0.9, 1.0, 0.8)
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.emission_enabled = true
    m.emission = Color(0.5, 0.8, 1.0)
    m.emission_energy_multiplier = 2.0
    ring.material_override = m
    ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(ring)
    ring.position = pos + Vector3(0.0, 0.15, 0.0)
    var tw := create_tween()
    tw.set_parallel(true)
    tw.tween_property(ring, "scale", Vector3(40.0, 1.0, 40.0), 0.7)
    tw.tween_property(m, "albedo_color:a", 0.0, 0.7)
    tw.chain().tween_callback(ring.queue_free)


func alert_around(pos: Vector3, radius: float) -> void:
    var r2: float = radius * radius
    for n in npcs:
        if n.is_healthy() and n.position.distance_squared_to(pos) < r2:
            n.panic()


func nearest_healthy(from: Vector3):
    var best = null
    var bd := INF
    for n in npcs:
        if n.is_healthy():
            var d: float = from.distance_squared_to(n.position)
            if d < bd:
                bd = d
                best = n
    return best


func on_npc_died(n, bonk: bool) -> void:
    if bonk:
        sfx.play3d("bonk", n.position, 3.0, 0.1)
        if bonk_toasts < 6 and n.position.distance_to(player.position) < 30.0:
            bonk_toasts += 1
            hud.toast("A dumb infected face-planted into a wall. BONK.")
    else:
        sfx.play3d("thud", n.position, 0.0, 0.15)


func on_infected(n) -> void:
    sfx.play3d("groan", n.position, 2.0, 0.2)


# ---------------------------------------------------------------- open world

func _update_open_world(delta: float) -> void:
    spawn_t -= delta
    if spawn_t > 0.0:
        return
    spawn_t = 1.0
    var now: float = Time.get_ticks_msec() / 1000.0
    var alive := 0
    for i in range(npcs.size() - 1, -1, -1):
        var n = npcs[i]
        if n.is_dead():
            if now - n.dead_time > 12.0:
                n.queue_free()
                npcs.remove_at(i)
        else:
            alive += 1
    var tries := 0
    while alive < Store.npc_count and tries < 3:
        tries += 1
        if _spawn_one(player.position, 28.0):
            alive += 1


func _update_shops() -> void:
    var near = null
    var nd := 3.6
    for s in world.shops:
        var d: float = player.position.distance_to(s["pos"])
        if d < nd:
            nd = d
            near = s
    if near == null:
        hud.interact_on = false
        key_interact = false
        return
    hud.interact_on = true
    hud.interact_text = "Enter " + String(near["name"])
    if hud.consume_interact() or key_interact:
        key_interact = false
        _open_shop(near)


func _open_shop(s: Dictionary) -> void:
    var ui = ShopUIScript.new()
    ui.setup(String(s["name"]), [String(s["cat"])], true)
    ui.changed.connect(player.apply_outfit)
    ui.closed.connect(_on_shop_closed)
    add_child(ui)
    hud.visible = false
    hud.interact_on = false
    get_tree().paused = true


func _on_shop_closed() -> void:
    get_tree().paused = false
    hud.visible = true
    Store.save_data()
    player.apply_outfit()


# ---------------------------------------------------------------- win

func _win() -> void:
    phase = Phase.WON
    player.move_input = Vector2.ZERO
    hud.hint_on = false
    var dead_count := 0
    var inf_count := 0
    for n in npcs:
        if n.is_dead():
            dead_count += 1
        elif n.is_infected():
            inf_count += 1
    var reward: int = int(round((60.0 + catches * 8.0 + dead_count * 2.0) * Store.coin_mult()))
    Store.add_coins(reward)
    Store.save_data()
    var secs: int = int(play_time)
    hud.show_stats = false
    sfx.play2d("win")
    hud.show_dialog("YOU ESCAPED THE %s!\n\nDead %d    Infected %d    Catches %d\nTime %d:%02d          +%d coins" % [String(map_def["name"]).to_upper(), dead_count, inf_count, catches, secs / 60, secs % 60, reward], "ENTER THE OPEN WORLD", _enter_open_world)


func _enter_open_world() -> void:
    Store.mode = "open"
    get_tree().reload_current_scene()
