extends RefCounted
## Builds a map procedurally: 10 round maps (layout functions) + the open world "Poopville".
## Every round map has the toilet room in the north-west corner and the exit in the middle of the east wall.

const Cfg = preload("res://scripts/config.gd")

var root: Node3D
var a
var def: Dictionary = {}
var open_world := false
var hx := 40.0
var hz := 30.0
var wh := 7.0
var indoor := true
var accent := Color.WHITE
var solids: Array = []           # Rect2 footprints (x/z): keeps spawn points clear, stops thrown poop
var door_hinge: Node3D
var exit_barrier: StaticBody3D
var exit_mesh: MeshInstance3D
var exit_label: Label3D
var toilet_pos := Vector3.ZERO
var spawn_pos := Vector3.ZERO
var shops: Array = []            # open world: [{pos, name, cat}]
var rng := RandomNumberGenerator.new()
var wall_mat: StandardMaterial3D


func build(p_root: Node3D, p_assets, p_def: Dictionary, p_open: bool) -> void:
    root = p_root
    a = p_assets
    def = p_def
    open_world = p_open
    a.make_world_assets()
    hx = float(def["hx"])
    hz = float(def["hz"])
    indoor = bool(def["indoor"])
    accent = def["accent"]
    wh = 7.0 if indoor else 2.6
    rng.seed = 777
    wall_mat = a.make(def["wall"], 0.85)
    _build_lighting()
    if open_world:
        _build_open_world()
        return
    _build_shell()
    _build_toilet_room()
    _build_exit()
    match String(def["layout"]):
        "mall":
            _layout_mall()
        "airport":
            _layout_airport()
        "metro":
            _layout_metro()
        "market":
            _layout_market()
        "hospital":
            _layout_hospital()
        "school":
            _layout_school()
        "funland":
            _layout_funland()
        "beach":
            _layout_beach()
        "casino":
            _layout_casino()
        "station":
            _layout_station()


func is_free(p: Vector3, margin: float) -> bool:
    var q := Vector2(p.x, p.z)
    for r in solids:
        var rect: Rect2 = r
        if rect.grow(margin).has_point(q):
            return false
    return true


## true if a thrown poop ball at p hits a wall / prop
func blocked(p: Vector3) -> bool:
    if p.y < 0.0:
        return true
    if p.y > 6.0:
        return false
    return not is_free(p, 0.0)


func exit_pos() -> Vector3:
    return Vector3(hx, 0.0, 0.0)


func door_pos() -> Vector3:
    return Vector3(-hx + 10.0, 0.0, -hz + 5.0)


func open_door() -> void:
    var tw := root.create_tween()
    tw.tween_property(door_hinge, "rotation:y", PI * 0.5, 0.8)


func open_exit() -> void:
    # layer 8 = blocks NPCs only, so the player can walk out but people can't
    exit_barrier.collision_layer = 8
    exit_mesh.material_override = a.exit_open
    exit_label.text = "EXIT OPEN"
    exit_label.modulate = Color(0.35, 1.0, 0.45)


# ---------------------------------------------------------------- helpers

func _box(center: Vector3, size: Vector3, mat: Material, solid: bool = true, parent: Node = null) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = center
    body.collision_layer = 1
    body.collision_mask = 0
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    body.add_child(mi)
    if solid:
        body.add_to_group("solid")
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = size
        cs.shape = bs
        body.add_child(cs)
        if parent == null:
            solids.append(Rect2(center.x - size.x * 0.5, center.z - size.z * 0.5, size.x, size.z))
    if parent == null:
        root.add_child(body)
    else:
        parent.add_child(body)
    return body


## solid box standing on the floor: centre x/z, size x/y/z
func _solid(cx: float, cz: float, sx: float, sy: float, sz: float, mat: Material) -> StaticBody3D:
    return _box(Vector3(cx, sy * 0.5, cz), Vector3(sx, sy, sz), mat)


func _deco(center: Vector3, size: Vector3, mat: Material, shadows: bool = true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    mi.position = center
    if not shadows:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mi)
    return mi


func _cyl(center: Vector3, radius: float, height: float, mat: Material, solid: bool = true, segments: int = 24) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = center
    body.collision_layer = 1
    body.collision_mask = 0
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = segments
    cm.rings = 1
    mi.mesh = cm
    mi.material_override = mat
    body.add_child(mi)
    if solid:
        body.add_to_group("solid")
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = radius
        sh.height = height
        cs.shape = sh
        body.add_child(cs)
        solids.append(Rect2(center.x - radius, center.z - radius, radius * 2.0, radius * 2.0))
    root.add_child(body)
    return body


func _cone(pos: Vector3, bottom_r: float, h: float, mat: Material, segs: int = 16) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.0
    cm.bottom_radius = bottom_r
    cm.height = h
    cm.radial_segments = segs
    cm.rings = 1
    mi.mesh = cm
    mi.material_override = mat
    mi.position = pos
    root.add_child(mi)
    return mi


func _ball(pos: Vector3, r: float, mat: Material, shadows: bool = true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = r
    sm.height = r * 2.0
    sm.radial_segments = 12
    sm.rings = 6
    mi.mesh = sm
    mi.material_override = mat
    mi.position = pos
    if not shadows:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mi)
    return mi


func _label(text: String, pos: Vector3, rot_y: float, col: Color, px: float = 0.012, fsize: int = 96) -> Label3D:
    var l := Label3D.new()
    l.text = text
    l.font_size = fsize
    l.pixel_size = px
    l.outline_size = 16
    l.modulate = col
    l.outline_modulate = Color(0, 0, 0, 1)
    l.shaded = false
    l.double_sided = false
    l.position = pos
    l.rotation.y = rot_y
    root.add_child(l)
    return l


func _pillar(x: float, z: float, r: float) -> void:
    _cyl(Vector3(x, wh * 0.5, z), r, wh, a.stone, true, 16)


func _tree(x: float, z: float) -> void:
    _cyl(Vector3(x, 1.6, z), 0.35, 3.2, a.cmat(Color(0.40, 0.26, 0.14), 0.9), true, 8)
    var leaf: StandardMaterial3D = a.cmat(Color(0.18, 0.52, 0.20), 0.9)
    _ball(Vector3(x, 4.4, z), 2.1, leaf)
    _ball(Vector3(x + 0.8, 5.3, z - 0.5), 1.4, leaf)


func _palm(x: float, z: float) -> void:
    _cyl(Vector3(x, 2.5, z), 0.25, 5.0, a.cmat(Color(0.5, 0.35, 0.2), 0.9), true, 8)
    var leaf: StandardMaterial3D = a.cmat(Color(0.2, 0.6, 0.25), 0.8)
    for i in 5:
        var lf := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(0.45, 0.06, 2.6)
        lf.mesh = bm
        lf.material_override = leaf
        lf.position = Vector3(x, 5.1, z)
        lf.rotation_degrees = Vector3(-22.0, 72.0 * i, 0.0)
        lf.translate_object_local(Vector3(0, 0, -1.2))
        root.add_child(lf)


func _umbrella(x: float, z: float, col: Color) -> void:
    _deco(Vector3(x, 1.2, z), Vector3(0.08, 2.4, 0.08), a.cmat(Color(0.9, 0.9, 0.9), 0.5), false)
    _cone(Vector3(x, 2.55, z), 1.5, 0.5, a.cmat(col, 0.7), 12)
    _deco(Vector3(x + 1.3, 0.03, z + 0.8), Vector3(0.9, 0.03, 1.8), a.cmat(col.lightened(0.3), 0.9), false)


# ---------------------------------------------------------------- shell

func _floor_material() -> StandardMaterial3D:
    var kind: String = def["floor_kind"]
    var m: StandardMaterial3D = a.make(def["floor_tint"], float(def["floor_rough"]), 0.0)
    m.albedo_texture = a.tile_tex if kind == "tile" else a.noise_tex
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    m.uv1_triplanar = true
    m.uv1_world_triplanar = true
    var sc: float = 0.3 if kind == "tile" else 0.1
    m.uv1_scale = Vector3(sc, sc, sc)
    if kind == "tile":
        m.clearcoat_enabled = true
        m.clearcoat = 0.5
        m.clearcoat_roughness = 0.08
    return m


func _build_shell() -> void:
    var floor_mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(hx * 2.0 + 10.0, hz * 2.0 + 4.0)
    floor_mi.mesh = pm
    floor_mi.material_override = _floor_material()
    floor_mi.position = Vector3(2.0, 0.0, 0.0)
    root.add_child(floor_mi)
    if not indoor:
        var og := MeshInstance3D.new()
        var opm := PlaneMesh.new()
        opm.size = Vector2(500.0, 500.0)
        og.mesh = opm
        og.material_override = a.make(Color(def["floor_tint"]).darkened(0.12), 0.9)
        og.position = Vector3(0, -0.03, 0)
        root.add_child(og)

    _box(Vector3(0, wh * 0.5, -hz - 0.5), Vector3(hx * 2.0 + 2.0, wh, 1.0), wall_mat)
    _box(Vector3(0, wh * 0.5, hz + 0.5), Vector3(hx * 2.0 + 2.0, wh, 1.0), wall_mat)
    _box(Vector3(-hx - 0.5, wh * 0.5, 0), Vector3(1.0, wh, hz * 2.0), wall_mat)
    var seg: float = hz - 3.0
    _box(Vector3(hx + 0.5, wh * 0.5, -3.0 - seg * 0.5), Vector3(1.0, wh, seg), wall_mat)
    _box(Vector3(hx + 0.5, wh * 0.5, 3.0 + seg * 0.5), Vector3(1.0, wh, seg), wall_mat)
    if indoor:
        _box(Vector3(hx + 0.5, (4.5 + wh) * 0.5, 0), Vector3(1.0, wh - 4.5, 6.0), wall_mat)
        _deco(Vector3(0, wh + 0.2, 0), Vector3(hx * 2.0 + 2.0, 0.4, hz * 2.0 + 2.0), a.cmat(def["ceiling"], 0.9), false)
        var panel: StandardMaterial3D = a.emissive(def["panel"], 2.4)
        for fx in [-0.75, -0.25, 0.25, 0.75]:
            for fz in [-0.6, -0.2, 0.2, 0.6]:
                _deco(Vector3(hx * fx, wh - 0.03, hz * fz), Vector3(hx * 0.25, 0.06, 1.0), panel, false)


# ---------------------------------------------------------------- toilet room (north-west corner)

func _build_toilet_room() -> void:
    var rh: float = wh if indoor else 3.4
    var x0: float = -hx
    var z0: float = -hz
    var wx: float = x0 + 10.0
    var dz: float = z0 + 5.0
    toilet_pos = Vector3(x0 + 1.05, 0.0, dz)

    _box(Vector3(wx, rh * 0.5, z0 + 1.9), Vector3(0.4, rh, 3.8), wall_mat)
    _box(Vector3(wx, rh * 0.5, z0 + 8.1), Vector3(0.4, rh, 3.8), wall_mat)
    _box(Vector3(wx, (2.6 + rh) * 0.5, dz), Vector3(0.4, rh - 2.6, 2.4), wall_mat)
    _box(Vector3(x0 + 5.0, rh * 0.5, z0 + 10.0), Vector3(10.4, rh, 0.4), wall_mat)
    if not indoor:
        _deco(Vector3(x0 + 5.0, rh + 0.1, z0 + 5.0), Vector3(10.6, 0.2, 10.6), wall_mat)
    solids.append(Rect2(x0, z0, 10.4, 10.4))
    _deco(Vector3(x0 + 5.0, 0.012, z0 + 5.0), Vector3(10.0, 0.02, 10.0), a.toilet_floor, false)

    door_hinge = Node3D.new()
    door_hinge.position = Vector3(wx, 0.0, dz - 1.2)
    root.add_child(door_hinge)
    _box(Vector3(0, 1.3, 1.2), Vector3(0.12, 2.6, 2.4), a.door, true, door_hinge)
    _label("WC", Vector3(wx + 0.3, minf(3.1, rh - 0.4), dz), PI * 0.5, Color(0.5, 0.8, 1.0), 0.012, 110)

    _deco(Vector3(x0 + 1.0, 0.21, dz), Vector3(0.75, 0.42, 0.5), a.porcelain)
    _deco(Vector3(x0 + 0.2, 0.62, dz), Vector3(0.3, 0.85, 0.52), a.porcelain)
    _deco(Vector3(x0 + 1.1, 0.445, dz), Vector3(0.62, 0.05, 0.46), a.porcelain)
    _box(Vector3(x0 + 1.8, 1.15, dz - 1.6), Vector3(3.6, 2.0, 0.06), a.partition)
    _box(Vector3(x0 + 1.8, 1.15, dz + 1.6), Vector3(3.6, 2.0, 0.06), a.partition)
    _box(Vector3(x0 + 6.0, 0.45, z0 + 0.6), Vector3(5.0, 0.9, 1.0), a.counter)
    _deco(Vector3(x0 + 6.0, 1.8, z0 + 0.07), Vector3(4.6, 1.3, 0.04), a.mirror)

    var l := OmniLight3D.new()
    l.position = Vector3(x0 + 5.0, minf(4.5, rh - 0.5), dz)
    l.omni_range = 11.0
    l.light_energy = 1.0
    l.light_color = Color(0.9, 0.97, 1.0)
    l.shadow_enabled = false
    root.add_child(l)


# ---------------------------------------------------------------- exit

func _build_exit() -> void:
    var eh: float = minf(4.5, wh - 0.1)
    exit_barrier = _box(Vector3(hx + 0.3, eh * 0.5, 0), Vector3(0.2, eh, 6.0), a.exit_locked)
    exit_mesh = exit_barrier.get_child(0)
    _deco(Vector3(hx + 6.0, 4.0, 0), Vector3(0.5, 14.0, 24.0), a.daylight, false)
    exit_label = _label("EXIT", Vector3(hx - 0.4, minf(5.75, wh - 0.4), 0), -PI * 0.5, Color(1.0, 0.3, 0.3), 0.012, 150)


# ---------------------------------------------------------------- lighting

func _build_lighting() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = def["sky_top"]
    sm.sky_horizon_color = def["sky_horizon"]
    sm.ground_horizon_color = Color(0.60, 0.58, 0.55)
    sm.ground_bottom_color = Color(0.35, 0.33, 0.30)
    sky.sky_material = sm
    env.sky = sky
    if indoor:
        env.background_mode = Environment.BG_COLOR
        env.background_color = Color(0.03, 0.03, 0.05)
    else:
        env.background_mode = Environment.BG_SKY
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = float(def["ambient"])
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.5
    env.glow_bloom = 0.05
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.05
    var we := WorldEnvironment.new()
    we.environment = env
    root.add_child(we)

    var sun_e: float = float(def["sun"])
    if sun_e > 0.0:
        var sun := DirectionalLight3D.new()
        sun.rotation_degrees = Vector3(-62.0, 35.0, 0.0)
        sun.light_energy = sun_e
        sun.light_color = Color(1.0, 0.96, 0.90)
        sun.shadow_enabled = true
        sun.directional_shadow_max_distance = 70.0 if not indoor else 50.0
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        root.add_child(sun)

    if indoor:
        # mobile renderer: max 8 omni lights per mesh -> 6 here (+1 in the toilet)
        var cols: Array = def["omni_colors"]
        var idx := 0
        for xi in 3:
            for zi in 2:
                var l := OmniLight3D.new()
                l.position = Vector3(hx * (-0.65 + 0.65 * xi), wh - 1.4, hz * (-0.33 if zi == 0 else 0.4))
                l.omni_range = maxf(hx, hz) * 0.8
                l.light_energy = float(def["light_energy"])
                l.light_color = cols[idx % cols.size()] if cols.size() > 0 else def["light_color"]
                l.shadow_enabled = false
                root.add_child(l)
                idx += 1


# ---------------------------------------------------------------- shops (shared by many maps)

## d = [x0, x1, z0, z1, facing (0:+Z 1:-Z 2:+X 3:-X), name, colour]
func _add_shop(d: Array) -> Dictionary:
    var sh: float = wh if indoor else 4.5
    var x0: float = d[0]
    var x1: float = d[1]
    var z0: float = d[2]
    var z1: float = d[3]
    var facing: int = d[4]
    var title: String = d[5]
    var col: Color = d[6]
    var cx: float = (x0 + x1) * 0.5
    var cz: float = (z0 + z1) * 0.5
    var sx: float = x1 - x0
    var sz: float = z1 - z0

    _box(Vector3(cx, sh * 0.5, cz), Vector3(sx, sh, sz), a.cmat(Color(0.80, 0.78, 0.74), 0.8) if indoor else a.cmat(col.darkened(0.45), 0.8))
    var glow: StandardMaterial3D = a.emissive(col.lightened(0.1), 0.9)
    var sy: float = sh - 1.5
    var win_pos := Vector3.ZERO
    var win_size := Vector3.ZERO
    var sign_pos := Vector3.ZERO
    var rot_y := 0.0
    var door := Vector3.ZERO
    match facing:
        0:
            win_pos = Vector3(cx, 1.8, z1 + 0.04)
            win_size = Vector3(sx - 3.0, 3.0, 0.08)
            sign_pos = Vector3(cx, sy, z1 + 0.1)
            rot_y = 0.0
            door = Vector3(cx, 0.0, z1 + 2.5)
        1:
            win_pos = Vector3(cx, 1.8, z0 - 0.04)
            win_size = Vector3(sx - 3.0, 3.0, 0.08)
            sign_pos = Vector3(cx, sy, z0 - 0.1)
            rot_y = PI
            door = Vector3(cx, 0.0, z0 - 2.5)
        2:
            win_pos = Vector3(x1 + 0.04, 1.8, cz)
            win_size = Vector3(0.08, 3.0, sz - 3.0)
            sign_pos = Vector3(x1 + 0.1, sy, cz)
            rot_y = PI * 0.5
            door = Vector3(x1 + 2.5, 0.0, cz)
        _:
            win_pos = Vector3(x0 - 0.04, 1.8, cz)
            win_size = Vector3(0.08, 3.0, sz - 3.0)
            sign_pos = Vector3(x0 - 0.1, sy, cz)
            rot_y = -PI * 0.5
            door = Vector3(x0 - 2.5, 0.0, cz)
    _deco(win_pos, win_size, glow, false)
    _label(title, sign_pos, rot_y, col.lightened(0.5))
    return {"door": door, "name": title}


# ================================================================ LAYOUTS

# ---- 1. Mega Mall (hall 80 x 60)
func _layout_mall() -> void:
    var defs := [
        [-27.0, -11.0, -30.0, -22.0, 0, "SHOE PALACE", Color(0.95, 0.35, 0.40)],
        [-7.0, 11.0, -30.0, -22.0, 0, "BURGER BARN", Color(1.00, 0.70, 0.20)],
        [15.0, 34.0, -30.0, -22.0, 0, "TOY KINGDOM", Color(0.40, 0.75, 1.00)],
        [-36.0, -20.0, 22.0, 30.0, 1, "PHONE PLANET", Color(0.50, 0.90, 0.60)],
        [-14.0, 4.0, 22.0, 30.0, 1, "BOOK NOOK", Color(0.85, 0.60, 1.00)],
        [10.0, 28.0, 22.0, 30.0, 1, "GAME ZONE", Color(1.00, 0.45, 0.85)],
        [-40.0, -34.0, -12.0, 8.0, 2, "FASHION FIX", Color(1.00, 0.55, 0.55)],
        [34.0, 40.0, -20.0, -6.0, 3, "SPORTS ARENA", Color(0.45, 0.85, 0.95)],
        [34.0, 40.0, 6.0, 20.0, 3, "PIZZA PIT", Color(1.00, 0.80, 0.30)],
    ]
    for d in defs:
        _add_shop(d)
    # fountain
    _cyl(Vector3(0, 0.35, 0), 5.0, 0.7, a.stone, true, 32)
    var wm := MeshInstance3D.new()
    var wc := CylinderMesh.new()
    wc.top_radius = 4.6
    wc.bottom_radius = 4.6
    wc.height = 0.06
    wc.radial_segments = 32
    wc.rings = 1
    wm.mesh = wc
    wm.material_override = a.water
    wm.position = Vector3(0, 0.66, 0)
    wm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(wm)
    _cyl(Vector3(0, 1.9, 0), 0.6, 3.6, a.stone, false, 16)
    for x in [-24.0, -8.0, 8.0, 24.0]:
        for z in [-12.0, 12.0]:
            _pillar(x, z, 0.7)
    for k in [[-14.0, -6.0, "INFO"], [14.0, -6.0, "CANDY"], [-14.0, 6.0, "COFFEE"], [14.0, 6.0, "JUICE"]]:
        var kx: float = k[0]
        var kz: float = k[1]
        _solid(kx, kz, 3.0, 2.6, 3.0, a.kiosk)
        _label(str(k[2]), Vector3(kx, 3.0, kz + 1.55), 0.0, Color(1, 0.95, 0.7), 0.01, 80)
        _label(str(k[2]), Vector3(kx, 3.0, kz - 1.55), PI, Color(1, 0.95, 0.7), 0.01, 80)


# ---- 2. Sky Airport (hall 100 x 48)
func _layout_airport() -> void:
    var cm: StandardMaterial3D = a.cmat(Color(0.85, 0.88, 0.92), 0.4)
    for x in [-18.0, -2.0, 14.0, 30.0]:
        for z in [-8.0, 8.0]:
            _solid(x, z, 10.0, 1.1, 1.6, cm)
            _label("CHECK-IN", Vector3(x, 3.0, z), 0.0 if z < 0.0 else PI, Color(0.6, 0.85, 1.0), 0.01, 80)
    var bench: StandardMaterial3D = a.cmat(Color(0.25, 0.30, 0.45), 0.6)
    for x in [-14.0, 2.0, 18.0, 34.0]:
        _solid(x, 18.0, 6.0, 0.5, 1.0, bench)
    for x in [-30.0, -10.0, 10.0, 30.0]:
        _pillar(x, 0.0, 0.8)
    _add_shop([-36.0, -24.0, 16.0, 24.0, 1, "DUTY FREE", Color(0.90, 0.60, 0.20)])
    _add_shop([38.0, 50.0, 16.0, 24.0, 1, "CAFE SKY", Color(0.40, 0.80, 0.90)])
    _deco(Vector3(6.0, 3.0, -hz + 0.06), Vector3(80.0, 3.6, 0.1), a.emissive(Color(0.55, 0.8, 1.0), 0.7), false)
    _label("GATES 1 - 24", Vector3(6.0, 5.6, -hz + 0.15), 0.0, Color(1.0, 0.9, 0.4), 0.014, 110)


# ---- 3. Metro Station (hall 90 x 36): a parked train fills the north side
func _layout_metro() -> void:
    var train: StandardMaterial3D = a.cmat(Color(0.20, 0.45, 0.85), 0.3, 0.3)
    var win: StandardMaterial3D = a.emissive(Color(1.0, 0.95, 0.7), 1.0)
    for r in [[-28.0, -15.0], [-13.0, 0.0], [2.0, 15.0], [17.0, 30.0], [32.0, 44.0]]:
        var x0: float = r[0]
        var x1: float = r[1]
        _solid((x0 + x1) * 0.5, -14.0, x1 - x0, 3.8, 7.0, train)
        _deco(Vector3((x0 + x1) * 0.5, 2.2, -10.47), Vector3(x1 - x0 - 2.0, 1.1, 0.06), win, false)
    _deco(Vector3(0, 0.02, -9.4), Vector3(88.0, 0.02, 0.4), a.emissive(Color(1.0, 0.85, 0.1), 0.8), false)
    for x in [-24.0, -8.0, 8.0, 24.0]:
        _pillar(x, 0.0, 0.6)
        _pillar(x, 9.0, 0.6)
    var mach: StandardMaterial3D = a.cmat(Color(0.2, 0.25, 0.3), 0.4)
    for x in [-20.0, -12.0, -4.0]:
        _solid(x, 16.5, 1.4, 2.2, 1.0, mach)
        _label("TICKETS", Vector3(x, 2.6, 15.95), PI, Color(0.5, 1.0, 0.7), 0.006, 80)
    var wood: StandardMaterial3D = a.cmat(Color(0.5, 0.35, 0.2), 0.8)
    for x in [12.0, 28.0]:
        _solid(x, 12.0, 5.0, 0.5, 1.0, wood)
    _label("PLATFORM 9", Vector3(0, 5.5, hz - 0.2), PI, Color(0.5, 1.0, 0.7), 0.014, 110)


# ---- 4. Super Saver Market (hall 72 x 56): long aisles
func _layout_market() -> void:
    var shelf: StandardMaterial3D = a.cmat(Color(0.85, 0.85, 0.88), 0.5)
    var cols := [Color(0.9, 0.3, 0.3), Color(0.3, 0.7, 0.3), Color(0.95, 0.8, 0.2), Color(0.3, 0.5, 0.9)]
    for x in [-16.0, -6.0, 4.0, 14.0, 24.0]:
        _solid(x, 2.0, 1.4, 2.2, 18.0, shelf)
        for i in 4:
            _deco(Vector3(x, 0.5 + i * 0.5, 2.0), Vector3(1.5, 0.28, 17.6), a.cmat(cols[i], 0.6))
    for x in [-20.0, -10.0, 0.0, 10.0, 20.0]:
        _solid(x, 22.0, 1.2, 1.0, 4.0, a.counter)
        _label("CHECKOUT", Vector3(x, 3.0, 22.0), 0.0, Color(1.0, 0.5, 0.5), 0.008, 80)
    var fridge: StandardMaterial3D = a.cmat(Color(0.70, 0.85, 0.95), 0.2, 0.2)
    var fnames := ["DAIRY", "FROZEN", "BAKERY"]
    var fx := [-12.0, 4.0, 20.0]
    for i in 3:
        _solid(fx[i], -hz + 0.7, 14.0, 2.2, 1.4, fridge)
        _label(fnames[i], Vector3(fx[i], 3.2, -hz + 1.5), 0.0, Color(0.7, 0.95, 1.0), 0.012, 90)


# ---- 5. St. Hospital (hall 88 x 48)
func _layout_hospital() -> void:
    var wn := [[-30.0, -16.0, "WARD A"], [-12.0, 2.0, "X-RAY"], [6.0, 20.0, "SURGERY"], [24.0, 38.0, "ICU"]]
    for w in wn:
        _add_shop([w[0], w[1], -24.0, -16.0, 0, w[2], Color(0.30, 0.85, 0.70)])
    var ws := [[-40.0, -26.0, "LAB"], [-22.0, -8.0, "WARD B"], [-4.0, 10.0, "PHARMACY"], [14.0, 28.0, "ER"]]
    for w in ws:
        _add_shop([w[0], w[1], 16.0, 24.0, 1, w[2], Color(0.95, 0.40, 0.40)])
    _solid(0.0, 0.0, 8.0, 1.1, 2.5, a.cmat(Color(0.9, 0.95, 0.95), 0.4))
    _label("RECEPTION", Vector3(0.0, 2.4, -1.3), 0.0, Color(0.5, 1.0, 0.85), 0.01, 90)
    var bed: StandardMaterial3D = a.cmat(Color(0.9, 0.92, 0.95), 0.5)
    for p in [[-20.0, -8.0], [-20.0, 8.0], [20.0, -8.0], [20.0, 8.0]]:
        _solid(p[0], p[1], 1.0, 0.6, 2.2, bed)
    var seat: StandardMaterial3D = a.cmat(Color(0.2, 0.5, 0.6), 0.6)
    for x in [-14.0, 14.0]:
        _solid(x, 0.0, 1.0, 0.5, 6.0, seat)


# ---- 6. Doom High School (hall 80 x 52)
func _layout_school() -> void:
    var rooms := [[-26.0, -12.0, "ROOM 101"], [-8.0, 6.0, "ROOM 102"], [10.0, 24.0, "LIBRARY"], [28.0, 40.0, "ROOM 104"]]
    for r in rooms:
        _add_shop([r[0], r[1], -26.0, -18.0, 0, r[2], Color(0.95, 0.80, 0.20)])
    _solid(0.0, hz - 0.35, hx * 2.0 - 2.0, 2.2, 0.7, a.cmat(Color(0.25, 0.3, 0.4), 0.5))
    for i in 17:
        var c: Color = Color(0.2, 0.5, 0.8) if i % 2 == 0 else Color(0.2, 0.7, 0.7)
        _deco(Vector3(-34.0 + i * 4.2, 1.1, hz - 0.72), Vector3(3.6, 2.0, 0.04), a.cmat(c, 0.4), false)
    var wood: StandardMaterial3D = a.cmat(Color(0.55, 0.38, 0.22), 0.8)
    for x in [-12.0, 0.0, 12.0]:
        for z in [-2.0, 8.0]:
            _solid(x, z, 6.0, 0.8, 1.6, wood)
    _label("CAFETERIA", Vector3(0.0, 4.0, -9.0), 0.0, Color(1.0, 0.9, 0.5), 0.012, 100)


# ---- 7. Funland Park (outdoor, 100 x 72)
func _layout_funland() -> void:
    var cx := 22.0
    var cz := -14.0
    var hub_y := 11.5
    var tm := TorusMesh.new()
    tm.inner_radius = 8.6
    tm.outer_radius = 9.0
    tm.rings = 40
    tm.ring_segments = 8
    var wheel := MeshInstance3D.new()
    wheel.mesh = tm
    wheel.material_override = a.emissive(accent, 0.6)
    wheel.rotation_degrees = Vector3(90.0, 0.0, 0.0)
    wheel.position = Vector3(cx, hub_y, cz)
    root.add_child(wheel)
    for i in 4:
        var sp := MeshInstance3D.new()
        var sb := BoxMesh.new()
        sb.size = Vector3(17.8, 0.15, 0.15)
        sp.mesh = sb
        sp.material_override = a.cmat(Color(0.9, 0.9, 0.95), 0.4)
        sp.position = Vector3(cx, hub_y, cz)
        sp.rotation_degrees = Vector3(0.0, 0.0, 45.0 * i)
        root.add_child(sp)
    var gcols := [Color(1, 0.3, 0.3), Color(0.3, 0.8, 0.3), Color(0.3, 0.5, 1.0), Color(1, 0.85, 0.2)]
    for i in 8:
        var ang: float = TAU * float(i) / 8.0
        _deco(Vector3(cx + cos(ang) * 8.8, hub_y + sin(ang) * 8.8 - 0.8, cz), Vector3(1.4, 1.4, 1.4), a.cmat(gcols[i % 4], 0.5))
    _solid(cx, cz, 1.4, hub_y, 1.4, a.cmat(Color(0.8, 0.8, 0.85), 0.4))
    _label("MEGA WHEEL", Vector3(cx, 1.6, cz + 1.0), 0.0, Color(1.0, 0.8, 0.3), 0.01, 90)
    # carousel
    _cyl(Vector3(-16, 0.25, 10), 5.0, 0.5, a.cmat(Color(0.9, 0.75, 0.3), 0.4), true, 24)
    _cone(Vector3(-16, 5.2, 10), 6.2, 2.8, a.cmat(accent, 0.5), 24)
    for i in 6:
        var ang2: float = TAU * float(i) / 6.0
        _deco(Vector3(-16 + cos(ang2) * 4.2, 2.5, 10 + sin(ang2) * 4.2), Vector3(0.2, 4.0, 0.2), a.cmat(Color(1, 1, 1), 0.4))
    # stalls + rides
    _add_shop([-34.0, -22.0, 28.0, 36.0, 1, "CORN DOGS", Color(1.00, 0.70, 0.20)])
    _add_shop([-8.0, 4.0, 28.0, 36.0, 1, "COTTON CANDY", Color(1.00, 0.50, 0.80)])
    _add_shop([18.0, 30.0, 28.0, 36.0, 1, "POPCORN", Color(1.00, 0.90, 0.30)])
    _add_shop([-8.0, 6.0, -36.0, -28.0, 0, "TICKETS", Color(0.40, 0.85, 0.50)])
    _add_shop([6.0, 24.0, 8.0, 20.0, 0, "BUMPER CARS", Color(0.40, 0.60, 1.00)])
    for p in [[-42.0, 0.0], [-42.0, 14.0], [-30.0, -10.0], [-30.0, 16.0], [-6.0, -18.0], [10.0, -26.0],
            [38.0, -20.0], [40.0, 8.0], [40.0, 22.0], [-18.0, -26.0], [32.0, 14.0], [0.0, 22.0]]:
        _tree(p[0], p[1])


# ---- 8. Sunny Beach (outdoor, 110 x 64)
func _layout_beach() -> void:
    _deco(Vector3(0, -0.5, -hz - 32.0), Vector3(260.0, 0.8, 60.0), a.water, false)
    _deco(Vector3(0, -0.2, -hz - 2.5), Vector3(260.0, 0.3, 5.0), a.emissive(Color(0.8, 0.95, 1.0), 0.3), false)
    _add_shop([-44.0, -30.0, 24.0, 32.0, 1, "SURF SHOP", Color(0.20, 0.80, 0.90)])
    _add_shop([-14.0, 0.0, 24.0, 32.0, 1, "ICE CREAM", Color(1.00, 0.60, 0.80)])
    _add_shop([16.0, 30.0, 24.0, 32.0, 1, "TACO HUT", Color(1.00, 0.80, 0.20)])
    _add_shop([38.0, 52.0, 24.0, 32.0, 1, "BEACH BAR", Color(0.50, 0.90, 0.50)])
    # lifeguard tower
    _solid(30.0, -20.0, 3.0, 4.5, 3.0, a.cmat(Color(1.0, 0.95, 0.9), 0.6))
    _deco(Vector3(30.0, 4.7, -20.0), Vector3(3.4, 0.3, 3.4), a.cmat(Color(0.9, 0.2, 0.2), 0.6))
    _label("LIFEGUARD", Vector3(30.0, 3.0, -18.45), 0.0, Color(0.9, 0.2, 0.2), 0.008, 90)
    # volleyball net
    _cyl(Vector3(-12.0, 1.2, 0.0), 0.12, 2.4, a.cmat(Color(0.9, 0.9, 0.9), 0.5), true, 8)
    _cyl(Vector3(-4.0, 1.2, 0.0), 0.12, 2.4, a.cmat(Color(0.9, 0.9, 0.9), 0.5), true, 8)
    _deco(Vector3(-8.0, 1.9, 0.0), Vector3(8.0, 0.9, 0.04), a.cmat(Color(1, 1, 1), 0.8), false)
    for p in [[-48.0, -8.0], [-48.0, 12.0], [48.0, -24.0], [48.0, 12.0], [10.0, -26.0], [-20.0, -26.0], [-26.0, 18.0], [8.0, 18.0]]:
        _palm(p[0], p[1])
    var ucols := [Color(1, 0.3, 0.3), Color(0.3, 0.6, 1.0), Color(1, 0.85, 0.2), Color(0.3, 0.8, 0.4), Color(1, 0.5, 0.8)]
    var placed := 0
    var tries := 0
    while placed < 14 and tries < 200:
        tries += 1
        var x: float = rng.randf_range(-hx + 14.0, hx - 6.0)
        var z: float = rng.randf_range(-hz + 4.0, hz - 10.0)
        if not is_free(Vector3(x, 0.0, z), 3.0):
            continue
        _umbrella(x, z, ucols[placed % 5])
        placed += 1


# ---- 9. Neon Casino (hall 84 x 60, dark)
func _layout_casino() -> void:
    var cab: StandardMaterial3D = a.cmat(Color(0.15, 0.05, 0.20), 0.4, 0.3)
    var cols := [Color(1.0, 0.2, 0.7), Color(0.2, 0.9, 1.0), Color(1.0, 0.8, 0.2)]
    var ci := 0
    for x in [-16.0, 0.0, 16.0]:
        for z in [-12.0, 12.0]:
            _solid(x, z, 13.0, 2.0, 1.4, cab)
            var dz: float = 0.72 if z < 0.0 else -0.72
            _deco(Vector3(x, 1.4, z + dz), Vector3(12.0, 0.8, 0.05), a.emissive(cols[ci % 3], 1.5), false)
            ci += 1
    var felt: StandardMaterial3D = a.cmat(Color(0.05, 0.4, 0.2), 0.8)
    for x in [-12.0, -4.0, 4.0, 12.0]:
        _cyl(Vector3(x, 0.45, 0.0), 2.0, 0.9, felt, true, 20)
    _ball(Vector3(0, 5.2, 0), 1.2, a.emissive(Color(1.0, 0.85, 0.5), 2.0), false)
    _deco(Vector3(0, 3.0, hz - 0.1), Vector3(hx * 2.0 - 4.0, 0.15, 0.1), a.emissive(Color(1.0, 0.2, 0.7), 2.0), false)
    _deco(Vector3(0, 3.0, -hz + 0.1), Vector3(hx * 2.0 - 4.0, 0.15, 0.1), a.emissive(Color(0.2, 0.9, 1.0), 2.0), false)
    _add_shop([20.0, 38.0, -30.0, -24.0, 0, "NEON BAR", Color(1.0, 0.2, 0.7)])
    _add_shop([-16.0, -4.0, 24.0, 30.0, 1, "CASHIER", Color(0.2, 0.9, 1.0)])


# ---- 10. Orbit Station (hall 92 x 52)
func _layout_station() -> void:
    _deco(Vector3(0.0, 3.5, -hz + 0.06), Vector3(70.0, 4.4, 0.1), a.cmat(Color(0.01, 0.01, 0.03), 0.2), false)
    var planet := _ball(Vector3(14.0, 3.6, -hz + 0.14), 3.4, a.emissive(Color(0.3, 0.55, 1.0), 0.8), false)
    planet.scale = Vector3(1.0, 1.0, 0.03)
    for i in 40:
        _deco(Vector3(rng.randf_range(-33.0, 33.0), rng.randf_range(1.5, 5.5), -hz + 0.13), Vector3(0.08, 0.08, 0.02), a.emissive(Color(1, 1, 1), 2.0), false)
    var crate: StandardMaterial3D = a.cmat(Color(0.75, 0.45, 0.15), 0.5, 0.4)
    for p in [[-14.0, 0.0], [-12.0, 2.0], [18.0, -8.0], [20.0, -8.0], [20.0, -6.0], [-2.0, 14.0], [0.0, 14.0], [2.0, 14.0]]:
        _solid(p[0], p[1], 2.0, 2.0, 2.0, crate)
    for p in [[-12.0, -8.0], [12.0, -8.0], [-12.0, 8.0], [12.0, 8.0]]:
        _pillar(p[0], p[1], 1.0)
        _deco(Vector3(p[0], 2.0, p[1]), Vector3(2.4, 0.15, 2.4), a.emissive(Color(0.3, 0.8, 1.0), 1.5), false)
    var green: StandardMaterial3D = a.cmat(Color(0.15, 0.55, 0.2), 0.7)
    for x in [-10.0, 12.0]:
        _solid(x, 16.0, 10.0, 1.0, 2.0, green)
    _add_shop([-6.0, 8.0, -26.0, -18.0, 0, "MESS HALL", Color(1.0, 0.7, 0.3)])
    _add_shop([22.0, 38.0, 18.0, 26.0, 1, "SUPPLY BAY", Color(0.4, 0.8, 1.0)])
    exit_label.text = "AIRLOCK"


# ================================================================ OPEN WORLD "Poopville" (170 x 170)

func _build_open_world() -> void:
    wh = 2.2
    spawn_pos = Vector3(0.0, 0.0, 14.0)

    var ground := MeshInstance3D.new()
    var gp := PlaneMesh.new()
    gp.size = Vector2(hx * 2.0 + 10.0, hz * 2.0 + 10.0)
    ground.mesh = gp
    ground.material_override = _floor_material()
    root.add_child(ground)
    var og := MeshInstance3D.new()
    var ogp := PlaneMesh.new()
    ogp.size = Vector2(600.0, 600.0)
    og.mesh = ogp
    og.material_override = a.make(Color(0.22, 0.5, 0.2), 0.95)
    og.position = Vector3(0, -0.03, 0)
    root.add_child(og)

    # hedges around the town
    var hedge: StandardMaterial3D = a.cmat(Color(0.15, 0.45, 0.18), 0.9)
    _box(Vector3(0, 1.1, -hz - 0.5), Vector3(hx * 2.0 + 2.0, 2.2, 1.0), hedge)
    _box(Vector3(0, 1.1, hz + 0.5), Vector3(hx * 2.0 + 2.0, 2.2, 1.0), hedge)
    _box(Vector3(-hx - 0.5, 1.1, 0), Vector3(1.0, 2.2, hz * 2.0), hedge)
    _box(Vector3(hx + 0.5, 1.1, 0), Vector3(1.0, 2.2, hz * 2.0), hedge)

    # roads + plaza
    var asphalt: StandardMaterial3D = a.cmat(Color(0.18, 0.18, 0.20), 0.9)
    _deco(Vector3(0, 0.02, 0), Vector3(hx * 2.0, 0.04, 8.0), asphalt, false)
    _deco(Vector3(0, 0.02, 0), Vector3(8.0, 0.04, hz * 2.0), asphalt, false)
    _deco(Vector3(0, 0.03, 0), Vector3(26.0, 0.04, 26.0), a.cmat(Color(0.75, 0.72, 0.66), 0.6), false)
    var dash: StandardMaterial3D = a.cmat(Color(0.95, 0.95, 0.9), 0.8)
    for i in 16:
        _deco(Vector3(-hx + 6.0 + i * 10.0, 0.045, 0.0), Vector3(4.0, 0.01, 0.2), dash, false)
        _deco(Vector3(0.0, 0.045, -hz + 6.0 + i * 10.0), Vector3(0.2, 0.01, 4.0), dash, false)

    # fountain in the middle of the plaza
    _cyl(Vector3(0, 0.35, 0), 4.5, 0.7, a.stone, true, 32)
    var wm := MeshInstance3D.new()
    var wc := CylinderMesh.new()
    wc.top_radius = 4.1
    wc.bottom_radius = 4.1
    wc.height = 0.06
    wc.radial_segments = 32
    wc.rings = 1
    wm.mesh = wc
    wm.material_override = a.water
    wm.position = Vector3(0, 0.66, 0)
    wm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(wm)
    _cyl(Vector3(0, 1.8, 0), 0.5, 3.2, a.stone, false, 16)

    # the four shops around the plaza
    var defs := [
        [-34.0, -20.0, -24.0, -15.0, 0, "SKIN SHOP", Color(1.00, 0.55, 0.20), "skins"],
        [20.0, 34.0, -24.0, -15.0, 0, "FACE SHOP", Color(0.95, 0.35, 0.75), "faces"],
        [-34.0, -20.0, 15.0, 24.0, 1, "ACCESSORY SHOP", Color(0.40, 0.75, 1.00), "acc"],
        [20.0, 34.0, 15.0, 24.0, 1, "POWER-UP SHOP", Color(0.50, 0.95, 0.40), "power"],
    ]
    for d in defs:
        var info: Dictionary = _add_shop(d)
        shops.append({"pos": info["door"], "name": d[5], "cat": d[7]})
        _deco(Vector3(info["door"].x, 0.04, info["door"].z), Vector3(3.0, 0.02, 3.0), a.emissive(d[6], 0.8), false)

    # parks
    _park(55.0, -58.0, 50.0, 40.0, 18, false)
    _park(-55.0, 58.0, 50.0, 40.0, 18, true)
    _park(-64.0, -8.0, 34.0, 30.0, 10, false)

    # houses
    var pastel := [Color(0.95, 0.80, 0.70), Color(0.75, 0.88, 0.95), Color(0.85, 0.95, 0.75), Color(0.97, 0.88, 0.60), Color(0.90, 0.75, 0.90)]
    var hi := 0
    for p in [[-70.0, -70.0], [-52.0, -70.0], [-70.0, -54.0], [-52.0, -54.0], [52.0, 52.0], [70.0, 52.0], [52.0, 68.0], [70.0, 68.0],
            [60.0, -16.0], [76.0, -16.0], [60.0, 16.0], [76.0, 16.0]]:
        _house(p[0], p[1], pastel[hi % 5])
        hi += 1

    _label("WELCOME TO POOPVILLE", Vector3(0.0, 4.0, 16.0), 0.0, Color(1.0, 0.85, 0.3), 0.02, 120)


func _park(cx: float, cz: float, sx: float, sz: float, n_trees: int, pond: bool) -> void:
    _deco(Vector3(cx, 0.015, cz), Vector3(sx, 0.03, sz), a.cmat(Color(0.25, 0.70, 0.28), 0.9), false)
    _deco(Vector3(cx, 0.03, cz), Vector3(sx, 0.02, 2.5), a.cmat(Color(0.85, 0.78, 0.60), 0.9), false)
    _deco(Vector3(cx, 0.03, cz), Vector3(2.5, 0.02, sz), a.cmat(Color(0.85, 0.78, 0.60), 0.9), false)
    if pond:
        _cyl(Vector3(cx + 10.0, 0.15, cz - 8.0), 6.4, 0.3, a.stone, true, 24)
        var wm := MeshInstance3D.new()
        var wc := CylinderMesh.new()
        wc.top_radius = 5.9
        wc.bottom_radius = 5.9
        wc.height = 0.05
        wc.radial_segments = 24
        wc.rings = 1
        wm.mesh = wc
        wm.material_override = a.water
        wm.position = Vector3(cx + 10.0, 0.32, cz - 8.0)
        wm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        root.add_child(wm)
    var wood: StandardMaterial3D = a.cmat(Color(0.55, 0.38, 0.22), 0.8)
    for i in 4:
        var bx: float = cx + (i - 1.5) * sx * 0.22
        _solid(bx, cz + 3.2, 2.0, 0.5, 0.6, wood)
    var placed := 0
    var tries := 0
    while placed < n_trees and tries < 300:
        tries += 1
        var x: float = cx + rng.randf_range(-sx * 0.5 + 2.0, sx * 0.5 - 2.0)
        var z: float = cz + rng.randf_range(-sz * 0.5 + 2.0, sz * 0.5 - 2.0)
        if not is_free(Vector3(x, 0.0, z), 2.5):
            continue
        if absf(x - cx) < 2.5 or absf(z - cz) < 2.5:
            continue
        _tree(x, z)
        placed += 1


func _house(x: float, z: float, col: Color) -> void:
    _solid(x, z, 9.0, 5.0, 7.0, a.cmat(col, 0.8))
    var roof := _cone(Vector3(x, 6.5, z), 6.6, 3.0, a.cmat(Color(0.65, 0.25, 0.2), 0.8), 4)
    roof.rotation_degrees = Vector3(0.0, 45.0, 0.0)
    _deco(Vector3(x, 1.1, z + 3.55), Vector3(1.2, 2.2, 0.1), a.cmat(Color(0.45, 0.28, 0.12), 0.7), false)
    var glow: StandardMaterial3D = a.emissive(Color(1.0, 0.9, 0.6), 0.6)
    _deco(Vector3(x - 2.5, 2.8, z + 3.55), Vector3(1.4, 1.2, 0.1), glow, false)
    _deco(Vector3(x + 2.5, 2.8, z + 3.55), Vector3(1.4, 1.2, 0.1), glow, false)
