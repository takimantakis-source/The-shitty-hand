extends RefCounted
## Builds people out of primitives. The character faces -Z.
## Rotating a limb pivot by +X swings it FORWARD. Faces are curved decals on the head.


static func build(a, parent: Node3D, shirt: Material, skin: Material, pants: Material, cast_shadow: bool,
        detailed: bool = false, face_id: String = "calm") -> Dictionary:
    var shadow_mode: int = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var vis_end: float = 0.0 if detailed else 65.0
    var parts := {}

    var body := Node3D.new()
    body.name = "Body"
    parent.add_child(body)
    parts["body"] = body

    var torso := _mi(a.mesh_torso, shirt, shadow_mode, vis_end)
    torso.position = Vector3(0, 1.2, 0)
    torso.scale = Vector3(1.05, 1.0, 0.7)
    body.add_child(torso)
    parts["torso"] = torso

    var head := _mi(a.mesh_head, skin, shadow_mode, vis_end)
    head.position = Vector3(0, 1.68, 0)
    body.add_child(head)
    parts["head"] = head

    var face := _mi(a.mesh_face, a.face_mat(face_id), GeometryInstance3D.SHADOW_CASTING_SETTING_OFF, 0.0 if detailed else 30.0)
    head.add_child(face)
    parts["face"] = face

    for side in [-1, 1]:
        var pivot := Node3D.new()
        pivot.position = Vector3(0.26 * side, 1.5, 0)
        body.add_child(pivot)
        var arm := _mi(a.mesh_arm, skin, shadow_mode, vis_end)
        arm.position = Vector3(0, -0.29, 0)
        pivot.add_child(arm)
        var key: String = "arm_r" if side == 1 else "arm_l"
        parts[key] = pivot
        parts[key + "_mesh"] = arm
        if detailed:
            parts["hand_r" if side == 1 else "hand_l"] = build_hand(a, pivot, skin, float(side), shadow_mode)

    for side in [-1, 1]:
        var pivot := Node3D.new()
        pivot.position = Vector3(0.1 * side, 0.9, 0)
        body.add_child(pivot)
        var leg := _mi(a.mesh_leg, pants, shadow_mode, vis_end)
        leg.position = Vector3(0, -0.45, 0)
        pivot.add_child(leg)
        parts["leg_r" if side == 1 else "leg_l"] = pivot
        parts["leg_r_mesh" if side == 1 else "leg_l_mesh"] = leg

    return parts


## A hand with FIVE fingers (4 fingers + thumb). Fingers point along -Y.
## Returns {"root", "fingers": [4 fingers..., thumb], "meshes": [...], "blob"}.
static func build_hand(a, pivot: Node3D, mat: Material, mirror: float, shadow_mode: int) -> Dictionary:
    var hand := Node3D.new()
    hand.position = Vector3(0, -0.62, 0)
    hand.scale = Vector3(1.5, 1.5, 1.5)
    pivot.add_child(hand)
    var meshes: Array = []

    var palm := _mi(a.mesh_palm, mat, shadow_mode, 0.0)
    palm.position = Vector3(0, -0.045, 0)
    hand.add_child(palm)
    meshes.append(palm)

    var fingers: Array = []
    var xs := [0.03, 0.01, -0.01, -0.03]          # index, middle, ring, pinky (thumb side first)
    var lens := [0.075, 0.085, 0.075, 0.058]
    for i in 4:
        var fp := Node3D.new()
        fp.position = Vector3(float(xs[i]) * mirror, -0.09, 0)
        hand.add_child(fp)
        var fl: float = lens[i]
        var fm := _mi(a.mesh_finger, mat, shadow_mode, 0.0)
        fm.scale = Vector3(1.0, fl / 0.07, 1.0)
        fm.position = Vector3(0, -fl * 0.5, 0)
        fp.add_child(fm)
        meshes.append(fm)
        fingers.append(fp)

    var tp := Node3D.new()
    tp.position = Vector3(0.05 * mirror, -0.03, 0)
    tp.rotation.z = 0.7 * mirror
    hand.add_child(tp)
    var tm := _mi(a.mesh_finger, mat, shadow_mode, 0.0)
    tm.scale = Vector3(1.15, 0.055 / 0.07, 1.15)
    tm.position = Vector3(0, -0.0275, 0)
    tp.add_child(tm)
    meshes.append(tm)
    fingers.append(tp)

    var blob := _mi(a.mesh_blob, a.poop, shadow_mode, 0.0)
    blob.position = Vector3(0, -0.05, -0.02)
    blob.scale = Vector3(1.0, 1.0, 0.4)
    blob.visible = false
    hand.add_child(blob)

    return {"root": hand, "fingers": fingers, "meshes": meshes, "blob": blob}


## Curved patch of a sphere (radius slightly larger than the head) that carries the face texture.
static func make_face_mesh() -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var n := 8
    var span: float = deg_to_rad(40.0)
    var r := 0.1345
    for iy in n:
        for ix in n:
            _face_vert(st, ix, iy, n, span, r)
            _face_vert(st, ix + 1, iy, n, span, r)
            _face_vert(st, ix, iy + 1, n, span, r)
            _face_vert(st, ix + 1, iy, n, span, r)
            _face_vert(st, ix + 1, iy + 1, n, span, r)
            _face_vert(st, ix, iy + 1, n, span, r)
    return st.commit()


static func _face_vert(st: SurfaceTool, ix: int, iy: int, n: int, span: float, r: float) -> void:
    var u: float = float(ix) / float(n)
    var v: float = float(iy) / float(n)
    var th: float = (1.0 - u * 2.0) * span      # texture-left = character's right (+X)
    var ph: float = (1.0 - v * 2.0) * span
    var pos := Vector3(r * sin(th) * cos(ph), r * sin(ph), -r * cos(th) * cos(ph))
    st.set_uv(Vector2(u, v))
    st.set_normal(pos.normalized())
    st.add_vertex(pos)


## Accessories: slot "head" / "eyes" attach to the head node, slot "back" to the body node.
static func build_accessory(a, id: String) -> Node3D:
    var root := Node3D.new()
    root.name = "Acc_" + id
    var black: StandardMaterial3D = a.cmat(Color(0.05, 0.05, 0.06), 0.35)
    match id:
        "top_hat":
            _cyl(root, Vector3(0, 0.21, 0), 0.085, 0.085, 0.2, black)
            _cyl(root, Vector3(0, 0.115, 0), 0.16, 0.16, 0.02, black)
            _cyl(root, Vector3(0, 0.15, 0), 0.088, 0.088, 0.035, a.cmat(Color(0.7, 0.1, 0.1), 0.5))
        "crown":
            var gold: StandardMaterial3D = a.cmat(Color(1.0, 0.8, 0.15), 0.25, 0.9)
            _cyl(root, Vector3(0, 0.135, 0), 0.1, 0.105, 0.06, gold)
            for i in 5:
                var ang: float = i * TAU / 5.0
                _cyl(root, Vector3(sin(ang) * 0.095, 0.2, cos(ang) * 0.095), 0.0, 0.022, 0.07, gold)
            _cyl(root, Vector3(0, 0.135, -0.104), 0.014, 0.014, 0.03, a.cmat(Color(0.9, 0.1, 0.2), 0.2), Vector3(90, 0, 0))
        "party_hat":
            _cyl(root, Vector3(0.015, 0.23, 0), 0.0, 0.085, 0.22, a.cmat(Color(0.95, 0.2, 0.7), 0.5), Vector3(0, 0, -8))
            _cyl(root, Vector3(0.03, 0.345, 0), 0.025, 0.025, 0.05, a.cmat(Color(1.0, 0.9, 0.2), 0.5))
        "cap":
            var red: StandardMaterial3D = a.cmat(Color(0.85, 0.1, 0.1), 0.6)
            var dome := MeshInstance3D.new()
            var sm := SphereMesh.new()
            sm.radius = 0.138
            sm.height = 0.18
            sm.radial_segments = 14
            sm.rings = 5
            dome.mesh = sm
            dome.material_override = red
            dome.position = Vector3(0, 0.07, 0)
            root.add_child(dome)
            _box(root, Vector3(0, 0.075, -0.15), Vector3(0.16, 0.012, 0.11), red)
        "horns":
            var hm: StandardMaterial3D = a.cmat(Color(0.8, 0.05, 0.05), 0.4)
            _cyl(root, Vector3(0.075, 0.14, 0), 0.0, 0.03, 0.13, hm, Vector3(0, 0, -25))
            _cyl(root, Vector3(-0.075, 0.14, 0), 0.0, 0.03, 0.13, hm, Vector3(0, 0, 25))
        "cat_ears":
            _cyl(root, Vector3(0.08, 0.125, -0.01), 0.0, 0.04, 0.08, black, Vector3(0, 0, -18))
            _cyl(root, Vector3(-0.08, 0.125, -0.01), 0.0, 0.04, 0.08, black, Vector3(0, 0, 18))
        "sunglasses":
            _box(root, Vector3(0.05, 0.03, -0.14), Vector3(0.085, 0.045, 0.012), black)
            _box(root, Vector3(-0.05, 0.03, -0.14), Vector3(0.085, 0.045, 0.012), black)
            _box(root, Vector3(0, 0.04, -0.141), Vector3(0.03, 0.01, 0.01), black)
        "cape":
            var cm: StandardMaterial3D = a.cmat(Color(0.75, 0.05, 0.1), 0.6)
            _box(root, Vector3(0, 1.1, 0.17), Vector3(0.42, 0.78, 0.025), cm)
            _box(root, Vector3(0, 1.52, 0.12), Vector3(0.4, 0.07, 0.1), cm)
    return root


static func _mi(mesh: Mesh, mat: Material, shadow: int, vis_end: float) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    m.mesh = mesh
    m.material_override = mat
    m.cast_shadow = shadow as GeometryInstance3D.ShadowCastingSetting
    if vis_end > 0.0:
        m.visibility_range_end = vis_end
    return m


static func _cyl(parent: Node3D, pos: Vector3, top_r: float, bottom_r: float, h: float, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> void:
    var m := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = top_r
    cm.bottom_radius = bottom_r
    cm.height = h
    cm.radial_segments = 14
    cm.rings = 1
    m.mesh = cm
    m.material_override = mat
    m.position = pos
    m.rotation_degrees = rot_deg
    parent.add_child(m)


static func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> void:
    var m := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    m.mesh = bm
    m.material_override = mat
    m.position = pos
    parent.add_child(m)
