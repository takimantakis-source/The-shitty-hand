extends RefCounted
## Shared materials and meshes. Character assets are created at startup,
## world assets (textures etc.) only when a map is built.

const Humanoid = preload("res://scripts/humanoid.gd")

var shirts: Array = []
var skins: Array = []
var pants: Array = []
var infected_shirt: StandardMaterial3D
var infected_skin: StandardMaterial3D
var poop: StandardMaterial3D
var stink: StandardMaterial3D
var frost: StandardMaterial3D
var ice: StandardMaterial3D        # same as frost: tint used while people are frozen

var tile_tex: ImageTexture
var noise_tex: ImageTexture
var stone: StandardMaterial3D
var water: StandardMaterial3D
var door: StandardMaterial3D
var porcelain: StandardMaterial3D
var partition: StandardMaterial3D
var mirror: StandardMaterial3D
var counter: StandardMaterial3D
var kiosk: StandardMaterial3D
var toilet_floor: StandardMaterial3D
var exit_locked: StandardMaterial3D
var exit_open: StandardMaterial3D
var daylight: StandardMaterial3D

var mesh_torso: CapsuleMesh
var mesh_head: SphereMesh
var mesh_arm: CapsuleMesh
var mesh_leg: BoxMesh
var mesh_palm: BoxMesh
var mesh_finger: CapsuleMesh
var mesh_blob: SphereMesh
var mesh_frost: CapsuleMesh
var mesh_face: ArrayMesh

var face_mats := {}
var _cache := {}
var _world_ready := false


func _init() -> void:
    _make_character_assets()


# ---------------------------------------------------------------- material helpers

func _mat(color: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metal
    return m


func make(color: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
    return _mat(color, rough, metal)


func cmat(color: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
    var key: String = "%s|%.2f|%.2f" % [color.to_html(true), rough, metal]
    if _cache.has(key):
        return _cache[key]
    var m := _mat(color, rough, metal)
    _cache[key] = m
    return m


func emissive(color: Color, energy: float = 1.5) -> StandardMaterial3D:
    var key: String = "e|%s|%.2f" % [color.to_html(true), energy]
    if _cache.has(key):
        return _cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.emission_enabled = true
    m.emission = color
    m.emission_energy_multiplier = energy
    _cache[key] = m
    return m


func _alpha(m: StandardMaterial3D) -> StandardMaterial3D:
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m


func skin_materials(d: Dictionary) -> Array:
    var shine: float = float(d.get("shine", 0.0))
    var shirt := _mat(d["shirt"], 0.75 - 0.55 * shine, shine)
    var skin := _mat(d["skin"], 0.55 - 0.3 * shine, shine * 0.6)
    var pnts := _mat(d["pants"], 0.85 - 0.6 * shine, shine * 0.5)
    if bool(d.get("glow", false)):
        for m in [shirt, skin]:
            m.emission_enabled = true
            m.emission = m.albedo_color
            m.emission_energy_multiplier = 0.55
    return [shirt, skin, pnts]


func face_mat(id: String) -> StandardMaterial3D:
    if face_mats.has(id):
        return face_mats[id]
    var m := StandardMaterial3D.new()
    m.albedo_texture = load("res://faces/%s.png" % id)
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    m.alpha_scissor_threshold = 0.5
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    face_mats[id] = m
    return m


# ---------------------------------------------------------------- characters

func _make_character_assets() -> void:
    for c in [Color(0.96, 0.80, 0.69), Color(0.87, 0.67, 0.51), Color(0.72, 0.51, 0.36), Color(0.55, 0.38, 0.26), Color(0.36, 0.24, 0.17)]:
        skins.append(_mat(c, 0.55))
    for c in [Color(0.80, 0.15, 0.15), Color(0.15, 0.30, 0.75), Color(0.90, 0.75, 0.15), Color(0.20, 0.55, 0.25),
            Color(0.90, 0.90, 0.90), Color(0.12, 0.12, 0.14), Color(0.90, 0.50, 0.65), Color(0.10, 0.55, 0.60),
            Color(0.50, 0.25, 0.60), Color(0.90, 0.50, 0.10), Color(0.50, 0.50, 0.52), Color(0.10, 0.12, 0.30)]:
        shirts.append(_mat(c, 0.8))
    for c in [Color(0.18, 0.25, 0.45), Color(0.10, 0.10, 0.10), Color(0.55, 0.50, 0.35), Color(0.35, 0.35, 0.38), Color(0.25, 0.17, 0.10)]:
        pants.append(_mat(c, 0.85))

    infected_shirt = _mat(Color(0.28, 0.36, 0.20), 0.9)
    infected_skin = _mat(Color(0.52, 0.70, 0.33), 0.6)
    poop = _mat(Color(0.30, 0.17, 0.06), 0.22)
    stink = _alpha(_mat(Color(0.55, 0.85, 0.20, 0.55), 0.5))
    stink.emission_enabled = true
    stink.emission = Color(0.55, 0.85, 0.20)
    stink.emission_energy_multiplier = 0.8
    frost = _alpha(_mat(Color(0.55, 0.85, 1.0, 0.55), 0.1))
    frost.emission_enabled = true
    frost.emission = Color(0.4, 0.8, 1.0)
    frost.emission_energy_multiplier = 0.7
    ice = frost

    mesh_torso = CapsuleMesh.new()
    mesh_torso.radius = 0.2
    mesh_torso.height = 0.74
    mesh_torso.radial_segments = 12
    mesh_torso.rings = 4

    mesh_head = SphereMesh.new()
    mesh_head.radius = 0.13
    mesh_head.height = 0.26
    mesh_head.radial_segments = 14
    mesh_head.rings = 7

    mesh_arm = CapsuleMesh.new()
    mesh_arm.radius = 0.05
    mesh_arm.height = 0.62
    mesh_arm.radial_segments = 8
    mesh_arm.rings = 3

    mesh_leg = BoxMesh.new()
    mesh_leg.size = Vector3(0.19, 0.9, 0.22)

    mesh_palm = BoxMesh.new()
    mesh_palm.size = Vector3(0.085, 0.09, 0.032)

    mesh_finger = CapsuleMesh.new()
    mesh_finger.radius = 0.0105
    mesh_finger.height = 0.07
    mesh_finger.radial_segments = 8
    mesh_finger.rings = 2

    mesh_blob = SphereMesh.new()
    mesh_blob.radius = 0.045
    mesh_blob.height = 0.09
    mesh_blob.radial_segments = 10
    mesh_blob.rings = 5

    mesh_frost = CapsuleMesh.new()
    mesh_frost.radius = 0.38
    mesh_frost.height = 1.85
    mesh_frost.radial_segments = 10
    mesh_frost.rings = 4

    mesh_face = Humanoid.make_face_mesh()


# ---------------------------------------------------------------- world

func make_world_assets() -> void:
    if _world_ready:
        return
    _world_ready = true
    tile_tex = _make_tile_texture(Color(0.95, 0.95, 0.95), Color(0.60, 0.60, 0.60), 4, 128)
    noise_tex = _make_noise_texture(128)

    stone = _mat(Color(0.72, 0.70, 0.66), 0.5)
    water = _alpha(_mat(Color(0.25, 0.55, 0.80, 0.75), 0.03))
    door = _mat(Color(0.55, 0.40, 0.28), 0.6)
    porcelain = _mat(Color(0.97, 0.97, 0.98), 0.12)
    partition = _mat(Color(0.55, 0.72, 0.78), 0.4)
    mirror = _mat(Color(0.80, 0.85, 0.90), 0.04, 1.0)
    counter = _mat(Color(0.20, 0.20, 0.22), 0.3, 0.4)
    kiosk = _mat(Color(0.25, 0.30, 0.40), 0.5)
    daylight = emissive(Color(1.0, 0.98, 0.92), 3.0)

    toilet_floor = _mat(Color(0.55, 0.76, 0.78), 0.25)
    toilet_floor.albedo_texture = tile_tex
    toilet_floor.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    toilet_floor.uv1_triplanar = true
    toilet_floor.uv1_world_triplanar = true
    toilet_floor.uv1_scale = Vector3(0.9, 0.9, 0.9)

    exit_locked = _alpha(_mat(Color(1.0, 0.1, 0.1, 0.4), 0.2))
    exit_locked.emission_enabled = true
    exit_locked.emission = Color(1.0, 0.1, 0.1)
    exit_locked.emission_energy_multiplier = 0.7

    exit_open = _alpha(_mat(Color(0.1, 1.0, 0.3, 0.2), 0.2))
    exit_open.emission_enabled = true
    exit_open.emission = Color(0.1, 1.0, 0.3)
    exit_open.emission_energy_multiplier = 0.6


func _make_tile_texture(base: Color, grout: Color, tiles: int, px: int) -> ImageTexture:
    var img := Image.create(px, px, true, Image.FORMAT_RGB8)
    var rng := RandomNumberGenerator.new()
    rng.seed = 12345
    var tile_px: int = px / tiles
    for ty in tiles:
        for tx in tiles:
            var shade := rng.randf_range(-0.035, 0.035)
            for y in tile_px:
                for x in tile_px:
                    var ox := tx * tile_px + x
                    var oy := ty * tile_px + y
                    if x < 2 or y < 2:
                        img.set_pixel(ox, oy, grout)
                    else:
                        var n := shade + rng.randf_range(-0.012, 0.012)
                        img.set_pixel(ox, oy, Color(base.r + n, base.g + n, base.b + n))
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)


func _make_noise_texture(px: int) -> ImageTexture:
    var img := Image.create(px, px, true, Image.FORMAT_RGB8)
    var n := FastNoiseLite.new()
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.frequency = 0.05
    n.seed = 7
    var rng := RandomNumberGenerator.new()
    rng.seed = 99
    for y in px:
        for x in px:
            var v: float = 0.86 + n.get_noise_2d(x, y) * 0.12 + rng.randf_range(-0.05, 0.05)
            img.set_pixel(x, y, Color(v, v, v))
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)
