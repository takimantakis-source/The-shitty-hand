extends CanvasLayer
## Shop / wardrobe overlay (built from Controls). Used by the 4 open-world shops (buying)
## and by the home-page wardrobe (equipping owned items only).

const Items = preload("res://scripts/items.gd")

signal closed
signal changed

var title_text := ""
var categories: Array = []
var can_buy := true
var cur_cat := ""

var list: VBoxContainer
var tab_row: HBoxContainer
var coins_label: Label
var click_player: AudioStreamPlayer
var coin_player: AudioStreamPlayer


func setup(title: String, cats: Array, buy: bool) -> void:
    title_text = title
    categories = cats
    can_buy = buy
    cur_cat = String(cats[0])


func _ready() -> void:
    layer = 30
    process_mode = Node.PROCESS_MODE_ALWAYS
    click_player = AudioStreamPlayer.new()
    click_player.stream = load("res://audio/click.wav")
    add_child(click_player)
    coin_player = AudioStreamPlayer.new()
    coin_player.stream = load("res://audio/coin.wav")
    add_child(coin_player)
    _build()
    _refresh()


func _build() -> void:
    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var th := Theme.new()
    th.default_font_size = 26
    root.theme = th

    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.72)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(940, 600)
    root.add_child(panel)
    panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)

    var margin := MarginContainer.new()
    for side in ["left", "right", "top", "bottom"]:
        margin.add_theme_constant_override("margin_" + side, 18)
    panel.add_child(margin)

    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    margin.add_child(v)

    var head := HBoxContainer.new()
    v.add_child(head)
    var title := Label.new()
    title.text = title_text
    title.add_theme_font_size_override("font_size", 38)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(title)
    coins_label = Label.new()
    coins_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
    head.add_child(coins_label)
    var close := Button.new()
    close.text = "  X  "
    close.pressed.connect(_on_close)
    head.add_child(close)

    tab_row = HBoxContainer.new()
    tab_row.add_theme_constant_override("separation", 10)
    v.add_child(tab_row)

    var scroll := ScrollContainer.new()
    scroll.custom_minimum_size = Vector2(0, 400)
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    v.add_child(scroll)
    list = VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    list.add_theme_constant_override("separation", 10)
    scroll.add_child(list)


func _refresh() -> void:
    coins_label.text = "Coins: %d   " % Store.coins

    for t in tab_row.get_children():
        t.queue_free()
    if categories.size() > 1:
        for c in categories:
            var tb := Button.new()
            tb.text = Items.category_title(String(c))
            tb.disabled = (String(c) == cur_cat)
            tb.pressed.connect(_on_tab.bind(String(c)))
            tab_row.add_child(tb)

    for r in list.get_children():
        r.queue_free()
    for it in Items.catalog(cur_cat):
        list.add_child(_make_row(it))


func _make_row(it: Dictionary) -> Control:
    var pc := PanelContainer.new()
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 14)
    pc.add_child(h)

    if cur_cat == "faces":
        var bg := ColorRect.new()
        bg.color = Color(0.87, 0.67, 0.51)
        bg.custom_minimum_size = Vector2(76, 76)
        h.add_child(bg)
        var tr := TextureRect.new()
        tr.texture = load("res://faces/%s.png" % it["id"])
        tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        bg.add_child(tr)
        tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    elif cur_cat == "skins":
        for key in ["shirt", "skin", "pants"]:
            var sw := ColorRect.new()
            sw.color = it[key]
            sw.custom_minimum_size = Vector2(26, 76)
            h.add_child(sw)

    var col := VBoxContainer.new()
    col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(col)
    var nm := Label.new()
    nm.text = String(it["name"])
    nm.add_theme_font_size_override("font_size", 30)
    col.add_child(nm)
    var ds := Label.new()
    ds.add_theme_font_size_override("font_size", 20)
    ds.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
    ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    col.add_child(ds)

    var b := Button.new()
    b.custom_minimum_size = Vector2(220, 64)
    b.pressed.connect(_on_action.bind(it))
    h.add_child(b)

    if cur_cat == "power":
        var lv: int = Store.level(String(it["id"]))
        var mx: int = int(it["max"])
        ds.text = "%s    (Lv %d / %d)" % [it["desc"], lv, mx]
        if lv >= mx:
            b.text = "MAX"
            b.disabled = true
        else:
            var cost: int = int(it["base"]) * (lv + 1)
            b.text = "UPGRADE %d" % cost
            b.disabled = (not can_buy) or Store.coins < cost
    else:
        ds.text = String(it["desc"])
        if Store.has_item(cur_cat, String(it["id"])):
            var eq: bool = Store.is_equipped(cur_cat, it)
            if cur_cat == "acc":
                b.text = "TAKE OFF" if eq else "WEAR"
            else:
                b.text = "EQUIPPED" if eq else "EQUIP"
                b.disabled = eq
        else:
            var price: int = int(it["price"])
            if can_buy:
                b.text = "BUY %d" % price
                b.disabled = Store.coins < price
            else:
                b.text = "LOCKED"
                b.disabled = true
    return pc


func _on_tab(cat: String) -> void:
    click_player.play()
    cur_cat = cat
    _refresh()


func _on_action(it: Dictionary) -> void:
    if cur_cat == "power":
        if Store.upgrade(it):
            coin_player.play()
    elif Store.has_item(cur_cat, String(it["id"])):
        Store.equip(cur_cat, it)
        click_player.play()
    elif Store.buy(cur_cat, it):
        Store.equip(cur_cat, it)
        coin_player.play()
    changed.emit()
    _refresh()


func _on_close() -> void:
    click_player.play()
    closed.emit()
    queue_free()
