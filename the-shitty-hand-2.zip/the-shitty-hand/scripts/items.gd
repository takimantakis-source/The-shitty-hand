extends RefCounted
## Shop catalog: skins, faces, accessories, power-ups.


static func category_title(cat: String) -> String:
    match cat:
        "skins":
            return "Skins"
        "faces":
            return "Faces"
        "acc":
            return "Accessories"
        "power":
            return "Power-ups"
    return cat


static func catalog(cat: String) -> Array:
    match cat:
        "skins":
            return skins()
        "faces":
            return faces()
        "acc":
            return accessories()
        "power":
            return powerups()
    return []


static func skins() -> Array:
    return [
        {"id": "classic", "name": "Classic Orange", "desc": "The original look.", "price": 0,
            "shirt": Color(0.95, 0.45, 0.08), "skin": Color(0.87, 0.67, 0.51), "pants": Color(0.12, 0.14, 0.22)},
        {"id": "zombie", "name": "Zombie Green", "desc": "Already dead inside.", "price": 150,
            "shirt": Color(0.30, 0.40, 0.22), "skin": Color(0.52, 0.70, 0.33), "pants": Color(0.20, 0.20, 0.15)},
        {"id": "pink", "name": "Hot Pink", "desc": "Aggressively fabulous.", "price": 200,
            "shirt": Color(1.0, 0.30, 0.60), "skin": Color(0.96, 0.80, 0.69), "pants": Color(0.50, 0.10, 0.35)},
        {"id": "ninja", "name": "Shadow Ninja", "desc": "Silent but deadly.", "price": 250,
            "shirt": Color(0.08, 0.08, 0.10), "skin": Color(0.80, 0.62, 0.48), "pants": Color(0.05, 0.05, 0.07)},
        {"id": "ghost", "name": "Ghost White", "desc": "Boo. Also: ew.", "price": 250,
            "shirt": Color(0.95, 0.95, 1.0), "skin": Color(0.90, 0.92, 1.0), "pants": Color(0.80, 0.82, 0.90)},
        {"id": "toxic", "name": "Toxic Waste", "desc": "Glows in the dark.", "price": 350, "glow": true,
            "shirt": Color(0.30, 1.0, 0.20), "skin": Color(0.60, 1.0, 0.40), "pants": Color(0.10, 0.40, 0.10)},
        {"id": "lava", "name": "Lava Lord", "desc": "Hot stuff.", "price": 400, "glow": true,
            "shirt": Color(0.90, 0.15, 0.05), "skin": Color(0.30, 0.10, 0.08), "pants": Color(0.10, 0.05, 0.05)},
        {"id": "golden", "name": "Golden God", "desc": "Pure gold. Pure filth.", "price": 600, "shine": 0.9,
            "shirt": Color(1.0, 0.80, 0.20), "skin": Color(1.0, 0.85, 0.40), "pants": Color(0.90, 0.65, 0.10)},
    ]


static func skin_def(id: String) -> Dictionary:
    for s in skins():
        if s["id"] == id:
            return s
    return skins()[0]


static func faces() -> Array:
    return [
        {"id": "evil", "name": "Evil Grin", "desc": "The classic. Comes free.", "price": 0},
        {"id": "happy", "name": "Happy Camper", "desc": "Smiling. Suspiciously.", "price": 100},
        {"id": "derp", "name": "Derp", "desc": "Lights are on, nobody home.", "price": 120},
        {"id": "angry", "name": "Grumpy", "desc": "Hasn't had coffee.", "price": 150},
        {"id": "hearts", "name": "Lovestruck", "desc": "Loves everyone. Licks everyone.", "price": 180},
        {"id": "cool", "name": "Too Cool", "desc": "Shades on. Hand dirty.", "price": 200},
        {"id": "villain", "name": "Supervillain", "desc": "Red eyes, razor teeth.", "price": 250},
        {"id": "skull", "name": "Skull", "desc": "Spooky scary.", "price": 300},
    ]


static func accessories() -> Array:
    return [
        {"id": "cap", "name": "Red Cap", "desc": "Backwards? Never.", "price": 100, "slot": "head"},
        {"id": "party_hat", "name": "Party Hat", "desc": "It's always a party.", "price": 120, "slot": "head"},
        {"id": "sunglasses", "name": "Sunglasses", "desc": "Deal with it.", "price": 130, "slot": "eyes"},
        {"id": "top_hat", "name": "Top Hat", "desc": "Fancy filth.", "price": 150, "slot": "head"},
        {"id": "cat_ears", "name": "Cat Ears", "desc": "Nya.", "price": 150, "slot": "head"},
        {"id": "horns", "name": "Devil Horns", "desc": "For the evil grin.", "price": 200, "slot": "head"},
        {"id": "cape", "name": "Hero Cape", "desc": "Not all heroes wash.", "price": 250, "slot": "back"},
        {"id": "crown", "name": "Golden Crown", "desc": "King of the mall.", "price": 400, "slot": "head"},
    ]


static func powerups() -> Array:
    return [
        {"id": "speed", "name": "Turbo Legs", "desc": "+7% run speed per level", "base": 100, "max": 5},
        {"id": "reach", "name": "Long Arms", "desc": "+0.3 m grab reach per level", "base": 120, "max": 4},
        {"id": "stamina", "name": "Iron Lungs", "desc": "Sprint drains 20% slower per level", "base": 90, "max": 5},
        {"id": "stink", "name": "Stink Cloud", "desc": "People near you run slower", "base": 200, "max": 3},
        {"id": "lucky", "name": "Lucky Coins", "desc": "+25% coins per level", "base": 150, "max": 5},
    ]


static func power_cost(item: Dictionary, level: int) -> int:
    return int(item["base"]) * (level + 1)
