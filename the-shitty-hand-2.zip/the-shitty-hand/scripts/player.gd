extends CharacterBody3D
## The player: sits on the toilet during the cutscene, then runs around with a poop hand.
## Also used as the preview model on the home screen.

const Cfg = preload("res://scripts/config.gd")
const Humanoid = preload("res://scripts/humanoid.gd")
const Items = preload("res://scripts/items.gd")

signal ultra_landed(pos: Vector3)

var move_input := Vector2.ZERO     # world-space x/z direction, length 0..1 (set by game.gd)
var sprint_held := false
var stamina := 1.0
var exhausted := false
var sitting := true
var locked := false                # true during the ultra attack
var holding_poop := false
var fp := false                    # first person: hide our own body

var assets
var body: Node3D
var torso: MeshInstance3D
var head: MeshInstance3D
var face_mi: MeshInstance3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l_mesh: MeshInstance3D
var arm_r_mesh: MeshInstance3D
var leg_l_mesh: MeshInstance3D
var leg_r_mesh: MeshInstance3D
var hand_l: Dictionary
var hand_r: Dictionary
var acc_nodes: Array = []
var face_override := ""
var stink_fx: CPUParticles3D = null
var anim_t := 0.0
var grab_t := 0.0
var cur_speed := 0.0
var curl_pose := -1.0              # >= 0: cutscene controls the finger curl
var ultra_state := 0               # 0 none, 1 rising, 2 hanging, 3 slamming, 4 sitting on the ground
var ultra_t := 0.0
var ultra_h := 6.0


func setup(a) -> void:
    assets = a
    collision_layer = 4
    collision_mask = 1
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.32
    cap.height = 1.7
    cs.shape = cap
    cs.position = Vector3(0, 0.85, 0)
    add_child(cs)

    var parts: Dictionary = Humanoid.build(a, self, a.skins[1], a.skins[1], a.skins[1], true, true, "evil")
    body = parts["body"]
    torso = parts["torso"]
    head = parts["head"]
    face_mi = parts["face"]
    arm_l = parts["arm_l"]
    arm_r = parts["arm_r"]
    arm_l_mesh = parts["arm_l_mesh"]
    arm_r_mesh = parts["arm_r_mesh"]
    leg_l = parts["leg_l"]
    leg_r = parts["leg_r"]
    leg_l_mesh = parts["leg_l_mesh"]
    leg_r_mesh = parts["leg_r_mesh"]
    hand_l = parts["hand_l"]
    hand_r = parts["hand_r"]
    apply_outfit()
    set_sitting(true)
    _set_curl(hand_l, 0.25)
    _set_curl(hand_r, 0.2)


## Applies the equipped skin, face and accessories (from Store).
func apply_outfit() -> void:
    var def: Dictionary = Items.skin_def(Store.equipped["skin"])
    var mats: Array = assets.skin_materials(def)
    torso.material_override = mats[0]
    head.material_override = mats[1]
    arm_l_mesh.material_override = mats[1]
    arm_r_mesh.material_override = mats[1]
    leg_l_mesh.material_override = mats[2]
    leg_r_mesh.material_override = mats[2]
    for m in hand_l["meshes"]:
        m.material_override = mats[1]
    for m in hand_r["meshes"]:
        m.material_override = assets.poop if holding_poop else mats[1]
    _refresh_face()

    for n in acc_nodes:
        if is_instance_valid(n):
            n.queue_free()
    acc_nodes.clear()
    for slot in ["head", "eyes", "back"]:
        var id: String = String(Store.equipped.get(slot, ""))
        if id == "":
            continue
        var node: Node3D = Humanoid.build_accessory(assets, id)
        if slot == "back":
            body.add_child(node)
        else:
            head.add_child(node)
        acc_nodes.append(node)


func _refresh_face() -> void:
    var id: String = face_override if face_override != "" else String(Store.equipped["face"])
    face_mi.material_override = assets.face_mat(id)


func set_face_override(id: String) -> void:
    face_override = id
    _refresh_face()


func set_first_person(b: bool) -> void:
    fp = b
    torso.visible = not b
    head.visible = not b
    leg_l.visible = not b
    leg_r.visible = not b
    arm_l.visible = not b


func face_angle(rad: float) -> void:
    rotation.y = rad


func face_point(p: Vector3) -> void:
    var d := p - position
    rotation.y = atan2(-d.x, -d.z)


func set_sitting(b: bool) -> void:
    sitting = b
    body.rotation.x = 0.0
    head.rotation.y = 0.0
    arm_l.rotation.z = 0.0
    arm_r.rotation.z = 0.0
    if b:
        body.position.y = -0.38
        leg_l.rotation.x = 1.25
        leg_r.rotation.x = 1.25
        arm_l.rotation.x = 0.5
        arm_r.rotation.x = 0.5
    else:
        body.position.y = 0.0
        leg_l.rotation.x = 0.0
        leg_r.rotation.x = 0.0
        arm_l.rotation.x = 0.0
        arm_r.rotation.x = 0.0
        curl_pose = -1.0


## Cutscene poses (lean = body lean, head_yaw, left arm x/z, right arm x/z, right-hand finger curl).
func set_pose(lean: float, head_yaw: float, al_x: float, al_z: float, ar_x: float, ar_z: float, curl: float) -> void:
    body.rotation.x = lean
    head.rotation.y = head_yaw
    arm_l.rotation.x = al_x
    arm_l.rotation.z = al_z
    arm_r.rotation.x = ar_x
    arm_r.rotation.z = ar_z
    curl_pose = curl
    _set_curl(hand_r, curl)


## Ultra attack poses. stage 0 = arms up, legs tucked (in the air); 1 = sitting on the ground.
func ultra_pose(stage: int) -> void:
    if stage == 0:
        body.position.y = 0.0
        arm_l.rotation.x = 3.0
        arm_r.rotation.x = 3.0
        leg_l.rotation.x = 1.0
        leg_r.rotation.x = 0.6
        _set_curl(hand_r, 0.9)
    else:
        body.position.y = -0.38
        leg_l.rotation.x = 1.25
        leg_r.rotation.x = 1.25
        arm_l.rotation.x = 0.6
        arm_r.rotation.x = 0.6
        _set_curl(hand_r, 0.2)


func _set_curl(hand: Dictionary, curl: float) -> void:
    var fingers: Array = hand["fingers"]
    for i in fingers.size():
        var f: Node3D = fingers[i]
        f.rotation.x = curl * (0.6 if i == 4 else 1.0)


func give_poop_hand() -> void:
    holding_poop = true
    for m in hand_r["meshes"]:
        m.material_override = assets.poop
    var blob: MeshInstance3D = hand_r["blob"]
    blob.visible = true
    if stink_fx != null:
        return
    var p := CPUParticles3D.new()
    p.amount = 14
    p.lifetime = 1.4
    p.local_coords = false
    p.direction = Vector3.UP
    p.spread = 30.0
    p.gravity = Vector3(0, 0.3, 0)
    p.initial_velocity_min = 0.2
    p.initial_velocity_max = 0.5
    p.scale_amount_min = 0.6
    p.scale_amount_max = 1.2
    var sm := SphereMesh.new()
    sm.radius = 0.035
    sm.height = 0.07
    sm.radial_segments = 6
    sm.rings = 3
    p.mesh = sm
    p.material_override = assets.stink
    p.position = Vector3(0, -0.75, 0)
    arm_r.add_child(p)
    stink_fx = p


func do_grab_anim() -> void:
    grab_t = 0.3


func is_busy() -> bool:
    return ultra_state != 0


## World position of the poop hand (where thrown poop starts).
func hand_world_pos() -> Vector3:
    var root: Node3D = hand_r["root"]
    return root.global_position


## ULTRA: jump really high, slam down on your butt. Emits ultra_landed(pos) on impact.
func start_ultra(h: float) -> void:
    ultra_state = 1
    ultra_t = 0.0
    ultra_h = h
    velocity = Vector3.ZERO
    ultra_pose(0)


func _update_ultra(delta: float) -> void:
    ultra_t += delta
    match ultra_state:
        1:
            var kr: float = clampf(ultra_t / 0.65, 0.0, 1.0)
            position.y = ultra_h * sin(kr * PI * 0.5)
            if kr >= 1.0:
                ultra_state = 2
                ultra_t = 0.0
        2:
            position.y = ultra_h
            if ultra_t >= 0.25:
                ultra_state = 3
                ultra_t = 0.0
        3:
            var ks: float = clampf(ultra_t / 0.22, 0.0, 1.0)
            position.y = ultra_h * (1.0 - ks * ks)
            if ks >= 1.0:
                position.y = 0.0
                ultra_state = 4
                ultra_t = 0.0
                ultra_pose(1)
                ultra_landed.emit(position)
        4:
            if ultra_t >= 0.9:
                ultra_state = 0
                set_sitting(false)


func _physics_process(delta: float) -> void:
    if ultra_state != 0:
        _update_ultra(delta)
        return
    if sitting or locked:
        return
    var moving: bool = move_input.length() > 0.08
    var want_sprint: bool = sprint_held and moving and (not exhausted) and stamina > 0.0
    if want_sprint:
        stamina = maxf(0.0, stamina - delta * 0.28 * Store.stamina_mult())
        if stamina <= 0.0:
            exhausted = true
    else:
        stamina = minf(1.0, stamina + delta * (0.06 if sprint_held else 0.18))
        if exhausted and stamina > 0.35:
            exhausted = false
    var base: float = Cfg.PLAYER_SPRINT if want_sprint else Cfg.PLAYER_WALK
    var speed: float = base * Store.speed_mult()
    cur_speed = speed if moving else 0.0
    velocity = Vector3(move_input.x, 0.0, move_input.y) * (speed if moving else 0.0)
    move_and_slide()
    if moving and not fp:
        var target: float = atan2(-move_input.x, -move_input.y)
        rotation.y = lerp_angle(rotation.y, target, clampf(14.0 * delta, 0.0, 1.0))
    _animate(delta)


func _animate(delta: float) -> void:
    if grab_t > 0.0:
        grab_t -= delta
    var k: float = minf(1.0, 10.0 * delta)
    if cur_speed > 0.1:
        anim_t += delta * (3.0 + cur_speed * 1.3)
        var s: float = sin(anim_t) * 0.85
        leg_l.rotation.x = s
        leg_r.rotation.x = -s
        arm_l.rotation.x = -s
        arm_r.rotation.x = s
    else:
        leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, k)
        leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, k)
        arm_l.rotation.x = lerpf(arm_l.rotation.x, 0.0, k)
        arm_r.rotation.x = lerpf(arm_r.rotation.x, 0.0, k)
    if holding_poop:
        # right arm stays up, poop hand held out in front
        var up: float = 1.55
        if cur_speed > 0.1:
            up += sin(anim_t * 2.0) * 0.08
        var curl: float = 0.22
        if grab_t > 0.0:
            var ph: float = sin(grab_t / 0.3 * PI)
            up += ph * 0.5
            curl += ph * 1.0
        arm_r.rotation.x = up
        _set_curl(hand_r, curl)
