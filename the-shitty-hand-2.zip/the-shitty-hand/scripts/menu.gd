extends Node3D
## Home page: 3D showcase of your character + map picker, PLAY button, wardrobe, open world, settings.

const Assets = preload("res://scripts/assets.gd")
const PlayerScript = preload("res://scripts/player.gd")
const Maps = preload("res://scripts/maps.gd")
const ShopUIScript = preload("res://scripts/shop_ui.gd")

var assets
var player
var maps: Array = []
var t := 0.0

var ui: Control
var map_name: Label
var map_desc: Label
var map_count: Label
var map_chip: ColorRect
var coins_label: Label
var settings_panel: PanelContainer
var people_label: Label
var reset_button: Button
var click_player: AudioStreamPlayer


func _ready() -> void:
    maps = Maps.list()
    Store.selected_map = clampi(Store.selected_map, 0, maps.size() - 1)
    click_player = AudioStreamPlayer.new()
    click_player.stream = load("res://audio/click.wav")
    add_child(click_player)
    _build_scene()
    _build_ui()
    _show_map()


func _process(delta: float) -> void:
    t += delta
    player.face_angle(PI + sin(t * 0.7) * 0.7)
    coins_label.text = "Coins: %d" % Store.coins


# ---------------------------------------------------------------- 3D showcase

func _build_scene() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.06, 0.20, 0.10)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.7, 0.85, 0.7)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-35.0, 20.0, 0.0)
    sun.light_energy = 1.1
    add_child(sun)
    var rim := OmniLight3D.new()
    rim.position = Vector3(-2.0, 2.5, -2.0)
    rim.light_color = Color(0.5, 1.0, 0.5)
    rim.light_energy = 2.0
    rim.omni_range = 8.0
    add_child(rim)

    var ground := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 1.6
    cm.bottom_radius = 1.6
    cm.height = 0.1
    ground.mesh = cm
    var gm := StandardMaterial3D.new()
    gm.albedo_color = Color(0.12, 0.30, 0.14)
    gm.roughness = 0.4
    ground.material_override = gm
    ground.position = Vector3(0, -0.05, 0)
    add_child(ground)

    var cam := Camera3D.new()
    cam.fov = 45.0
    add_child(cam)
    cam.look_at_from_position(Vector3(0.0, 1.35, 4.4), Vector3(0.0, 1.0, 0.0), Vector3.UP)
    cam.make_current()

    assets = Assets.new()
    player = PlayerScript.new()
    player.setup(assets)
    add_child(player)
    player.set_sitting(false)
    player.give_poop_hand()
    player.apply_outfit()


# ---------------------------------------------------------------- UI

func _flat(c: Color, r: int, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = c
    sb.set_corner_radius_all(r)
    if bw > 0:
        sb.border_color = border
        sb.set_border_width_all(bw)
    return sb


func _btn(text: String, cb: Callable, min_size: Vector2 = Vector2(0, 0)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.pressed.connect(_click)
    b.pressed.connect(cb)
    return b


func _click() -> void:
    click_player.play()


func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    ui = Control.new()
    layer.add_child(ui)
    ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var th := Theme.new()
    th.default_font_size = 28
    ui.theme = th

    # title
    var title := Label.new()
    title.text = "THE SHITTY HAND"
    title.add_theme_font_size_override("font_size", 72)
    title.add_theme_color_override("font_color", Color(0.55, 0.85, 0.3))
    title.add_theme_color_override("font_outline_color", Color(0.15, 0.08, 0.02))
    title.add_theme_constant_override("outline_size", 14)
    ui.add_child(title)
    title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 14)

    # coins (top-left)
    coins_label = Label.new()
    coins_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
    ui.add_child(coins_label)
    coins_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 22)

    # settings (top-right)
    var sb := _btn("SETTINGS", _toggle_settings, Vector2(190, 56))
    ui.add_child(sb)
    sb.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 20)

    # map picker (left)
    var mp := PanelContainer.new()
    mp.custom_minimum_size = Vector2(430, 0)
    ui.add_child(mp)
    mp.set_anchors_and_offsets_preset(Control.PRESET_CENTER_LEFT, Control.PRESET_MODE_MINSIZE, 24)
    var mm := MarginContainer.new()
    for side in ["left", "right", "top", "bottom"]:
        mm.add_theme_constant_override("margin_" + side, 16)
    mp.add_child(mm)
    var mv := VBoxContainer.new()
    mv.add_theme_constant_override("separation", 10)
    mm.add_child(mv)
    var hd := Label.new()
    hd.text = "CHOOSE YOUR MAP"
    hd.add_theme_font_size_override("font_size", 24)
    hd.add_theme_color_override("font_color", Color(0.8, 0.8, 0.85))
    mv.add_child(hd)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 10)
    mv.add_child(row)
    row.add_child(_btn("<", _prev_map, Vector2(70, 70)))
    map_name = Label.new()
    map_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    map_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    map_name.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    map_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    map_name.add_theme_font_size_override("font_size", 34)
    row.add_child(map_name)
    row.add_child(_btn(">", _next_map, Vector2(70, 70)))
    map_chip = ColorRect.new()
    map_chip.custom_minimum_size = Vector2(0, 12)
    mv.add_child(map_chip)
    map_desc = Label.new()
    map_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    map_desc.custom_minimum_size = Vector2(0, 90)
    map_desc.add_theme_font_size_override("font_size", 22)
    mv.add_child(map_desc)
    map_count = Label.new()
    map_count.add_theme_font_size_override("font_size", 20)
    map_count.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
    mv.add_child(map_count)

    # wardrobe + open world (bottom-left)
    var bl := VBoxContainer.new()
    bl.add_theme_constant_override("separation", 10)
    ui.add_child(bl)
    bl.add_child(_btn("WARDROBE", _open_wardrobe, Vector2(300, 66)))
    bl.add_child(_btn("OPEN WORLD", _open_world, Vector2(300, 66)))
    bl.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT, Control.PRESET_MODE_MINSIZE, 24)

    # PLAY: green rectangle with poop on it (bottom-right)
    var play := Button.new()
    play.text = "PLAY"
    play.icon = load("res://icons/poop.png")
    play.expand_icon = true
    play.add_theme_constant_override("icon_max_width", 90)
    play.add_theme_constant_override("h_separation", 16)
    play.custom_minimum_size = Vector2(360, 124)
    play.add_theme_font_size_override("font_size", 56)
    play.add_theme_color_override("font_color", Color.WHITE)
    play.add_theme_color_override("font_hover_color", Color.WHITE)
    play.add_theme_color_override("font_pressed_color", Color.WHITE)
    play.add_theme_stylebox_override("normal", _flat(Color(0.16, 0.62, 0.20), 12, Color(0.07, 0.36, 0.10), 5))
    play.add_theme_stylebox_override("hover", _flat(Color(0.22, 0.72, 0.26), 12, Color(0.07, 0.36, 0.10), 5))
    play.add_theme_stylebox_override("pressed", _flat(Color(0.10, 0.48, 0.14), 12, Color(0.07, 0.36, 0.10), 5))
    play.pressed.connect(_click)
    play.pressed.connect(_on_play)
    ui.add_child(play)
    play.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 26)

    _build_settings()


func _build_settings() -> void:
    settings_panel = PanelContainer.new()
    settings_panel.visible = false
    settings_panel.custom_minimum_size = Vector2(760, 0)
    ui.add_child(settings_panel)
    settings_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER, Control.PRESET_MODE_MINSIZE)
    var m := MarginContainer.new()
    for side in ["left", "right", "top", "bottom"]:
        m.add_theme_constant_override("margin_" + side, 22)
    settings_panel.add_child(m)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 14)
    m.add_child(v)

    var t1 := Label.new()
    t1.text = "SETTINGS"
    t1.add_theme_font_size_override("font_size", 40)
    v.add_child(t1)

    people_label = Label.new()
    v.add_child(people_label)
    v.add_child(_slider(10.0, 250.0, 5.0, float(Store.npc_count), _on_people))
    var hint := Label.new()
    hint.text = "Number of people in every map. More than ~200 can lag on older phones."
    hint.add_theme_font_size_override("font_size", 20)
    hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    v.add_child(hint)
    _on_people(float(Store.npc_count))

    var vl := Label.new()
    vl.text = "Volume"
    v.add_child(vl)
    v.add_child(_slider(0.0, 1.0, 0.05, Store.volume, _on_volume))

    var sl := Label.new()
    sl.text = "Look sensitivity"
    v.add_child(sl)
    v.add_child(_slider(0.4, 2.5, 0.1, Store.sens, _on_sens))

    var fp := CheckButton.new()
    fp.text = "Start in first person"
    fp.button_pressed = Store.first_person
    fp.toggled.connect(_on_fp)
    v.add_child(fp)

    reset_button = _btn("Reset all progress", _on_reset)
    v.add_child(reset_button)
    v.add_child(_btn("CLOSE", _toggle_settings, Vector2(0, 64)))


func _slider(mn: float, mx: float, step: float, val: float, cb: Callable) -> HSlider:
    var s := HSlider.new()
    s.min_value = mn
    s.max_value = mx
    s.step = step
    s.value = val
    s.custom_minimum_size = Vector2(0, 44)
    s.value_changed.connect(cb)
    return s


func _on_people(v: float) -> void:
    Store.npc_count = int(v)
    people_label.text = "People per map: %d" % Store.npc_count


func _on_volume(v: float) -> void:
    Store.volume = v
    Store.apply_volume()


func _on_sens(v: float) -> void:
    Store.sens = v


func _on_fp(on: bool) -> void:
    Store.first_person = on


func _on_reset() -> void:
    if reset_button.text == "Reset all progress":
        reset_button.text = "Tap again to really reset"
        return
    Store.reset_all()
    reset_button.text = "Reset all progress"
    player.apply_outfit()


func _toggle_settings() -> void:
    settings_panel.visible = not settings_panel.visible
    reset_button.text = "Reset all progress"
    Store.save_data()


# ---------------------------------------------------------------- actions

func _show_map() -> void:
    var m: Dictionary = maps[Store.selected_map]
    map_name.text = String(m["name"])
    map_desc.text = String(m["desc"])
    map_chip.color = m["accent"]
    map_count.text = "Map %d / %d" % [Store.selected_map + 1, maps.size()]


func _prev_map() -> void:
    Store.selected_map = (Store.selected_map + maps.size() - 1) % maps.size()
    _show_map()


func _next_map() -> void:
    Store.selected_map = (Store.selected_map + 1) % maps.size()
    _show_map()


func _on_play() -> void:
    Store.mode = "round"
    Store.save_data()
    get_tree().change_scene_to_file("res://scenes/main.tscn")


func _open_world() -> void:
    Store.mode = "open"
    Store.save_data()
    get_tree().change_scene_to_file("res://scenes/main.tscn")


func _open_wardrobe() -> void:
    var s = ShopUIScript.new()
    s.setup("WARDROBE", ["skins", "faces", "acc"], false)
    s.changed.connect(player.apply_outfit)
    add_child(s)
