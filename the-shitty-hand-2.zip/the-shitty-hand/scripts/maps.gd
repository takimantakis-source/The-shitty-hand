extends RefCounted
## The 10 round maps + the open world. The layouts themselves live in world_builder.gd.


static func _d(name: String, desc: String, layout: String, hx: float, hz: float, indoor: bool,
        floor_kind: String, floor_tint: Color, wall: Color, accent: Color, extra: Dictionary = {}) -> Dictionary:
    var d := {
        "name": name, "desc": desc, "layout": layout, "hx": hx, "hz": hz, "indoor": indoor,
        "floor_kind": floor_kind, "floor_tint": floor_tint, "wall": wall, "accent": accent,
        "floor_rough": 0.3,
        "light_color": Color(1.0, 0.95, 0.86), "light_energy": 1.3, "ambient": 0.9, "sun": 0.7,
        "panel": Color(1.0, 0.97, 0.9), "ceiling": Color(0.95, 0.95, 0.95),
        "sky_top": Color(0.55, 0.65, 0.80), "sky_horizon": Color(0.80, 0.82, 0.85),
        "omni_colors": [],
    }
    for k in extra:
        d[k] = extra[k]
    return d


static func open_world() -> Dictionary:
    return _d("Poopville", "The open world.", "open", 85.0, 85.0, false, "noise",
        Color(0.30, 0.62, 0.26), Color(0.20, 0.50, 0.20), Color(1.0, 0.8, 0.3),
        {"ambient": 1.0, "sun": 1.1, "sky_top": Color(0.35, 0.60, 0.95), "sky_horizon": Color(0.75, 0.88, 1.0)})


static func list() -> Array:
    return [
        _d("Mega Mall", "The original. Shops, a fountain and 80 x 60 m of panic.", "mall", 40.0, 30.0, true, "tile",
            Color(0.86, 0.84, 0.80), Color(0.93, 0.91, 0.87), Color(1.0, 0.70, 0.20)),
        _d("Sky Airport", "Check-in counters, gates and a very long hall.", "airport", 50.0, 24.0, true, "tile",
            Color(0.80, 0.85, 0.92), Color(0.90, 0.93, 0.97), Color(0.30, 0.60, 1.0),
            {"light_color": Color(0.90, 0.95, 1.0)}),
        _d("Metro Station", "A parked train, pillars and bad lighting.", "metro", 45.0, 18.0, true, "tile",
            Color(0.55, 0.58, 0.55), Color(0.50, 0.55, 0.50), Color(0.20, 0.80, 0.50),
            {"light_color": Color(0.80, 1.0, 0.85), "light_energy": 1.0, "ambient": 0.6, "sun": 0.3}),
        _d("Super Saver Market", "Long aisles of shelves. Hide-and-seek heaven.", "market", 36.0, 28.0, true, "tile",
            Color(0.95, 0.95, 0.90), Color(0.95, 0.95, 0.92), Color(0.95, 0.30, 0.30)),
        _d("St. Hospital", "Wards, beds and a reception desk.", "hospital", 44.0, 24.0, true, "tile",
            Color(0.75, 0.88, 0.90), Color(0.95, 0.97, 0.97), Color(0.30, 0.85, 0.70),
            {"light_color": Color(0.92, 1.0, 1.0)}),
        _d("Doom High School", "Classrooms, lockers and a cafeteria.", "school", 40.0, 26.0, true, "tile",
            Color(0.70, 0.65, 0.50), Color(0.85, 0.80, 0.60), Color(0.95, 0.80, 0.20)),
        _d("Funland Park", "Outdoors! Ferris wheel, carousel and snack stalls.", "funland", 50.0, 36.0, false, "noise",
            Color(0.35, 0.65, 0.30), Color(0.75, 0.55, 0.35), Color(1.0, 0.40, 0.70),
            {"ambient": 1.0, "sun": 1.2, "floor_rough": 0.9,
             "sky_top": Color(0.35, 0.60, 0.95), "sky_horizon": Color(0.75, 0.88, 1.0)}),
        _d("Sunny Beach", "Sand, umbrellas, palm trees and the sea.", "beach", 55.0, 32.0, false, "noise",
            Color(0.93, 0.85, 0.60), Color(0.85, 0.70, 0.50), Color(0.20, 0.80, 0.90),
            {"ambient": 1.0, "sun": 1.3, "floor_rough": 0.95,
             "sky_top": Color(0.30, 0.60, 1.0), "sky_horizon": Color(0.80, 0.92, 1.0)}),
        _d("Neon Casino", "Dark, loud and glowing. Slot machines everywhere.", "casino", 42.0, 30.0, true, "tile",
            Color(0.35, 0.08, 0.14), Color(0.14, 0.06, 0.18), Color(1.0, 0.20, 0.70),
            {"light_energy": 1.1, "ambient": 0.35, "sun": 0.0, "panel": Color(1.0, 0.3, 0.8),
             "ceiling": Color(0.08, 0.04, 0.10),
             "omni_colors": [Color(1.0, 0.2, 0.7), Color(0.2, 0.9, 1.0), Color(1.0, 0.8, 0.2)]}),
        _d("Orbit Station", "Zero-G vibes. Crates, planters and a view of space.", "station", 46.0, 26.0, true, "tile",
            Color(0.35, 0.40, 0.50), Color(0.30, 0.33, 0.40), Color(0.30, 0.80, 1.0),
            {"light_color": Color(0.7, 0.9, 1.0), "light_energy": 1.2, "ambient": 0.5, "sun": 0.0,
             "panel": Color(0.5, 0.9, 1.0), "ceiling": Color(0.15, 0.17, 0.22), "floor_rough": 0.25}),
    ]
