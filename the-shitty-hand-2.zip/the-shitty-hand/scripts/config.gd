extends RefCounted
## Central tuning knobs. Change a number here to rebalance the game.
## (People count, volume etc. are player settings now - see Store / the Settings screen.)

const PLAYER_WALK := 5.2           # m/s
const PLAYER_SPRINT := 7.4
const GRAB_RANGE := 2.1            # how close a victim must be
const GRAB_COOLDOWN := 0.7
const EVERY_NTH_IS_INFECTED := 3   # every 3rd catch is infected instead of killed
const DUMB_CHANCE := 0.35          # share of infected that run into walls and die
const NPC_NOTICE_RADIUS := 15.0    # people start fleeing when you are this close
const NPC_CALM_RADIUS := 28.0      # ...and calm down when you are this far
const NPC_CAST_SHADOWS := false    # true = prettier, much slower on phones

const ULTRA_NEED := 5              # catches (kills/infections) needed for the ultra attack
const FREEZE_TIME := 5.0           # seconds everybody stays frozen after the ultra
const THROW_COOLDOWN := 0.6
const THROW_SPEED := 24.0
const THROW_GRAVITY := 7.0
const INFECTION_LIFESPAN := 25.0   # open world only: infected die after this many seconds
