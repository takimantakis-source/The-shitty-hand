# The Shitty Hand

A silly 3D gross-out chase game for Android, made with **Godot 4.3+** (GDScript, Mobile renderer).

You're mid-poop in a public toilet. No toilet paper. You wipe with your hand, walk out with an evil grin,
and chase everybody. Escape the map, then roam the **open world**, earn coins and buy stuff.

## Features

- **Home page** with a 3D preview of your character, **10 maps** to choose from, Settings, Wardrobe,
  Open World and the big green **PLAY** button (bottom right).
- **10 maps**: Mega Mall, Sky Airport, Metro Station, Super Saver Market, St. Hospital, Doom High School,
  Funland Park, Sunny Beach, Neon Casino, Orbit Station.
- **Animated cutscene** at the start of every round (sit, no toilet paper, look at your hand, wipe, evil grin). Tap SKIP to skip it.
- **Rules**: catch people with **GRAB** (they lick your hand and die). Every 3rd catch is infected instead and hunts for you.
  Some infected are dumb and run into walls. The exit opens when nobody healthy is left.
- **Throw poop** (THROW button) with light aim assist. A hit counts as a catch.
- **ULTRA attack**: after 5 catches the ULTRA button lights up. You jump really high, land on your butt and
  **everyone is frozen for 5 seconds**.
- Your poop hand has **5 fingers**, your character has an **evil smile**, and there's a **first-person** mode (1P/3P button).
- **Open world (Poopville)**: parks, houses, a fountain and 4 shops - skins, faces (happy, villain, skull, ...),
  accessories (hats, crown, sunglasses, cape, ...) and power-ups (speed, reach, stamina, stink cloud, lucky coins).
  Tap the **house icon** (top right) any time to go back to the home page.
- **Settings**: number of people (10-250), volume, look sensitivity, first person by default.
- Progress (coins, items, settings) is saved on the device.
- 17 synthesized **sound effects** (3D positional for people).

## Controls

| | Touch | Keyboard (desktop testing) |
|---|---|---|
| Move | left thumb joystick | WASD |
| Look | drag on the right side | arrow keys |
| Grab | GRAB | Space |
| Throw poop | THROW | F |
| Ultra (when charged) | ULTRA | U |
| Sprint | RUN (uses stamina) | Shift |
| 1st / 3rd person | 1P/3P button | V |
| Enter shop | button at the bottom | E |

## Run it

1. Install [Godot 4.3 or newer](https://godotengine.org/download) (the normal build, not .NET).
2. Project Manager -> Import -> select `project.godot` -> Run (F5).

Maps are built from code at startup, so a round takes a moment to load. If it is slow on a phone, lower the
number of people in Settings.

## Build the Android APK

1. In Godot: Editor -> Manage Export Templates -> download for your version.
2. Install a JDK (17) and the Android SDK (Android Studio is the easiest way).
3. Editor -> Editor Settings -> Export -> Android: set the Android SDK path, the JDK path and a debug keystore.
   Create a debug keystore once with:
   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ```
4. Project -> Export -> Android. Change `Package > Unique Name` (currently `com.example.theshittyhand`) to your own.
5. Export Project (APK), or plug in a phone with USB debugging and use the one-click deploy button.

Official guide: <https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html>

## Automatic APK builds (GitHub Actions)

`.github/workflows/build-android.yml` builds a **debug-signed APK** on every push/PR and uploads it as a
workflow artifact (Actions tab -> run -> Artifacts). Push a tag like `v1.0.0` and the APK is also attached to a Release:

```
git tag v1.0.0
git push origin v1.0.0
```

It uses the `barichello/godot-ci:4.3` Docker image. Debug-signed APKs install on any phone (allow "install unknown apps")
but can't be uploaded to Google Play - that needs your own release keystore.

## Publish on GitHub

```
git init
git add .
git commit -m "The Shitty Hand"
git branch -M main
git remote add origin https://github.com/<you>/the-shitty-hand.git
git push -u origin main
```

`*.apk` is git-ignored: upload the exported APK under **Releases** instead.

## Project layout

```
scenes/menu.tscn, main.tscn   home page / game scene (both just load a script)
scripts/menu.gd               home page: map picker, settings, wardrobe, PLAY
scripts/game.gd               round + open-world logic, cutscene, throwing, ultra, shops
scripts/world_builder.gd      procedural maps (10 layouts) + the open world
scripts/maps.gd               map definitions / themes
scripts/player.gd             player model, animation, first person, ultra jump
scripts/npc.gd                people: wander, flee, lick, die, infected AI, freezing
scripts/humanoid.gd           builds people: 5-finger hand, face decals, accessories
scripts/assets.gd             shared materials/meshes, procedural textures
scripts/items.gd, store.gd    shop catalog, save data + settings (autoload "Store")
scripts/shop_ui.gd            shop / wardrobe screen
scripts/hud.gd                touch controls + HUD (drawn in code)
scripts/sfx.gd                sound manager (3D + 2D pools, ambient loop)
scripts/config.gd             balance numbers
audio/, faces/, icons/        generated sounds, face decals, app icons
tools/                        make_sounds.py (numpy), make_faces.py + make_icons.py (Pillow)
```

## Notes

- Graphics: PBR materials, reflective floors, bloom, filmic tonemapping. People are low-poly primitives -
  for a more realistic look swap `humanoid.gd` for CC0 character models (Quaternius, Kenney, Mixamo).
- All shop names are fictional. The humor is crude cartoon gross-out - check store policies before publishing to
  Google Play; GitHub Releases / sideloading is the easy route.

MIT licensed (see `LICENSE`).
