#!/usr/bin/env python3
"""Synthesizes all sound effects into ../audio/*.wav (16-bit mono, 22.05 kHz).
Needs numpy:  pip install numpy      Run:  python3 tools/make_sounds.py
Every sound is generated from scratch, so there are no licensing issues."""
import os
import wave
import numpy as np

SR = 22050
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "audio")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(1234)
TAU = 2 * np.pi


def tt(dur):
    return np.arange(int(SR * dur)) / SR


def noise(dur):
    return rng.uniform(-1, 1, int(SR * dur))


def lowpass(x, cutoff):
    """One-pole low-pass. cutoff may be a scalar or an array (Hz) per sample."""
    cutoff = np.broadcast_to(np.asarray(cutoff, dtype=float), x.shape)
    a = 1.0 - np.exp(-TAU * cutoff / SR)
    y = np.empty_like(x)
    s = 0.0
    for i in range(len(x)):
        s += a[i] * (x[i] - s)
        y[i] = s
    return y


def env(t, attack=0.01, decay=5.0):
    return np.minimum(1.0, t / max(attack, 1e-4)) * np.exp(-decay * t)


def sweep(t, f0, f1, curve=1.0):
    """Sine with frequency gliding f0 -> f1 over the sound's length."""
    k = (t / t[-1]) ** curve
    f = f0 + (f1 - f0) * k
    return np.sin(TAU * np.cumsum(f) / SR)


def bubble(dur, f0, f1, decay=18.0):
    t = tt(dur)
    return sweep(t, f0, f1) * env(t, 0.004, decay)


def place(buf, snd, at):
    i = int(at * SR)
    end = min(len(buf), i + len(snd))
    if end > i:
        buf[i:end] += snd[: end - i]


def save(name, x, peak=0.8):
    x = np.asarray(x, dtype=float)
    m = np.max(np.abs(x))
    if m > 0:
        x = x / m * peak
    data = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    print(f"{name}.wav  {len(x) / SR:.2f}s")


# ------------------------------------------------------------------ sounds

def plop():
    buf = np.zeros(int(SR * 0.5))
    place(buf, bubble(0.18, 520, 140, 16), 0.0)
    place(buf, 0.5 * bubble(0.12, 700, 260, 22), 0.22)
    return buf


def squelch():
    dur = 0.9
    t = tt(dur)
    n = lowpass(noise(dur), 500 + 300 * np.sin(TAU * 7 * t))
    wob = 0.5 + 0.5 * np.sin(TAU * 17 * t + 1.0)
    base = n * wob * np.minimum(1, t / 0.03) * np.exp(-2.2 * np.maximum(0, t - 0.4))
    buf = base * 2.0
    for at, f0, f1 in [(0.05, 260, 110), (0.25, 330, 120), (0.48, 220, 90), (0.62, 280, 100)]:
        place(buf, 0.8 * bubble(0.14, f0, f1, 20), at)
    return buf


def lick():
    dur = 0.65
    t = tt(dur)
    n = lowpass(noise(dur), 900 + 700 * np.sin(TAU * 5 * t))
    buf = n * (0.5 + 0.5 * np.sin(TAU * 11 * t)) * np.minimum(1, t / 0.02) * np.exp(-3.0 * t) * 2.2
    place(buf, 0.9 * bubble(0.1, 420, 900, 20), 0.12)
    place(buf, 0.9 * bubble(0.09, 380, 800, 24), 0.32)
    place(buf, 0.8 * bubble(0.12, 700, 220, 18), 0.46)
    return buf


def scream():
    dur = 0.7
    t = tt(dur)
    glide = 650 + 500 * np.sin(np.pi * np.minimum(1, t / 0.5) * 0.5) - 120 * np.maximum(0, t - 0.5)
    vib = 35 * np.sin(TAU * 7 * t)
    ph = np.cumsum(glide + vib) * TAU / SR
    x = sum((1.0 / k) * np.sin(k * ph) for k in range(1, 9))
    x = lowpass(x, 2800) + 0.12 * lowpass(noise(dur), 3500)
    return x * np.minimum(1, t / 0.03) * np.exp(-2.5 * np.maximum(0, t - 0.25))


def thud():
    dur = 0.3
    t = tt(dur)
    return sweep(t, 110, 40) * env(t, 0.002, 14) + 0.7 * lowpass(noise(dur), 350) * env(t, 0.001, 40)


def bonk():
    dur = 0.55
    t = tt(dur)
    wood = (np.sin(TAU * 540 * t) * 0.8 + np.sin(TAU * 1080 * t) * 0.3) * env(t, 0.001, 30)
    boing = sweep(t, 220, 120) * env(t, 0.002, 7) * (0.7 + 0.3 * np.sin(TAU * 22 * t))
    hit = lowpass(noise(dur), 800) * env(t, 0.001, 60)
    return wood + 0.9 * boing + 0.6 * hit


def groan():
    dur = 1.0
    t = tt(dur)
    f0 = 95 - 30 * (t / dur) + 4 * np.sin(TAU * 5 * t)
    ph = np.cumsum(f0) * TAU / SR
    x = np.zeros_like(t)
    for k in range(1, 30):
        fk = k * f0
        w = np.exp(-((fk - 520) / 260.0) ** 2) + 0.5 * np.exp(-((fk - 1100) / 300.0) ** 2)
        x += w * np.sin(k * ph)
    x = x * (0.6 + 0.4 * np.sin(TAU * 31 * t)) + 0.25 * lowpass(noise(dur), 700)
    return x * np.minimum(1, t / 0.12) * np.exp(-3.0 * np.maximum(0, t - 0.55))


def door():
    dur = 1.0
    t = tt(dur)
    f = 180 + 520 * (t / dur) ** 1.4 + 25 * np.sin(TAU * 9 * t)
    ph = np.cumsum(f) * TAU / SR
    saw = sum((1.0 / k) * np.sin(k * ph) for k in range(1, 7))
    stick = 0.35 + 0.65 * np.abs(np.sin(TAU * 38 * t + 0.4 * np.sin(TAU * 3 * t)))
    buf = 0.7 * lowpass(saw, 1800) * stick * np.minimum(1, t / 0.08) * np.exp(-3.0 * np.maximum(0, t - 0.7))
    place(buf, 1.2 * lowpass(noise(0.04), 4000) * env(tt(0.04), 0.0005, 120), 0.0)
    return buf


def whoosh():
    dur = 0.28
    t = tt(dur)
    return lowpass(noise(dur), 300 + 3500 * np.sin(np.pi * t / dur)) * np.sin(np.pi * t / dur) ** 1.5


def exit_open():
    buf = np.zeros(int(SR * 1.6))
    for i, f in enumerate([1046.5, 1318.5, 1568.0, 2093.0]):
        t = tt(1.0)
        bell = (np.sin(TAU * f * t) + 0.35 * np.sin(TAU * f * 2.01 * t) + 0.15 * np.sin(TAU * f * 3.2 * t)) * env(t, 0.004, 4.5)
        place(buf, bell, 0.13 * i)
    return buf


def win():
    buf = np.zeros(int(SR * 2.2))
    notes = [(523.25, 0.0, 0.18), (659.25, 0.18, 0.18), (783.99, 0.36, 0.18), (1046.5, 0.54, 0.5),
             (783.99, 1.1, 0.16), (1046.5, 1.26, 0.8)]
    for f, at, d in notes:
        t = tt(d + 0.25)
        tone = np.sin(TAU * f * t) + 0.5 * np.sin(TAU * 2 * f * t) + 0.25 * np.sin(TAU * 3 * f * t)
        place(buf, tone * np.minimum(1, t / 0.01) * np.where(t < d, 1.0, np.exp(-14 * (t - d))), at)
    return buf


def ambient():
    """4 s seamless loop: low mall hum + soft air noise + very faint muzak."""
    dur = 4.0
    t = tt(dur)
    hum = (np.sin(TAU * 60 * t) * 0.5 + np.sin(TAU * 120 * t) * 0.25 + np.sin(TAU * 180.25 * t) * 0.1
           + np.sin(TAU * 7.5 * t) * 0.3)
    n = len(t)
    f = int(0.3 * SR)                       # crossfade tail into head so the noise loops cleanly
    long_air = lowpass(noise(dur + 0.3), 900)
    air_loop = long_air[:n].copy()
    ramp = np.linspace(0, 1, f)
    air_loop[:f] = long_air[:f] * ramp + long_air[n:n + f] * (1 - ramp)
    x = hum * 0.5 + air_loop * 1.2
    mus = np.zeros(n)
    for i, fq in enumerate([392.0, 493.9, 587.3, 493.9]):
        tn = tt(1.0)
        place(mus, np.sin(TAU * fq * tn) * env(tn, 0.05, 2.5), i * 1.0)
    return x + 0.05 * lowpass(mus, 1200)


def click():
    t = tt(0.06)
    return lowpass(noise(0.06), 3500) * env(t, 0.0005, 90) + 0.6 * np.sin(TAU * 1300 * t) * env(t, 0.0005, 70)


def coin():
    buf = np.zeros(int(SR * 0.55))
    for f, at in [(1318.5, 0.0), (1760.0, 0.09)]:
        t = tt(0.45)
        place(buf, (np.sin(TAU * f * t) + 0.3 * np.sin(TAU * f * 2.7 * t)) * env(t, 0.002, 8), at)
    return buf


def splat():
    dur = 0.45
    t = tt(dur)
    wet = lowpass(noise(dur), 1300) * env(t, 0.002, 18) * (0.6 + 0.4 * np.sin(TAU * 40 * t))
    buf = wet * 1.8
    place(buf, bubble(0.12, 320, 90, 16), 0.02)
    place(buf, 0.7 * bubble(0.1, 240, 80, 20), 0.14)
    place(buf, 0.6 * sweep(tt(0.2), 140, 50) * env(tt(0.2), 0.002, 14), 0.0)
    return buf


def boom():
    dur = 1.1
    t = tt(dur)
    low = sweep(t, 90, 28) * env(t, 0.004, 3.5)
    rumble = lowpass(noise(dur), 300) * env(t, 0.003, 5.0)
    crack = lowpass(noise(0.12), 5000) * env(tt(0.12), 0.0005, 45)
    buf = low + 1.2 * rumble
    place(buf, 1.0 * crack, 0.0)
    return buf


def freeze():
    dur = 1.1
    t = tt(dur)
    buf = np.zeros(len(t))
    for f, at in [(2093.0, 0.00), (2637.0, 0.06), (3136.0, 0.12), (3951.0, 0.20), (3322.0, 0.30), (4186.0, 0.42)]:
        tn = tt(0.5)
        place(buf, (np.sin(TAU * f * tn) + 0.4 * np.sin(TAU * f * 1.5 * tn)) * env(tn, 0.002, 7) * 0.5, at)
    hiss = noise(dur) - lowpass(noise(dur), 3500)
    buf += 0.25 * hiss * env(t, 0.05, 3.0) * (0.6 + 0.4 * np.sin(TAU * 18 * t))
    buf += 0.4 * sweep(t, 1400, 500) * env(t, 0.02, 4.0)
    return buf


SOUNDS = [("plop", plop, 0.8), ("squelch", squelch, 0.85), ("lick", lick, 0.85),
          ("scream", scream, 0.7), ("thud", thud, 0.9), ("bonk", bonk, 0.85),
          ("groan", groan, 0.8), ("door", door, 0.7), ("whoosh", whoosh, 0.5),
          ("exit_open", exit_open, 0.7), ("win", win, 0.7), ("ambient", ambient, 0.35),
          ("click", click, 0.6), ("coin", coin, 0.65), ("splat", splat, 0.85),
          ("boom", boom, 0.95), ("freeze", freeze, 0.7)]

if __name__ == "__main__":
    for name, fn, pk in SOUNDS:
        save(name, fn(), pk)
