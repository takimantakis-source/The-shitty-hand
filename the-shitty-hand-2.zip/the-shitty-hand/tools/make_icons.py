#!/usr/bin/env python3
"""Generates the app icons into ../icons and ../icon.png.  Needs Pillow:  pip install pillow
(The face decals and the poop button icon come from make_faces.py.)"""
import math
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
OUT = os.path.join(ROOT, "icons")
os.makedirs(OUT, exist_ok=True)

SKIN = (244, 196, 156, 255)
SKIN_LINE = (96, 52, 28, 255)
POOP = (104, 62, 24, 255)
POOP_DARK = (50, 27, 10, 255)
POOP_LIGHT = (160, 106, 52, 255)
STINK = (160, 225, 70, 235)


def background(size):
    grad = Image.radial_gradient("L").resize((size, size), Image.LANCZOS)
    inner = Image.new("RGB", (size, size), (96, 176, 62))
    outer = Image.new("RGB", (size, size), (12, 44, 22))
    return Image.composite(outer, inner, grad).convert("RGBA")


def hand(size, scale, shift=0.0):
    """A cartoon hand (5 fingers) with a poop smear. Drawn in a 1000x1000 design space."""
    S = size * 2
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    k = S / 1000.0

    def X(x): return (500 + (x - 500) * scale) * k
    def Y(y): return (500 + (y - 500 + shift) * scale) * k
    def R(v): return v * scale * k

    def rrect(x0, y0, x1, y1, r, fill, infl=0):
        d.rounded_rectangle([X(x0) - R(infl), Y(y0) - R(infl), X(x1) + R(infl), Y(y1) + R(infl)],
                            radius=R(r + infl), fill=fill)

    def ell(x0, y0, x1, y1, fill, infl=0):
        d.ellipse([X(x0) - R(infl), Y(y0) - R(infl), X(x1) + R(infl), Y(y1) + R(infl)], fill=fill)

    fingers = [(300, 250), (390, 170), (480, 205), (570, 295)]
    for infl, col in ((16, SKIN_LINE), (0, SKIN)):
        rrect(300, 400, 700, 745, 120, col, infl)
        for fx, top in fingers:
            rrect(fx, top, fx + 84, 480, 42, col, infl)
        w = 92 + 2 * infl
        d.line([(X(330), Y(650)), (X(205), Y(480))], fill=col, width=int(R(w)))
        ell(205 - 46, 480 - 46, 205 + 46, 480 + 46, col, infl)
        ell(330 - 46, 650 - 46, 330 + 46, 650 + 46, col, infl)

    tiers = [(300, 615, 700, 745), (345, 535, 655, 640), (395, 465, 605, 555), (452, 395, 548, 485)]
    drips = [(330, 725, 374, 815), (612, 725, 652, 790), (480, 735, 520, 835)]
    for t in tiers:
        ell(*t, POOP_DARK, infl=11)
    for t in drips:
        ell(*t, POOP_DARK, infl=9)
    for t in tiers + drips:
        ell(*t, POOP)
    for t in [(340, 640, 440, 668), (385, 560, 465, 582), (428, 495, 484, 512), (478, 410, 512, 428)]:
        ell(*t, POOP_LIGHT)

    for x0 in (330, 500, 670):
        pts = []
        for i in range(0, 41):
            t = i / 40.0
            pts.append((X(x0 + 24 * math.sin(t * 3 * math.pi)), Y(150 - 120 * t)))
        d.line(pts, fill=STINK, width=int(R(15)), joint="curve")

    return img.resize((size, size), Image.LANCZOS)


main = background(512)
main.alpha_composite(hand(512, 0.98, 80))
main.convert("RGB").save(os.path.join(ROOT, "icon.png"))
main.resize((192, 192), Image.LANCZOS).convert("RGB").save(os.path.join(OUT, "main_192.png"))
background(432).save(os.path.join(OUT, "adaptive_bg.png"))
hand(432, 0.62, 80).save(os.path.join(OUT, "adaptive_fg.png"))
print("icons written")
