#!/usr/bin/env python3
"""Draws the face decals (../faces/*.png, 256x256 transparent) and the poop icon (../icons/poop.png).
Needs Pillow.  The faces are wrapped around the head sphere in game (see humanoid.gd)."""
import math
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
FACES = os.path.join(HERE, "..", "faces")
ICONS = os.path.join(HERE, "..", "icons")
os.makedirs(FACES, exist_ok=True)
os.makedirs(ICONS, exist_ok=True)

K = 2  # supersampling
BLACK = (18, 14, 14, 255)
WHITE = (255, 255, 255, 255)
RED = (225, 30, 30, 255)
PINK = (255, 120, 150, 255)
BONE = (238, 232, 214, 255)


def S(v):
    return v * 2 * K


def W(v):
    return max(1, int(round(S(v))))


def P(p):
    return (S(p[0]), S(p[1]))


def box(x0, y0, x1, y1):
    return [S(x0), S(y0), S(x1), S(y1)]


class Face:
    def __init__(self):
        self.img = Image.new("RGBA", (256 * K, 256 * K), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)

    # all coordinates are in a 128x128 design space
    def eye(self, cx, cy, rx, ry, px=0.0, py=0.0, pr=5.0, white=WHITE, pupil=BLACK):
        self.d.ellipse(box(cx - rx, cy - ry, cx + rx, cy + ry), fill=white, outline=BLACK, width=W(2))
        self.d.ellipse(box(cx + px - pr, cy + py - pr, cx + px + pr, cy + py + pr), fill=pupil)

    def dot(self, cx, cy, r, col=BLACK):
        self.d.ellipse(box(cx - r, cy - r, cx + r, cy + r), fill=col)

    def line(self, a, b, w=6, col=BLACK):
        self.d.line([P(a), P(b)], fill=col, width=W(w))
        for e in (a, b):
            self.dot(e[0], e[1], w / 2.0, col)

    def poly(self, pts, fill=None, outline=BLACK, w=3):
        self.d.polygon([P(p) for p in pts], fill=fill)
        if outline:
            self.d.line([P(p) for p in pts] + [P(pts[0])], fill=outline, width=W(w), joint="curve")

    def curve(self, cx, cy, rx, ry, a0, a1, w=5, col=BLACK):
        pts = []
        for i in range(41):
            t = math.radians(a0 + (a1 - a0) * i / 40.0)
            pts.append(P((cx + rx * math.cos(t), cy + ry * math.sin(t))))
        self.d.line(pts, fill=col, width=W(w), joint="curve")
        for p in (pts[0], pts[-1]):
            r = S(w) / 2.0
            self.d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=col)

    def heart(self, cx, cy, s, col=RED):
        self.dot(cx - s * 0.5, cy - s * 0.2, s * 0.56, col)
        self.dot(cx + s * 0.5, cy - s * 0.2, s * 0.56, col)
        self.d.polygon([P((cx - s * 1.04, cy - s * 0.02)), P((cx + s * 1.04, cy - s * 0.02)), P((cx, cy + s * 1.25))], fill=col)

    def save(self, name):
        out = self.img.resize((256, 256), Image.LANCZOS)
        out.save(os.path.join(FACES, name + ".png"))


def grin(f, x0, x1, y_top, depth, teeth=7, fangs=True, jag=False, fill=WHITE):
    """Wide grin: flat top lip, curved bottom, white teeth."""
    pts = []
    n = 40
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        pts.append((x, y_top + depth * math.sin(math.pi * i / n)))
    shape = [(x0, y_top)] + pts + [(x1, y_top)]
    f.poly(shape, fill=fill, outline=BLACK, w=3)
    for i in range(1, teeth):
        x = x0 + (x1 - x0) * i / teeth
        yb = y_top + depth * math.sin(math.pi * i / teeth)
        f.line((x, y_top), (x, yb), w=1.6)
    if fangs:
        for fx in (x0 + (x1 - x0) * 0.2, x1 - (x1 - x0) * 0.2):
            f.poly([(fx - 4, y_top), (fx + 4, y_top), (fx, y_top + 11)], fill=WHITE, outline=BLACK, w=1.6)
    if jag:
        # sharp teeth along the top and bottom edge
        steps = 8
        for i in range(steps):
            xa = x0 + (x1 - x0) * i / steps
            xb = x0 + (x1 - x0) * (i + 1) / steps
            f.poly([(xa, y_top), (xb, y_top), ((xa + xb) / 2, y_top + 9)], fill=WHITE, outline=BLACK, w=1.2)
    # mouth corner flicks
    f.line((x0 - 2, y_top - 1), (x0 - 7, y_top - 7), w=3)
    f.line((x1 + 2, y_top - 1), (x1 + 7, y_top - 7), w=3)


def evil():
    f = Face()
    f.line((24, 38), (56, 50), w=8)
    f.line((104, 38), (72, 50), w=8)
    f.eye(40, 62, 13, 8, px=4, py=1, pr=4.5)
    f.eye(88, 62, 13, 8, px=-4, py=1, pr=4.5)
    grin(f, 24, 104, 80, 26, teeth=8, fangs=True)
    f.save("evil")


def happy():
    f = Face()
    f.curve(40, 44, 13, 8, 200, 340, w=4)
    f.curve(88, 44, 13, 8, 200, 340, w=4)
    for cx in (40, 88):
        f.d.ellipse(box(cx - 7, 52, cx + 7, 74), fill=BLACK)
        f.dot(cx + 2, 58, 2.5, WHITE)
    f.curve(64, 78, 26, 20, 15, 165, w=5)
    f.d.ellipse(box(14, 76, 30, 90), fill=(255, 130, 150, 190))
    f.d.ellipse(box(98, 76, 114, 90), fill=(255, 130, 150, 190))
    f.save("happy")


def villain():
    f = Face()
    f.line((18, 28), (56, 52), w=9)
    f.line((110, 28), (72, 52), w=9)
    for cx in (40, 88):
        f.eye(cx, 64, 15, 9, white=RED, pupil=BLACK, pr=1.0)
        f.d.ellipse(box(cx - 3, 55, cx + 3, 73), fill=BLACK)
    grin(f, 16, 112, 82, 30, teeth=10, fangs=False, jag=True, fill=(60, 10, 10, 255))
    f.line((96, 34), (112, 60), w=3, col=(150, 20, 20, 255))   # scar
    f.save("villain")


def angry():
    f = Face()
    f.line((22, 36), (56, 52), w=8)
    f.line((106, 36), (72, 52), w=8)
    f.eye(40, 64, 11, 8, px=2, py=2, pr=4.5)
    f.eye(88, 64, 11, 8, px=-2, py=2, pr=4.5)
    f.curve(64, 104, 24, 14, 200, 340, w=6)
    f.line((98, 20), (106, 28), w=3, col=(220, 40, 40, 255))
    f.line((106, 20), (98, 28), w=3, col=(220, 40, 40, 255))
    f.save("angry")


def derp():
    f = Face()
    f.eye(40, 58, 18, 18, px=7, py=-5, pr=6.5)
    f.eye(90, 62, 10, 10, px=-3, py=3, pr=4)
    f.curve(64, 80, 24, 18, 10, 170, w=5)
    f.d.ellipse(box(60, 90, 84, 118), fill=PINK, outline=BLACK, width=W(2))
    f.line((72, 92), (72, 108), w=2)
    f.save("derp")


def cool():
    f = Face()
    f.d.rounded_rectangle(box(14, 46, 58, 76), radius=S(8), fill=BLACK)
    f.d.rounded_rectangle(box(70, 46, 114, 76), radius=S(8), fill=BLACK)
    f.line((58, 52), (70, 52), w=4)
    f.line((20, 52), (34, 52), w=2.5, col=(255, 255, 255, 200))
    f.line((76, 52), (90, 52), w=2.5, col=(255, 255, 255, 200))
    f.curve(64, 92, 22, 12, 20, 140, w=5)
    f.save("cool")


def skull():
    f = Face()
    f.d.ellipse(box(8, 10, 120, 122), fill=BONE, outline=BLACK, width=W(3))
    f.d.ellipse(box(22, 40, 54, 78), fill=BLACK)
    f.d.ellipse(box(74, 40, 106, 78), fill=BLACK)
    f.poly([(64, 78), (56, 94), (72, 94)], fill=BLACK, outline=None)
    f.d.rectangle(box(40, 100, 88, 118), fill=WHITE, outline=BLACK, width=W(2))
    for x in range(48, 88, 8):
        f.line((x, 100), (x, 118), w=1.6)
    f.save("skull")


def hearts():
    f = Face()
    f.heart(40, 56, 14, RED)
    f.heart(88, 56, 14, RED)
    f.curve(64, 82, 26, 20, 15, 165, w=5)
    f.d.ellipse(box(12, 84, 28, 98), fill=(255, 130, 150, 190))
    f.d.ellipse(box(100, 84, 116, 98), fill=(255, 130, 150, 190))
    f.save("hearts")


def neutral():
    f = Face()
    f.dot(42, 64, 5)
    f.dot(86, 64, 5)
    f.line((50, 96), (78, 96), w=4)
    f.save("neutral")


def calm():
    f = Face()
    f.dot(42, 62, 4.5)
    f.dot(86, 62, 4.5)
    f.curve(64, 82, 16, 10, 20, 160, w=3.5)
    f.save("calm")


def scared():
    f = Face()
    f.line((24, 36), (50, 30), w=4)
    f.line((104, 36), (78, 30), w=4)
    f.eye(40, 58, 15, 15, pr=3.5)
    f.eye(88, 58, 15, 15, pr=3.5)
    f.d.ellipse(box(52, 84, 76, 116), fill=BLACK)
    f.save("scared")


def zombie():
    f = Face()
    f.eye(40, 62, 13, 13, px=2, py=2, pr=3, white=(235, 235, 120, 255))
    f.eye(88, 62, 10, 10, px=-1, py=1, pr=3, white=(235, 235, 120, 255))
    pts = [(30, 96), (42, 106), (52, 94), (64, 106), (76, 94), (88, 106), (98, 96)]
    f.d.line([P(p) for p in pts], fill=BLACK, width=W(4), joint="curve")
    f.line((20, 40), (50, 50), w=3, col=(60, 90, 30, 255))
    f.save("zombie")


def dead():
    f = Face()
    for cx in (40, 88):
        f.line((cx - 9, 54), (cx + 9, 72), w=4)
        f.line((cx - 9, 72), (cx + 9, 54), w=4)
    f.line((48, 98), (80, 98), w=4)
    f.save("dead")


for fn in (evil, happy, villain, angry, derp, cool, skull, hearts, neutral, calm, scared, zombie, dead):
    fn()


# ------------------------------------------------------------ poop icon for the PLAY button
def poop_icon():
    size = 96
    big = 4
    img = Image.new("RGBA", (size * big, size * big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    u = size * big / 100.0
    POOP = (112, 66, 26, 255)
    DARK = (52, 28, 10, 255)
    LIGHT = (165, 110, 55, 255)

    def ell(x0, y0, x1, y1, fill, infl=0.0):
        d.ellipse([(x0 - infl) * u, (y0 - infl) * u, (x1 + infl) * u, (y1 + infl) * u], fill=fill)

    tiers = [(8, 62, 92, 92), (20, 42, 80, 72), (32, 24, 68, 52), (42, 9, 58, 32)]
    for t in tiers:
        ell(*t, DARK, 3.0)
    for t in tiers:
        ell(*t, POOP)
    for t in [(18, 70, 40, 76), (30, 50, 46, 55), (40, 31, 52, 35)]:
        ell(*t, LIGHT)
    for cx in (38, 62):
        ell(cx - 7, 56, cx + 7, 72, WHITE)
        ell(cx - 3, 60, cx + 3, 69, BLACK)
    pts = []
    for i in range(21):
        t = math.radians(20 + 140 * i / 20.0)
        pts.append(((50 + 14 * math.cos(t)) * u, (76 + 8 * math.sin(t)) * u))
    d.line(pts, fill=DARK, width=int(3 * u), joint="curve")
    img.resize((size, size), Image.LANCZOS).save(os.path.join(ICONS, "poop.png"))


poop_icon()
print("faces + poop icon written")
