extends RefCounted
## Central tuning knobs. Change a number here to rebalance the game.

const NPC_MIN := 100               # people in the mall (random between MIN and MAX)
const NPC_MAX := 150
const PLAYER_WALK := 5.2           # m/s
const PLAYER_SPRINT := 7.4
const GRAB_RANGE := 2.1            # how close a victim must be
const GRAB_COOLDOWN := 0.7
const EVERY_NTH_IS_INFECTED := 3   # every 3rd catch is infected instead of killed
const DUMB_CHANCE := 0.35          # share of infected that run into walls and die
const NPC_NOTICE_RADIUS := 15.0    # people start fleeing when you are this close
const NPC_CALM_RADIUS := 28.0      # ...and calm down when you are this far
const NPC_CAST_SHADOWS := false    # true = prettier, much slower on phones

const HALL_X := 40.0               # mall is 80 x 60 m (half sizes)
const HALL_Z := 30.0
const WALL_H := 7.0
