extends RefCounted
## Builds a simple "person" out of a few primitives. Meshes/materials are shared.
## Returns a Dictionary with the parts so the caller can animate them.
## Character faces -Z. Rotating a limb pivot by +X swings it FORWARD.


static func build(a, parent: Node3D, shirt: Material, skin: Material, pants: Material, cast_shadow: bool, detailed: bool = false) -> Dictionary:
    var shadow_mode: int = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var vis_end: float = 0.0 if detailed else 65.0
    var parts := {}

    var body := Node3D.new()
    body.name = "Body"
    parent.add_child(body)
    parts["body"] = body

    var torso := _mi(a.mesh_torso, shirt, shadow_mode, vis_end)
    torso.position = Vector3(0, 1.2, 0)
    torso.scale = Vector3(1.05, 1.0, 0.7)
    body.add_child(torso)
    parts["torso"] = torso

    var head := _mi(a.mesh_head, skin, shadow_mode, vis_end)
    head.position = Vector3(0, 1.68, 0)
    body.add_child(head)
    parts["head"] = head

    if detailed:
        for s in [-1, 1]:
            var e := _mi(a.mesh_eye, a.eye, shadow_mode, vis_end)
            e.position = Vector3(0.05 * s, 1.70, -0.115)
            body.add_child(e)

    for side in [-1, 1]:
        var pivot := Node3D.new()
        pivot.position = Vector3(0.26 * side, 1.5, 0)
        body.add_child(pivot)
        var arm := _mi(a.mesh_arm, skin, shadow_mode, vis_end)
        arm.position = Vector3(0, -0.29, 0)
        pivot.add_child(arm)
        var key: String = "arm_r" if side == 1 else "arm_l"
        parts[key] = pivot
        parts[key + "_mesh"] = arm
        if detailed:
            var hand := _mi(a.mesh_hand, skin, shadow_mode, vis_end)
            hand.position = Vector3(0, -0.64, 0)
            pivot.add_child(hand)
            parts["hand_r" if side == 1 else "hand_l"] = hand

    for side in [-1, 1]:
        var pivot := Node3D.new()
        pivot.position = Vector3(0.1 * side, 0.9, 0)
        body.add_child(pivot)
        var leg := _mi(a.mesh_leg, pants, shadow_mode, vis_end)
        leg.position = Vector3(0, -0.45, 0)
        pivot.add_child(leg)
        parts["leg_r" if side == 1 else "leg_l"] = pivot

    return parts


static func _mi(mesh: Mesh, mat: Material, shadow: int, vis_end: float) -> MeshInstance3D:
    var m := MeshInstance3D.new()
    m.mesh = mesh
    m.material_override = mat
    m.cast_shadow = shadow as GeometryInstance3D.ShadowCastingSetting
    if vis_end > 0.0:
        m.visibility_range_end = vis_end
    return m
