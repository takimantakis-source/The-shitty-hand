extends RefCounted
## Builds the whole mall procedurally: shell, toilet room, shops, atrium, exit, lights.
## Coordinates: hall spans x in [-40, 40], z in [-30, 30]. Toilet room is the NW corner,
## the exit is in the middle of the east wall (x = +40).

const Cfg = preload("res://scripts/config.gd")

var root: Node3D
var a
var solids: Array = []          # Rect2 footprints (x/z) used to keep spawn points clear
var door_hinge: Node3D
var exit_barrier: StaticBody3D
var exit_mesh: MeshInstance3D
var exit_label: Label3D
var toilet_pos := Vector3(-38.95, 0.0, -25.0)


func build(p_root: Node3D, p_assets) -> void:
    root = p_root
    a = p_assets
    _build_shell()
    _build_toilet_room()
    _build_shops()
    _build_atrium()
    _build_exit()
    _build_lighting()


func is_free(p: Vector3, margin: float) -> bool:
    var q := Vector2(p.x, p.z)
    for r in solids:
        var rect: Rect2 = r
        if rect.grow(margin).has_point(q):
            return false
    return true


func exit_pos() -> Vector3:
    return Vector3(Cfg.HALL_X, 0.0, 0.0)


func open_door() -> void:
    var tw := root.create_tween()
    tw.tween_property(door_hinge, "rotation:y", PI * 0.5, 0.8)


func open_exit() -> void:
    # Layer 8 = blocks NPCs only, so the player can walk out but people can't.
    exit_barrier.collision_layer = 8
    exit_mesh.material_override = a.exit_open
    exit_label.text = "EXIT OPEN"
    exit_label.modulate = Color(0.35, 1.0, 0.45)


# ---------------------------------------------------------------- helpers

func _box(center: Vector3, size: Vector3, mat: Material, solid: bool = true, parent: Node = null) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = center
    body.collision_layer = 1
    body.collision_mask = 0
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    body.add_child(mi)
    if solid:
        body.add_to_group("solid")
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = size
        cs.shape = bs
        body.add_child(cs)
    if parent == null:
        root.add_child(body)
    else:
        parent.add_child(body)
    return body


func _deco(center: Vector3, size: Vector3, mat: Material, shadows: bool = true) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat
    mi.position = center
    if not shadows:
        mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(mi)
    return mi


func _cyl(center: Vector3, radius: float, height: float, mat: Material, solid: bool = true, segments: int = 24) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = center
    body.collision_layer = 1
    body.collision_mask = 0
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = radius
    cm.bottom_radius = radius
    cm.height = height
    cm.radial_segments = segments
    cm.rings = 1
    mi.mesh = cm
    mi.material_override = mat
    body.add_child(mi)
    if solid:
        body.add_to_group("solid")
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = radius
        sh.height = height
        cs.shape = sh
        body.add_child(cs)
    root.add_child(body)
    return body


func _sign(text: String, pos: Vector3, rot_y: float, col: Color, px: float = 0.012, fsize: int = 96) -> Label3D:
    var l := Label3D.new()
    l.text = text
    l.font_size = fsize
    l.pixel_size = px
    l.outline_size = 16
    l.modulate = col
    l.outline_modulate = Color(0, 0, 0, 1)
    l.shaded = false
    l.double_sided = false
    l.position = pos
    l.rotation.y = rot_y
    root.add_child(l)
    return l


# ---------------------------------------------------------------- shell

func _build_shell() -> void:
    var hx: float = Cfg.HALL_X
    var hz: float = Cfg.HALL_Z
    var h: float = Cfg.WALL_H

    var floor_mi := MeshInstance3D.new()
    var pm := PlaneMesh.new()
    pm.size = Vector2(hx * 2.0 + 10.0, hz * 2.0 + 4.0)
    floor_mi.mesh = pm
    floor_mi.material_override = a.floor_tiles
    floor_mi.position = Vector3(2.0, 0.0, 0.0)
    root.add_child(floor_mi)

    _box(Vector3(0, h * 0.5, -hz - 0.5), Vector3(hx * 2.0 + 2.0, h, 1.0), a.wall)
    _box(Vector3(0, h * 0.5, hz + 0.5), Vector3(hx * 2.0 + 2.0, h, 1.0), a.wall)
    _box(Vector3(-hx - 0.5, h * 0.5, 0), Vector3(1.0, h, hz * 2.0), a.wall)
    var seg: float = hz - 3.0
    _box(Vector3(hx + 0.5, h * 0.5, -3.0 - seg * 0.5), Vector3(1.0, h, seg), a.wall)
    _box(Vector3(hx + 0.5, h * 0.5, 3.0 + seg * 0.5), Vector3(1.0, h, seg), a.wall)
    _box(Vector3(hx + 0.5, (4.5 + h) * 0.5, 0), Vector3(1.0, h - 4.5, 6.0), a.wall)

    _deco(Vector3(0, h + 0.2, 0), Vector3(hx * 2.0 + 2.0, 0.4, hz * 2.0 + 2.0), a.ceiling, false)
    for x in [-30.0, -10.0, 10.0, 30.0]:
        for z in [-18.0, -6.0, 6.0, 18.0]:
            _deco(Vector3(x, h - 0.03, z), Vector3(10.0, 0.06, 1.0), a.panel, false)


# ---------------------------------------------------------------- toilet room

func _build_toilet_room() -> void:
    var h: float = Cfg.WALL_H
    var wx := -30.0
    # east wall with a door opening at z in [-26.2, -23.8]
    _box(Vector3(wx, h * 0.5, -28.1), Vector3(0.4, h, 3.8), a.wall)
    _box(Vector3(wx, h * 0.5, -21.9), Vector3(0.4, h, 3.8), a.wall)
    _box(Vector3(wx, (2.6 + h) * 0.5, -25.0), Vector3(0.4, h - 2.6, 2.4), a.wall)
    _box(Vector3(-35.0, h * 0.5, -20.0), Vector3(10.4, h, 0.4), a.wall)
    solids.append(Rect2(-40.0, -30.0, 10.4, 10.4))

    _deco(Vector3(-35.0, 0.012, -25.0), Vector3(10.0, 0.02, 10.0), a.toilet_floor, false)

    # door (hinge at the north edge of the opening, swings out into the hall)
    door_hinge = Node3D.new()
    door_hinge.position = Vector3(wx, 0.0, -26.2)
    root.add_child(door_hinge)
    _box(Vector3(0, 1.3, 1.2), Vector3(0.12, 2.6, 2.4), a.door, true, door_hinge)
    _sign("WC", Vector3(wx + 0.3, 3.1, -25.0), PI * 0.5, Color(0.5, 0.8, 1.0), 0.012, 110)

    # the toilet (against the west wall, facing east)
    _deco(Vector3(-39.0, 0.21, -25.0), Vector3(0.75, 0.42, 0.5), a.porcelain)
    _deco(Vector3(-39.8, 0.62, -25.0), Vector3(0.3, 0.85, 0.52), a.porcelain)
    _deco(Vector3(-38.9, 0.445, -25.0), Vector3(0.62, 0.05, 0.46), a.porcelain)

    # stall partitions
    _box(Vector3(-38.2, 1.15, -26.6), Vector3(3.6, 2.0, 0.06), a.partition)
    _box(Vector3(-38.2, 1.15, -23.4), Vector3(3.6, 2.0, 0.06), a.partition)

    # sinks + mirror along the north wall
    _box(Vector3(-34.0, 0.45, -29.4), Vector3(5.0, 0.9, 1.0), a.counter)
    _deco(Vector3(-34.0, 1.8, -29.93), Vector3(4.6, 1.3, 0.04), a.mirror)

    var l := OmniLight3D.new()
    l.position = Vector3(-35.0, 4.5, -25.0)
    l.omni_range = 11.0
    l.light_energy = 1.0
    l.light_color = Color(0.9, 0.97, 1.0)
    l.shadow_enabled = false
    root.add_child(l)


# ---------------------------------------------------------------- shops

func _build_shops() -> void:
    # [x0, x1, z0, z1, facing (0:+Z 1:-Z 2:+X 3:-X), name, colour]
    var defs := [
        [-27.0, -11.0, -30.0, -22.0, 0, "SHOE PALACE", Color(0.95, 0.35, 0.40)],
        [-7.0, 11.0, -30.0, -22.0, 0, "BURGER BARN", Color(1.00, 0.70, 0.20)],
        [15.0, 34.0, -30.0, -22.0, 0, "TOY KINGDOM", Color(0.40, 0.75, 1.00)],
        [-36.0, -20.0, 22.0, 30.0, 1, "PHONE PLANET", Color(0.50, 0.90, 0.60)],
        [-14.0, 4.0, 22.0, 30.0, 1, "BOOK NOOK", Color(0.85, 0.60, 1.00)],
        [10.0, 28.0, 22.0, 30.0, 1, "GAME ZONE", Color(1.00, 0.45, 0.85)],
        [-40.0, -34.0, -12.0, 8.0, 2, "FASHION FIX", Color(1.00, 0.55, 0.55)],
        [34.0, 40.0, -20.0, -6.0, 3, "SPORTS ARENA", Color(0.45, 0.85, 0.95)],
        [34.0, 40.0, 6.0, 20.0, 3, "PIZZA PIT", Color(1.00, 0.80, 0.30)],
    ]
    for d in defs:
        _add_shop(d)


func _add_shop(d: Array) -> void:
    var h: float = Cfg.WALL_H
    var x0: float = d[0]
    var x1: float = d[1]
    var z0: float = d[2]
    var z1: float = d[3]
    var facing: int = d[4]
    var title: String = d[5]
    var col: Color = d[6]
    var cx: float = (x0 + x1) * 0.5
    var cz: float = (z0 + z1) * 0.5
    var sx: float = x1 - x0
    var sz: float = z1 - z0

    _box(Vector3(cx, h * 0.5, cz), Vector3(sx, h, sz), a.shop_wall)
    solids.append(Rect2(x0, z0, sx, sz))

    var glow: StandardMaterial3D = a.emissive(col.lightened(0.1), 0.9)
    var win_pos := Vector3.ZERO
    var win_size := Vector3.ZERO
    var sign_pos := Vector3.ZERO
    var rot_y := 0.0
    match facing:
        0:
            win_pos = Vector3(cx, 1.9, z1 + 0.04)
            win_size = Vector3(sx - 3.0, 3.4, 0.08)
            sign_pos = Vector3(cx, 5.4, z1 + 0.1)
            rot_y = 0.0
        1:
            win_pos = Vector3(cx, 1.9, z0 - 0.04)
            win_size = Vector3(sx - 3.0, 3.4, 0.08)
            sign_pos = Vector3(cx, 5.4, z0 - 0.1)
            rot_y = PI
        2:
            win_pos = Vector3(x1 + 0.04, 1.9, cz)
            win_size = Vector3(0.08, 3.4, sz - 3.0)
            sign_pos = Vector3(x1 + 0.1, 5.4, cz)
            rot_y = PI * 0.5
        _:
            win_pos = Vector3(x0 - 0.04, 1.9, cz)
            win_size = Vector3(0.08, 3.4, sz - 3.0)
            sign_pos = Vector3(x0 - 0.1, 5.4, cz)
            rot_y = -PI * 0.5
    _deco(win_pos, win_size, glow, false)
    _sign(title, sign_pos, rot_y, col.lightened(0.5))


# ---------------------------------------------------------------- atrium

func _build_atrium() -> void:
    var h: float = Cfg.WALL_H
    # fountain
    _cyl(Vector3(0, 0.35, 0), 5.0, 0.7, a.stone, true, 32)
    var wm := MeshInstance3D.new()
    var wc := CylinderMesh.new()
    wc.top_radius = 4.6
    wc.bottom_radius = 4.6
    wc.height = 0.06
    wc.radial_segments = 32
    wc.rings = 1
    wm.mesh = wc
    wm.material_override = a.water
    wm.position = Vector3(0, 0.66, 0)
    wm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(wm)
    _cyl(Vector3(0, 1.9, 0), 0.6, 3.6, a.stone, false, 16)
    solids.append(Rect2(-5.2, -5.2, 10.4, 10.4))

    # pillars
    for x in [-24.0, -8.0, 8.0, 24.0]:
        for z in [-12.0, 12.0]:
            _cyl(Vector3(x, h * 0.5, z), 0.7, h, a.stone, true, 16)
            solids.append(Rect2(x - 0.7, z - 0.7, 1.4, 1.4))

    # kiosks
    var kiosks := [[-14.0, -6.0, "INFO"], [14.0, -6.0, "CANDY"], [-14.0, 6.0, "COFFEE"], [14.0, 6.0, "JUICE"]]
    for k in kiosks:
        var kx: float = k[0]
        var kz: float = k[1]
        _box(Vector3(kx, 1.3, kz), Vector3(3.0, 2.6, 3.0), a.kiosk)
        solids.append(Rect2(kx - 1.5, kz - 1.5, 3.0, 3.0))
        _sign(str(k[2]), Vector3(kx, 3.0, kz + 1.55), 0.0, Color(1, 0.95, 0.7), 0.01, 80)
        _sign(str(k[2]), Vector3(kx, 3.0, kz - 1.55), PI, Color(1, 0.95, 0.7), 0.01, 80)


# ---------------------------------------------------------------- exit

func _build_exit() -> void:
    var hx: float = Cfg.HALL_X
    exit_barrier = _box(Vector3(hx + 0.3, 2.25, 0), Vector3(0.2, 4.5, 6.0), a.exit_locked)
    exit_mesh = exit_barrier.get_child(0)
    _deco(Vector3(hx + 6.0, 4.0, 0), Vector3(0.5, 14.0, 24.0), a.daylight, false)
    exit_label = _sign("EXIT", Vector3(hx - 0.4, 5.75, 0), -PI * 0.5, Color(1.0, 0.3, 0.3), 0.012, 150)


# ---------------------------------------------------------------- lighting

func _build_lighting() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.05, 0.05, 0.07)
    var sky := Sky.new()
    var sm := ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.55, 0.65, 0.80)
    sm.sky_horizon_color = Color(0.80, 0.82, 0.85)
    sm.ground_horizon_color = Color(0.60, 0.58, 0.55)
    sm.ground_bottom_color = Color(0.35, 0.33, 0.30)
    sky.sky_material = sm
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.5
    env.glow_bloom = 0.05
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.05
    var we := WorldEnvironment.new()
    we.environment = env
    root.add_child(we)

    # "skylight": the ceiling does not cast shadows, walls and props do
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-62.0, 35.0, 0.0)
    sun.light_energy = 0.7
    sun.light_color = Color(1.0, 0.96, 0.90)
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 50.0
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    root.add_child(sun)

    # mobile renderer: max 8 omni lights per mesh -> keep it to 6 here (+1 in the toilet)
    for x in [-26.0, 0.0, 26.0]:
        for z in [-10.0, 12.0]:
            var l := OmniLight3D.new()
            l.position = Vector3(x, 5.6, z)
            l.omni_range = 30.0
            l.light_energy = 1.3
            l.light_color = Color(1.0, 0.95, 0.86)
            l.shadow_enabled = false
            root.add_child(l)
