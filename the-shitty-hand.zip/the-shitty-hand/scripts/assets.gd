extends RefCounted
## Shared materials and meshes. Created once, reused by every character and prop.

var shirts: Array = []
var skins: Array = []
var pants: Array = []

var player_shirt: StandardMaterial3D
var player_pants: StandardMaterial3D
var eye: StandardMaterial3D
var infected_shirt: StandardMaterial3D
var infected_skin: StandardMaterial3D
var poop: StandardMaterial3D
var stink: StandardMaterial3D

var floor_tiles: StandardMaterial3D
var toilet_floor: StandardMaterial3D
var wall: StandardMaterial3D
var shop_wall: StandardMaterial3D
var stone: StandardMaterial3D
var water: StandardMaterial3D
var ceiling: StandardMaterial3D
var panel: StandardMaterial3D
var door: StandardMaterial3D
var porcelain: StandardMaterial3D
var partition: StandardMaterial3D
var mirror: StandardMaterial3D
var counter: StandardMaterial3D
var kiosk: StandardMaterial3D
var exit_locked: StandardMaterial3D
var exit_open: StandardMaterial3D
var daylight: StandardMaterial3D

var mesh_torso: CapsuleMesh
var mesh_head: SphereMesh
var mesh_arm: CapsuleMesh
var mesh_leg: BoxMesh
var mesh_hand: SphereMesh
var mesh_eye: SphereMesh


func _init() -> void:
    _make_character_assets()
    _make_world_assets()


func _mat(color: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    m.metallic = metal
    return m


func emissive(color: Color, energy: float = 1.5) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.emission_enabled = true
    m.emission = color
    m.emission_energy_multiplier = energy
    return m


func _alpha(m: StandardMaterial3D) -> StandardMaterial3D:
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m


func _make_character_assets() -> void:
    for c in [Color(0.96, 0.80, 0.69), Color(0.87, 0.67, 0.51), Color(0.72, 0.51, 0.36), Color(0.55, 0.38, 0.26), Color(0.36, 0.24, 0.17)]:
        skins.append(_mat(c, 0.55))
    for c in [Color(0.80, 0.15, 0.15), Color(0.15, 0.30, 0.75), Color(0.90, 0.75, 0.15), Color(0.20, 0.55, 0.25),
            Color(0.90, 0.90, 0.90), Color(0.12, 0.12, 0.14), Color(0.90, 0.50, 0.65), Color(0.10, 0.55, 0.60),
            Color(0.50, 0.25, 0.60), Color(0.90, 0.50, 0.10), Color(0.50, 0.50, 0.52), Color(0.10, 0.12, 0.30)]:
        shirts.append(_mat(c, 0.8))
    for c in [Color(0.18, 0.25, 0.45), Color(0.10, 0.10, 0.10), Color(0.55, 0.50, 0.35), Color(0.35, 0.35, 0.38), Color(0.25, 0.17, 0.10)]:
        pants.append(_mat(c, 0.85))

    player_shirt = _mat(Color(0.95, 0.45, 0.08), 0.8)
    player_pants = _mat(Color(0.12, 0.14, 0.22), 0.85)
    eye = _mat(Color(0.02, 0.02, 0.02), 0.2)
    infected_shirt = _mat(Color(0.28, 0.36, 0.20), 0.9)
    infected_skin = _mat(Color(0.52, 0.70, 0.33), 0.6)
    poop = _mat(Color(0.30, 0.17, 0.06), 0.22)
    stink = _alpha(emissive(Color(0.55, 0.85, 0.20, 0.55), 0.8))

    mesh_torso = CapsuleMesh.new()
    mesh_torso.radius = 0.2
    mesh_torso.height = 0.74
    mesh_torso.radial_segments = 12
    mesh_torso.rings = 4

    mesh_head = SphereMesh.new()
    mesh_head.radius = 0.13
    mesh_head.height = 0.26
    mesh_head.radial_segments = 14
    mesh_head.rings = 7

    mesh_arm = CapsuleMesh.new()
    mesh_arm.radius = 0.05
    mesh_arm.height = 0.62
    mesh_arm.radial_segments = 8
    mesh_arm.rings = 3

    mesh_leg = BoxMesh.new()
    mesh_leg.size = Vector3(0.19, 0.9, 0.22)

    mesh_hand = SphereMesh.new()
    mesh_hand.radius = 0.075
    mesh_hand.height = 0.15
    mesh_hand.radial_segments = 10
    mesh_hand.rings = 5

    mesh_eye = SphereMesh.new()
    mesh_eye.radius = 0.02
    mesh_eye.height = 0.04
    mesh_eye.radial_segments = 6
    mesh_eye.rings = 3


func _make_world_assets() -> void:
    # Polished tile floor with a procedurally generated tile texture (world-space triplanar).
    floor_tiles = _mat(Color.WHITE, 0.2)
    floor_tiles.albedo_texture = _make_tile_texture(Color(0.86, 0.84, 0.80), Color(0.52, 0.50, 0.47), 4, 256)
    floor_tiles.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    floor_tiles.uv1_triplanar = true
    floor_tiles.uv1_world_triplanar = true
    floor_tiles.uv1_scale = Vector3(0.3, 0.3, 0.3)
    floor_tiles.clearcoat_enabled = true
    floor_tiles.clearcoat = 0.5
    floor_tiles.clearcoat_roughness = 0.08

    toilet_floor = _mat(Color.WHITE, 0.25)
    toilet_floor.albedo_texture = _make_tile_texture(Color(0.55, 0.76, 0.78), Color(0.30, 0.45, 0.47), 4, 128)
    toilet_floor.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    toilet_floor.uv1_triplanar = true
    toilet_floor.uv1_world_triplanar = true
    toilet_floor.uv1_scale = Vector3(0.9, 0.9, 0.9)

    wall = _mat(Color(0.93, 0.91, 0.87), 0.85)
    shop_wall = _mat(Color(0.80, 0.78, 0.74), 0.8)
    stone = _mat(Color(0.72, 0.70, 0.66), 0.5)
    water = _alpha(_mat(Color(0.25, 0.55, 0.80, 0.75), 0.03))
    ceiling = _mat(Color(0.95, 0.95, 0.95), 0.9)
    panel = emissive(Color(1.0, 0.97, 0.90), 2.4)
    door = _mat(Color(0.55, 0.40, 0.28), 0.6)
    porcelain = _mat(Color(0.97, 0.97, 0.98), 0.12)
    partition = _mat(Color(0.55, 0.72, 0.78), 0.4)
    mirror = _mat(Color(0.80, 0.85, 0.90), 0.04, 1.0)
    counter = _mat(Color(0.20, 0.20, 0.22), 0.3, 0.4)
    kiosk = _mat(Color(0.25, 0.30, 0.40), 0.5)
    daylight = emissive(Color(1.0, 0.98, 0.92), 3.0)

    exit_locked = _alpha(_mat(Color(1.0, 0.1, 0.1, 0.4), 0.2))
    exit_locked.emission_enabled = true
    exit_locked.emission = Color(1.0, 0.1, 0.1)
    exit_locked.emission_energy_multiplier = 0.7

    exit_open = _alpha(_mat(Color(0.1, 1.0, 0.3, 0.2), 0.2))
    exit_open.emission_enabled = true
    exit_open.emission = Color(0.1, 1.0, 0.3)
    exit_open.emission_energy_multiplier = 0.6


func _make_tile_texture(base: Color, grout: Color, tiles: int, px: int) -> ImageTexture:
    var img := Image.create(px, px, true, Image.FORMAT_RGB8)
    var rng := RandomNumberGenerator.new()
    rng.seed = 12345
    var tile_px: int = px / tiles
    for ty in tiles:
        for tx in tiles:
            var shade := rng.randf_range(-0.035, 0.035)
            for y in tile_px:
                for x in tile_px:
                    var ox := tx * tile_px + x
                    var oy := ty * tile_px + y
                    if x < 2 or y < 2:
                        img.set_pixel(ox, oy, grout)
                    else:
                        var n := shade + rng.randf_range(-0.012, 0.012)
                        img.set_pixel(ox, oy, Color(base.r + n, base.g + n, base.b + n))
    img.generate_mipmaps()
    return ImageTexture.create_from_image(img)
