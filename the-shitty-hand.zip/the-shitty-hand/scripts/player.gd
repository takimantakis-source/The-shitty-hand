extends CharacterBody3D
## The player: sits on the toilet during the intro, then runs around with a poop hand.

const Cfg = preload("res://scripts/config.gd")
const Humanoid = preload("res://scripts/humanoid.gd")

var move_input := Vector2.ZERO     # world-space x/z direction, length 0..1 (set by game.gd)
var sprint_held := false
var stamina := 1.0
var exhausted := false
var sitting := true
var holding_poop := false

var assets
var body: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var hand_r: MeshInstance3D
var anim_t := 0.0
var grab_t := 0.0
var cur_speed := 0.0


func setup(a) -> void:
    assets = a
    collision_layer = 4
    collision_mask = 1
    motion_mode = CharacterBody3D.MOTION_MODE_FLOATING
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.32
    cap.height = 1.7
    cs.shape = cap
    cs.position = Vector3(0, 0.85, 0)
    add_child(cs)

    var parts: Dictionary = Humanoid.build(a, self, a.player_shirt, a.skins[1], a.player_pants, true, true)
    body = parts["body"]
    arm_l = parts["arm_l"]
    arm_r = parts["arm_r"]
    leg_l = parts["leg_l"]
    leg_r = parts["leg_r"]
    hand_r = parts["hand_r"]
    set_sitting(true)


func face_angle(rad: float) -> void:
    rotation.y = rad


func face_point(p: Vector3) -> void:
    var d := p - position
    rotation.y = atan2(-d.x, -d.z)


func set_sitting(b: bool) -> void:
    sitting = b
    if b:
        body.position.y = -0.38
        leg_l.rotation.x = 1.25
        leg_r.rotation.x = 1.25
        arm_l.rotation.x = 0.5
        arm_r.rotation.x = 0.5
    else:
        body.position.y = 0.0
        leg_l.rotation.x = 0.0
        leg_r.rotation.x = 0.0
        arm_l.rotation.x = 0.0
        arm_r.rotation.x = 0.0


func give_poop_hand() -> void:
    holding_poop = true
    hand_r.material_override = assets.poop
    var p := CPUParticles3D.new()
    p.amount = 14
    p.lifetime = 1.4
    p.local_coords = false
    p.direction = Vector3.UP
    p.spread = 30.0
    p.gravity = Vector3(0, 0.3, 0)
    p.initial_velocity_min = 0.2
    p.initial_velocity_max = 0.5
    p.scale_amount_min = 0.6
    p.scale_amount_max = 1.2
    var sm := SphereMesh.new()
    sm.radius = 0.035
    sm.height = 0.07
    sm.radial_segments = 6
    sm.rings = 3
    p.mesh = sm
    p.material_override = assets.stink
    p.position = Vector3(0, -0.7, 0)
    arm_r.add_child(p)


func do_grab_anim() -> void:
    grab_t = 0.3


func _physics_process(delta: float) -> void:
    if sitting:
        return
    var moving: bool = move_input.length() > 0.08
    var want_sprint: bool = sprint_held and moving and (not exhausted) and stamina > 0.0
    if want_sprint:
        stamina = maxf(0.0, stamina - delta * 0.28)
        if stamina <= 0.0:
            exhausted = true
    else:
        stamina = minf(1.0, stamina + delta * (0.06 if sprint_held else 0.18))
        if exhausted and stamina > 0.35:
            exhausted = false
    var speed: float = Cfg.PLAYER_SPRINT if want_sprint else Cfg.PLAYER_WALK
    cur_speed = speed if moving else 0.0
    velocity = Vector3(move_input.x, 0.0, move_input.y) * (speed if moving else 0.0)
    move_and_slide()
    if moving:
        var target: float = atan2(-move_input.x, -move_input.y)
        rotation.y = lerp_angle(rotation.y, target, clampf(14.0 * delta, 0.0, 1.0))
    _animate(delta)


func _animate(delta: float) -> void:
    if grab_t > 0.0:
        grab_t -= delta
    var k: float = minf(1.0, 10.0 * delta)
    if cur_speed > 0.1:
        anim_t += delta * (3.0 + cur_speed * 1.3)
        var s: float = sin(anim_t) * 0.85
        leg_l.rotation.x = s
        leg_r.rotation.x = -s
        arm_l.rotation.x = -s
        arm_r.rotation.x = s
    else:
        leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, k)
        leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, k)
        arm_l.rotation.x = lerpf(arm_l.rotation.x, 0.0, k)
        arm_r.rotation.x = lerpf(arm_r.rotation.x, 0.0, k)
    if holding_poop:
        # right arm stays up, hand held out in front
        var up: float = 1.55
        if cur_speed > 0.1:
            up += sin(anim_t * 2.0) * 0.08
        if grab_t > 0.0:
            up += sin(grab_t / 0.3 * PI) * 0.5
        arm_r.rotation.x = up
