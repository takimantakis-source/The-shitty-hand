extends Control
## All UI is drawn by hand and driven by raw touch events, so multi-touch works the same on a
## phone and on desktop (where the mouse emulates a single touch).
##   left half  = floating joystick   |  right side = drag to look
##   RUN / GRAB = buttons              |  dialogs     = tap the button

const JOY_R := 95.0
const GRAB_R := 88.0
const RUN_R := 62.0
const SAFE := 40.0   # side margin so notches don't cover the HUD

var joy := Vector2.ZERO
var sprint_held := false
var grab_held := false

var stamina := 1.0
var healthy := 0
var infected := 0
var dead := 0
var catches := 0
var next_is_infection := false
var show_stats := false

var hint_on := false
var hint_angle := 0.0
var hint_dist := 0.0
var hint_text := ""

var dialog_text := ""
var dialog_button := ""
var dialog_cb: Callable = Callable()

var _toasts: Array = []
var _look := Vector2.ZERO
var _joy_touch := -1
var _joy_origin := Vector2.ZERO
var _look_touch := -1
var _grab_touch := -1
var _run_touch := -1

var _sb_panel: StyleBoxFlat
var _sb_dialog: StyleBoxFlat
var _sb_button: StyleBoxFlat


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _sb_panel = _make_box(Color(0, 0, 0, 0.45), 14)
    _sb_dialog = _make_box(Color(0.07, 0.07, 0.09, 0.94), 22, Color(0.55, 0.38, 0.16), 4)
    _sb_button = _make_box(Color(0.42, 0.26, 0.08, 1.0), 18, Color(0.95, 0.75, 0.3), 3)


func _make_box(c: Color, r: int, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = c
    sb.set_corner_radius_all(r)
    if bw > 0:
        sb.border_color = border
        sb.set_border_width_all(bw)
    return sb


# ---------------------------------------------------------------- API for game.gd

func consume_look() -> Vector2:
    var l := _look
    _look = Vector2.ZERO
    return l


func toast(text: String, ttl: float = 2.4) -> void:
    _toasts.append([text, ttl])
    if _toasts.size() > 3:
        _toasts.pop_front()


func show_dialog(text: String, button: String, cb: Callable) -> void:
    dialog_text = text
    dialog_button = button
    dialog_cb = cb
    joy = Vector2.ZERO
    sprint_held = false
    grab_held = false
    _joy_touch = -1
    _look_touch = -1
    _grab_touch = -1
    _run_touch = -1


# ---------------------------------------------------------------- input

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var t := event as InputEventScreenTouch
        if t.pressed:
            _down(t.index, t.position)
        else:
            _up(t.index)
    elif event is InputEventScreenDrag:
        var d := event as InputEventScreenDrag
        _drag(d.index, d.position, d.relative)


func _grab_center() -> Vector2:
    return Vector2(size.x - SAFE - 110.0, size.y - 170.0)


func _run_center() -> Vector2:
    return Vector2(size.x - SAFE - 290.0, size.y - 100.0)


func _panel_rect() -> Rect2:
    var w: float = minf(size.x * 0.82, 940.0)
    var h := 360.0
    return Rect2((size.x - w) * 0.5, (size.y - h) * 0.5, w, h)


func _dialog_button_rect() -> Rect2:
    var p := _panel_rect()
    return Rect2(p.position.x + p.size.x * 0.5 - 190.0, p.end.y - 100.0, 380.0, 76.0)


func _down(idx: int, pos: Vector2) -> void:
    if dialog_text != "":
        if _dialog_button_rect().has_point(pos):
            var cb: Callable = dialog_cb
            dialog_text = ""
            if cb.is_valid():
                cb.call()
        return
    if _grab_touch == -1 and pos.distance_to(_grab_center()) < GRAB_R:
        _grab_touch = idx
        grab_held = true
        return
    if _run_touch == -1 and pos.distance_to(_run_center()) < RUN_R:
        _run_touch = idx
        sprint_held = true
        return
    if pos.x < size.x * 0.5 and _joy_touch == -1:
        _joy_touch = idx
        _joy_origin = pos
        joy = Vector2.ZERO
        return
    if _look_touch == -1:
        _look_touch = idx


func _up(idx: int) -> void:
    if idx == _joy_touch:
        _joy_touch = -1
        joy = Vector2.ZERO
    elif idx == _look_touch:
        _look_touch = -1
    elif idx == _grab_touch:
        _grab_touch = -1
        grab_held = false
    elif idx == _run_touch:
        _run_touch = -1
        sprint_held = false


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
    if idx == _joy_touch:
        var v := pos - _joy_origin
        if v.length() > JOY_R:
            v = v.normalized() * JOY_R
        joy = v / JOY_R
        if joy.length() < 0.12:
            joy = Vector2.ZERO
    elif idx == _look_touch:
        _look += rel


# ---------------------------------------------------------------- drawing

func _process(delta: float) -> void:
    for t in _toasts:
        t[1] -= delta
    for i in range(_toasts.size() - 1, -1, -1):
        if _toasts[i][1] <= 0.0:
            _toasts.remove_at(i)
    queue_redraw()


func _draw() -> void:
    var font := ThemeDB.fallback_font

    if show_stats:
        draw_style_box(_sb_panel, Rect2(SAFE, 12, 480, 112))
        draw_string(font, Vector2(SAFE + 16, 46), "Healthy %d    Infected %d    Dead %d" % [healthy, infected, dead], HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color.WHITE)
        var nxt: String = "INFECTED" if next_is_infection else "dies"
        draw_string(font, Vector2(SAFE + 16, 80), "Catches %d   -   next victim: %s" % [catches, nxt], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.95, 0.85, 0.45))
        draw_rect(Rect2(SAFE + 16, 96, 240, 12), Color(0, 0, 0, 0.5))
        draw_rect(Rect2(SAFE + 16, 96, 240.0 * stamina, 12), Color(0.45, 0.9, 0.4))

    if hint_on:
        var c := Vector2(size.x * 0.5, 120.0)
        var dv := Vector2(sin(hint_angle), -cos(hint_angle))
        var perp := Vector2(-dv.y, dv.x)
        var tip := c + dv * 34.0
        var b1 := c - dv * 18.0 + perp * 22.0
        var b2 := c - dv * 18.0 - perp * 22.0
        draw_colored_polygon(PackedVector2Array([tip, b1, b2]), Color(1.0, 0.8, 0.2, 0.95))
        draw_string(font, Vector2(c.x - 120, c.y + 64), "%s  %d m" % [hint_text, int(hint_dist)], HORIZONTAL_ALIGNMENT_CENTER, 240, 22, Color.WHITE)

    var ty: float = size.y * 0.30
    for t in _toasts:
        var a: float = clampf(float(t[1]) / 0.6, 0.0, 1.0)
        draw_string(font, Vector2(2, ty + 2), str(t[0]), HORIZONTAL_ALIGNMENT_CENTER, size.x, 32, Color(0, 0, 0, a))
        draw_string(font, Vector2(0, ty), str(t[0]), HORIZONTAL_ALIGNMENT_CENTER, size.x, 32, Color(1, 1, 1, a))
        ty += 42.0

    if show_stats and dialog_text == "":
        # joystick
        var jc: Vector2 = _joy_origin if _joy_touch != -1 else Vector2(SAFE + 150.0, size.y - 150.0)
        var jal: float = 0.55 if _joy_touch != -1 else 0.22
        draw_circle(jc, JOY_R, Color(1, 1, 1, jal * 0.35))
        draw_arc(jc, JOY_R, 0.0, TAU, 48, Color(1, 1, 1, jal + 0.2), 3.0)
        draw_circle(jc + joy * JOY_R, 38.0, Color(1, 1, 1, jal + 0.25))
        # buttons
        var gc := _grab_center()
        draw_circle(gc, GRAB_R, Color(0.45, 0.25, 0.05, 0.85 if grab_held else 0.6))
        draw_arc(gc, GRAB_R, 0.0, TAU, 48, Color(1, 0.8, 0.4, 0.9), 4.0)
        draw_string(font, Vector2(gc.x - 70, gc.y + 11), "GRAB", HORIZONTAL_ALIGNMENT_CENTER, 140, 32, Color.WHITE)
        var rc := _run_center()
        draw_circle(rc, RUN_R, Color(0.1, 0.3, 0.5, 0.85 if sprint_held else 0.55))
        draw_arc(rc, RUN_R, 0.0, TAU, 40, Color(0.6, 0.85, 1, 0.9), 3.0)
        draw_string(font, Vector2(rc.x - 50, rc.y + 9), "RUN", HORIZONTAL_ALIGNMENT_CENTER, 100, 26, Color.WHITE)

    if dialog_text != "":
        draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.55))
        var p := _panel_rect()
        draw_style_box(_sb_dialog, p)
        draw_multiline_string(font, Vector2(p.position.x + 30, p.position.y + 62), dialog_text, HORIZONTAL_ALIGNMENT_CENTER, p.size.x - 60, 30, -1, Color.WHITE)
        var br := _dialog_button_rect()
        draw_style_box(_sb_button, br)
        draw_string(font, Vector2(br.position.x, br.position.y + 50), dialog_button, HORIZONTAL_ALIGNMENT_CENTER, br.size.x, 32, Color.WHITE)
